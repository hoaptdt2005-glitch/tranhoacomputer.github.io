module.exports = {
  apps: [{
    name: "check-kenspyronx",
    script: "./src/app.js",
    instances: "max",
    exec_mode: "cluster",
    max_memory_restart: "3G",
    watch: false,
    env: {
      NODE_ENV: "production"
    },
    env_development: {
      NODE_ENV: "development"
    }
  }]
};
