# 🛡️ PC SERVER SECURITY HANDBOOK & DEVSECOPS HARDENING

Documentation guiding the deep security implementation for the physical server / VPS hosting the **CYBER C2 DEFENDER (IP Report & Anti-DDoS)** system, adhering to the **Least Privilege** and **Defense in Depth** principles.

---

## 📑 TABLE OF CONTENTS
1. [Configure Application Execution with Least Privilege](#1-configure-application-execution-with-least-privilege)
2. [Redis Security Hardening (`redis.conf` Hardening)](#2-redis-security-hardening-redisconf-hardening)
3. [Configure mTLS Cloudflare Authenticated Origin Pulls](#3-configure-mtls-cloudflare-authenticated-origin-pulls)
4. [Windows & Linux Firewall Blocking Direct-to-IP](#4-windows--linux-firewall-blocking-direct-to-ip)
5. [Secure Nginx Reverse Proxy Configuration](#5-secure-nginx-reverse-proxy-configuration)

---

## 1. CONFIGURE APPLICATION EXECUTION WITH LEAST PRIVILEGE

> ⚠️ **Golden Rule**: Absolutely DO NOT run Node.js applications under the `root` (Linux) or `Administrator` (Windows) privileges.

### On Linux (Ubuntu/Debian):
```bash
# 1. Create a dedicated user for the app without an interactive login shell
sudo adduser --system --no-create-home --group apprunner

# 2. Grant permissions to the project directory
sudo chown -R apprunner:apprunner /home/kenzema/Desktop/programming/IPREPORT

# 3. Grant read-only permissions for secret configuration files
chmod 600 /home/kenzema/Desktop/programming/IPREPORT/.env
chmod 600 /home/kenzema/Desktop/programming/IPREPORT/config.txt
```

---

## 2. REDIS SECURITY HARDENING (`redis.conf` HARDENING)

Open the Redis configuration file (`/etc/redis/redis.conf` on Linux or `redis.windows.conf`):

```ini
# 1. Only listen on Localhost (Absolutely do not expose 0.0.0.0 to the Internet)
bind 127.0.0.1 ::1
protected-mode yes
port 6379

# 2. Set a strong access password (Minimum 32 random characters)
requirepass YourSuperStrongRedisPassword_ChangeMe_2026!

# 3. Rename or disable dangerous commands (Command Renaming)
rename-command FLUSHDB ""
rename-command FLUSHALL ""
rename-command KEYS ""
rename-command CONFIG "B9F8D2_CONFIG_SECRET"
rename-command SHUTDOWN "B9F8D2_SHUTDOWN_SECRET"

# 4. Limit maximum RAM capacity and Eviction Policy
maxmemory 512mb
maxmemory-policy allkeys-lru
```

Restart Redis:
```bash
sudo systemctl restart redis-server
```

---

## 3. CONFIGURE mTLS CLOUDFLARE AUTHENTICATED ORIGIN PULLS

Cloudflare Authenticated Origin Pulls (mTLS) ensures that **ONLY Cloudflare** can perform TLS handshakes with your server. Any requests attempting to connect directly to the server IP will be rejected at the SSL Handshake layer.

### Step 1: Download Cloudflare CA Certificate
Download the official `cloudflare-origin-pull-ca.pem` file from Cloudflare and save it to the `certs/` directory:
```bash
mkdir -p certs
curl -s -o certs/cloudflare-origin-pull-ca.pem https://developers.cloudflare.com/ssl/static/authenticated_origin_pull_ca.pem
```

### Step 2: Create Origin Certificate from Cloudflare Dashboard
1. Go to **SSL/TLS** -> **Origin Server** -> Click **Create Certificate**.
2. Save the certificate file as `certs/origin.crt` and the private key as `certs/origin.key`.

### Step 3: Enable mTLS in the `.env` file
```ini
USE_HTTPS=true
SSL_CERT_PATH=certs/origin.crt
SSL_KEY_PATH=certs/origin.key
CLOUDFLARE_CA_PATH=certs/cloudflare-origin-pull-ca.pem
```

---

## 4. WINDOWS & LINUX FIREWALL BLOCKING DIRECT-TO-IP

### On Windows Server / Windows PC:
Run the pre-created PowerShell script:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\setup_firewall.ps1
```

### On Linux (UFW Firewall):
```bash
# 1. Deny all incoming connections
sudo ufw default deny incoming
sudo ufw default allow outgoing

# 2. Open SSH port
sudo ufw allow 22/tcp

# 3. Only allow Cloudflare IP ranges to access ports 80, 443, and 3000
for ip in $(curl -s https://www.cloudflare.com/ips-v4); do sudo ufw allow proto tcp from $ip to any port 80,443,3000; done
for ip in $(curl -s https://www.cloudflare.com/ips-v6); do sudo ufw allow proto tcp from $ip to any port 80,443,3000; done

# 4. Enable UFW
sudo ufw enable
```

---

## 5. SECURE NGINX REVERSE PROXY CONFIGURATION

```nginx
# /etc/nginx/conf.d/ipshield.conf
limit_req_zone $binary_remote_addr zone=api_limit:10m rate=20r/s;

server {
    listen 443 ssl http2;
    server_name shield.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/shield.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/shield.yourdomain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;

    # Block scanning for hidden and sensitive files
    location ~ /\.(env|git|svn|ht|DS_Store) {
        deny all;
        return 404;
    }

    location ~* \.(config\.txt|rdb|enc|bak|sql|log)$ {
        deny all;
        return 404;
    }

    location / {
        limit_req zone=api_limit burst=15 nodelay;
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
