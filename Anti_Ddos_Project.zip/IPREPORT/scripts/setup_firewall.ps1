<#
.SYNOPSIS
    Script automatically downloads Cloudflare's IP list and configures Windows Advanced Firewall
    to block 100% of Direct-to-IP connections to the Server PC, only allowing Cloudflare Edge Network.

.DESCRIPTION
    1. Downloads official IPv4 and IPv6 lists from Cloudflare:
       - https://www.cloudflare.com/ips-v4
       - https://www.cloudflare.com/ips-v6
    2. Creates / Updates Firewall Rule for port 80 (HTTP), 443 (HTTPS) and custom port (3000).
    3. Blocks all other IPs from directly accessing application ports.

.NOTES
    Requires running PowerShell as Administrator (Run as Administrator).
#>

Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "⚡ CYBER DEFENSE: CLOUDFLARE WINDOWS FIREWALL SETUP" -ForegroundColor Green
Write-Host "=======================================================" -ForegroundColor Cyan

# Check for Administrator privileges
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Error "[-] ERROR: Please run PowerShell as Administrator!"
    Exit 1
}

$PORT_LIST = @(80, 443, 3000)
$RULE_NAME = "Cloudflare_Edge_Only_Access"

Write-Host "[1/3] Downloading official IP list from Cloudflare..." -ForegroundColor Yellow

try {
    $cf_ipv4 = Invoke-RestMethod -Uri "https://www.cloudflare.com/ips-v4" -UseBasicParsing
    $cf_ipv6 = Invoke-RestMethod -Uri "https://www.cloudflare.com/ips-v6" -UseBasicParsing

    $ipList = @()
    $cf_ipv4 -split "`n" | ForEach-Object { if ($_.Trim()) { $ipList += $_.Trim() } }
    $cf_ipv6 -split "`n" | ForEach-Object { if ($_.Trim()) { $ipList += $_.Trim() } }

    # Add Localhost to prevent loss of internal connections
    $ipList += "127.0.0.1"
    $ipList += "::1"

    Write-Host "[+] Successfully downloaded $($ipList.Count) valid Cloudflare IP ranges." -ForegroundColor Green
} catch {
    Write-Error "[-] ERROR downloading IPs from Cloudflare: $_"
    Exit 1
}

Write-Host "[2/3] Deleting old Rules if they exist..." -ForegroundColor Yellow
Get-NetFirewallRule -DisplayName $RULE_NAME -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue

Write-Host "[3/3] Setting up new Windows Firewall Rule..." -ForegroundColor Yellow

foreach ($port in $PORT_LIST) {
    New-NetFirewallRule `
        -DisplayName "$RULE_NAME - Port $port" `
        -Direction Inbound `
        -LocalPort $port `
        -Protocol TCP `
        -Action Allow `
        -RemoteAddress $ipList `
        -Profile Any `
        -Description "Only allow traffic routing through Cloudflare Edge Network to port $port." | Out-Null
    
    Write-Host "[+] Blocked port $port: Only allowing Cloudflare IPs to access!" -ForegroundColor Green
}

Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "🎉 SUCCESS: All Direct IP connections to the server have been blocked!" -ForegroundColor Green
Write-Host "=======================================================" -ForegroundColor Cyan
