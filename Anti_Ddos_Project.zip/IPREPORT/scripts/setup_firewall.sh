#!/usr/bin/env bash
# ==============================================================================
# 🛡️ CYBER C2 DEFENDER - PRODUCTION NETWORK FIREWALL SETUP SCRIPT
# ==============================================================================
# Features:
# 1. Locks down Redis Port 6379 (Only allows 127.0.0.1 for internal access).
# 2. Opens necessary Ports: 80 (HTTP), 443 (HTTPS), 3000 (App Dashboard), 22/2208 (SSH).
# 3. Blocks all other strange ports (Default Ingress: DENY).
# ==============================================================================

set -e

echo "======================================================="
echo "🛡️  STARTING SECURITY FIREWALL CONFIGURATION FOR CYBER C2 DEFENDER"
echo "======================================================="

# Check root / sudo privileges
if [ "$EUID" -ne 0 ]; then
  echo "❌ Please run this script with sudo privileges: sudo bash scripts/setup_firewall.sh"
  exit 1
fi

# 1. Install UFW if not present
if ! command -v ufw &> /dev/null; then
    echo "📦 Installing ufw..."
    apt-get update && apt-get install -y ufw
fi

# 2. Reset UFW to safe default state
echo "🔄 Resetting old UFW rules..."
ufw --force reset

# 3. Set default policy: Deny all Ingress, allow Egress
echo "🔒 Applying Default Policy (Deny Ingress, Allow Egress)..."
ufw default deny incoming
ufw default allow outgoing

# 4. Allow all Loopback traffic (Internal Server)
echo "✅ Allowing Loopback (lo / 127.0.0.1)..."
ufw allow in on lo to any
ufw allow out on lo to any

# 5. Open secure SSH port (Preventing loss of server access)
echo "🔑 Opening SSH port (Port 22 & Port 2208)..."
ufw allow 22/tcp comment 'SSH Remote Admin'
ufw allow 2208/tcp comment 'Custom SSH Port'

# 6. Open Web Server ports (HTTP 80, HTTPS 443, App Dashboard 3000)
echo "🌐 Opening Web ports (80, 443, 3000)..."
ufw allow 80/tcp comment 'HTTP Web'
ufw allow 443/tcp comment 'HTTPS Web mTLS'
ufw allow 3000/tcp comment 'Cyber C2 Node.js Dashboard'

# 7. Lock down Redis Port 6379 (Only allow localhost 127.0.0.1)
echo "⛔ Locking down Redis Port 6379..."
# Allow 127.0.0.1 to connect to Redis
ufw allow from 127.0.0.1 to any port 6379 proto tcp comment 'Redis Localhost Only'
ufw allow from ::1 to any port 6379 proto tcp comment 'Redis IPv6 Localhost Only'
# Deny all Redis connections from external public IPs
ufw deny 6379/tcp comment 'Block External Redis'

# 8. Add Iptables Kernel-level Drop rule for Port 6379
echo "🛡️  Applying Iptables Layer for Port 6379..."
iptables -A INPUT -p tcp -s 127.0.0.1 --dport 6379 -j ACCEPT || true
iptables -A INPUT -p tcp --dport 6379 -i lo -j ACCEPT || true
iptables -A INPUT -p tcp --dport 6379 -j DROP || true

# 9. Enable UFW Firewall
echo "🚀 Enabling UFW Firewall..."
ufw --force enable

echo "======================================================="
echo "✅ FIREWALL CONFIGURATION SUCCESSFUL!"
echo "======================================================="
ufw status verbose
