# IPREPORT Setup & Configuration Guide

This project is an advanced IP tracking and Anti-DDoS telemetry dashboard integrated with Cloudflare and Telegram. Follow the instructions below to configure and run the server.

## Prerequisites
Before running the project, you must have the following installed:
1. **Node.js** (v18 or higher)
2. **Redis Server** (Used for rate-limiting, IP tracking, and high-performance caching)
3. **PM2** (For keeping the app running in the background)

---

## 1. Installation

**Step 1: Install Redis**
- **Ubuntu/Debian:** `sudo apt install redis-server` and start it with `sudo systemctl start redis`.
- **Windows:** You can use Memurai, WSL (Windows Subsystem for Linux), or Redis for Windows.

**Step 2: Install PM2**
PM2 is a production process manager for Node.js. Install it globally via npm:
```bash
npm install -g pm2
```

**Step 3: Install Project Dependencies**
Navigate to the project folder and install the required NPM packages:
```bash
npm install
```

---

## 2. Setting up `config.txt`
All configurations are managed in the `config.txt` file located in the root directory. You must fill in the correct keys for Cloudflare and Telegram to work properly.

### A. Admin & Server Configuration
- `PORT`: The port your server runs on (default: `3000`).
- `ADMIN_API_KEY`: A secure custom password you create. This is required to log into the web UI dashboard.

### B. Redis Configuration
- `REDIS_HOST`: Usually `127.0.0.1` if hosted on the same server.
- `REDIS_PORT`: Usually `6379`.
- `REDIS_PASSWORD`: Leave empty if your Redis server has no password.

### C. Cloudflare API Keys
To allow the server to automatically mitigate DDoS attacks via Cloudflare, you need to provide your Cloudflare credentials.

1. **`CLOUDFLARE_ZONE_ID` & `CLOUDFLARE_ACCOUNT_ID`**:
   - Log into your Cloudflare Dashboard.
   - Click on your website (domain).
   - Scroll down on the **Overview** page. Look at the bottom right sidebar under the "API" section to find your Zone ID and Account ID.
2. **`CLOUDFLARE_AUTH_EMAIL`**: The email address associated with your Cloudflare account.
3. **`CLOUDFLARE_API_KEY`**: 
   - Click "Get your API token" in the Cloudflare sidebar (or go to My Profile -> API Tokens).
   - Scroll down to "API Keys" and click **View** next to "Global API Key". Copy this and paste it into `config.txt`.

### D. Telegram Bot Integration
The server sends real-time attack telemetry and alerts to Telegram.

1. **`TELEGRAM_BOT_TOKEN`**:
   - Open Telegram and search for `@BotFather`.
   - Send the command `/newbot` and follow the steps to create a bot.
   - BotFather will give you an HTTP API Token (e.g., `123456:ABC-DEF1234...`). Paste this as the token.
2. **`TELEGRAM_CHAT_ID`**:
   - Send a message to your newly created bot.
   - Forward that message to `@userinfobot` to get your exact User ID (Chat ID). Paste this ID into the config.
3. **`TELEGRAM_BOT_PASSWORD`**:
   - Create a secure password here. When you message your bot to run administrative commands, it will ask you for this password to verify it is you.

---

## 3. Running the Server

### Option A: Production Mode with PM2 (Highly Recommended)
Using PM2 ensures that your application stays online 24/7 and automatically restarts if it crashes.

Run the following command to start the application:
```bash
pm2 start src/app.js --name "ipreport"
```
*(If you have an `ecosystem.config.js`, you can also just run `pm2 start ecosystem.config.js`)*

To monitor the logs and see if it's working:
```bash
pm2 logs ipreport
```

### Option B: Development/Testing Mode
If you do not want to install PM2 or simply want to test the app temporarily in your terminal, run:
```bash
node src/app.js
```
*(Note: If you close the terminal, the server will stop!)*

---

## 4. Usage Instructions
1. Ensure your Redis server is running.
2. Start the app using PM2 or Node.
3. Open your browser and navigate to `http://localhost:3000` (or your domain/server IP).
4. Enter the `ADMIN_API_KEY` when prompted to access the analytics dashboard.
5. Watch your Telegram bot for automated warnings whenever the request rate exceeds your `DDOS_NOTIFY_THRESHOLD_RPS`.