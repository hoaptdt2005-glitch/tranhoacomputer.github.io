const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const configPath = path.join(__dirname, '..', 'config.txt');

// Safe Default Configurations (Safe Fallback Defaults)
const defaultConfig = {
  NODE_ENV: process.env.NODE_ENV || 'production',
  PORT: 3000,
  USE_HTTPS: false,
  SSL_CERT_PATH: 'certs/origin.crt',
  SSL_KEY_PATH: 'certs/origin.key',
  CLOUDFLARE_CA_PATH: 'certs/cloudflare-origin-pull-ca.pem',
  ADMIN_API_KEY: '',
  REDIS_HOST: '127.0.0.1',
  REDIS_PORT: 6379,
  REDIS_PASSWORD: '',
  RATE_LIMIT_WINDOW_SEC: 60,
  RATE_LIMIT_MAX_REQUESTS: 50,
  RATE_LIMIT_BURST_MAX: 15,
  BAN_DURATION_SEC: 1800,
  TRACKER_TTL_SEC: 86400,
  EXCEL_EXPORT_PATH: 'data/ip_report.xlsx',
  IGNORE_IPS: '',
  TELEGRAM_BOT_TOKEN: '',
  TELEGRAM_CHAT_ID: '',
  TELEGRAM_BOT_PASSWORD: '',
  CLOUDFLARE_ZONE_ID: '',
  CLOUDFLARE_ACCOUNT_ID: '',
  CLOUDFLARE_API_TOKEN: '',
  CLOUDFLARE_AUTH_EMAIL: '',
  CLOUDFLARE_API_KEY: '',
  DDOS_NOTIFY_THRESHOLD_RPS: 10
};

let config = { ...defaultConfig };

// 1. Read from config.txt (if any)
try {
  if (fs.existsSync(configPath)) {
    const fileContent = fs.readFileSync(configPath, 'utf8');
    const lines = fileContent.split(/\r?\n/);
    
    lines.forEach(line => {
      const trimmedLine = line.trim();
      if (trimmedLine && !trimmedLine.startsWith('#') && !trimmedLine.startsWith('//')) {
        const separatorIndex = trimmedLine.indexOf('=');
        if (separatorIndex !== -1) {
          const key = trimmedLine.slice(0, separatorIndex).trim();
          const value = trimmedLine.slice(separatorIndex + 1).trim();
          
          if (value !== '') {
            const booleanKeys = ['USE_HTTPS'];
            const stringKeys = [
              'NODE_ENV',
              'SSL_CERT_PATH',
              'SSL_KEY_PATH',
              'CLOUDFLARE_CA_PATH',
              'ADMIN_API_KEY',
              'REDIS_HOST',
              'REDIS_PASSWORD',
              'EXCEL_EXPORT_PATH',
              'IGNORE_IPS',
              'TELEGRAM_BOT_TOKEN',
              'TELEGRAM_CHAT_ID',
              'TELEGRAM_BOT_PASSWORD',
              'CLOUDFLARE_ZONE_ID',
              'CLOUDFLARE_ACCOUNT_ID',
              'CLOUDFLARE_API_TOKEN',
              'CLOUDFLARE_AUTH_EMAIL',
              'CLOUDFLARE_API_KEY'
            ];

            if (booleanKeys.includes(key)) {
              config[key] = value.toLowerCase() === 'true';
            } else if (stringKeys.includes(key)) {
              config[key] = value;
            } else {
              const numValue = Number(value);
              config[key] = isNaN(numValue) ? value : numValue;
            }
          }
        }
      }
    });
  }
} catch (error) {
  console.error('[CONFIG ERROR] Error reading config.txt:', error.message);
}

// 2. PRIORITIZE ENVIRONMENT VARIABLES FROM .env and process.env (Overrides config.txt)
Object.keys(defaultConfig).forEach(key => {
  if (process.env[key] !== undefined && process.env[key] !== '') {
    const val = process.env[key];
    const booleanKeys = ['USE_HTTPS'];
    const stringKeys = [
      'NODE_ENV',
      'SSL_CERT_PATH',
      'SSL_KEY_PATH',
      'CLOUDFLARE_CA_PATH',
      'ADMIN_API_KEY',
      'REDIS_HOST',
      'REDIS_PASSWORD',
      'EXCEL_EXPORT_PATH',
      'IGNORE_IPS',
      'TELEGRAM_BOT_TOKEN',
      'TELEGRAM_CHAT_ID',
      'TELEGRAM_BOT_PASSWORD',
      'CLOUDFLARE_ZONE_ID',
      'CLOUDFLARE_ACCOUNT_ID',
      'CLOUDFLARE_API_TOKEN',
      'CLOUDFLARE_AUTH_EMAIL',
      'CLOUDFLARE_API_KEY'
    ];

    if (booleanKeys.includes(key)) {
      config[key] = String(val).toLowerCase() === 'true';
    } else if (stringKeys.includes(key)) {
      config[key] = String(val);
    } else {
      const num = Number(val);
      config[key] = isNaN(num) ? val : num;
    }
  }
});

module.exports = config;
