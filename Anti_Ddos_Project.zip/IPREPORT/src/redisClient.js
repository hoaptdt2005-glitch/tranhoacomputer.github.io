const Redis = require('ioredis');
const config = require('./configLoader');

const redisOptions = {
  host: config.REDIS_HOST || '127.0.0.1',
  port: Number(config.REDIS_PORT) || 6379,
  lazyConnect: false,
  enableOfflineQueue: true, // Allow temporary queue of commands while connecting / reconnecting
  maxRetriesPerRequest: 3,
  connectTimeout: 5000,
  retryStrategy(times) {
    const delay = Math.min(times * 150, 3000);
    return delay;
  }
};

if (config.REDIS_PASSWORD) {
  redisOptions.password = config.REDIS_PASSWORD;
}

const redis = new Redis(redisOptions);

// Catch connection errors to prevent app crash (Crash-resilient)
redis.on('error', (err) => {
  console.error('[REDIS ERROR] ❌ Redis connection error:', err.message);
});

redis.on('connect', () => {
  console.log(`[REDIS] ⚡ Successfully connected to Redis server at ${config.REDIS_HOST}:${config.REDIS_PORT}`);
});

redis.on('ready', () => {
  console.log('[REDIS] 🟢 Redis ready to execute commands.');
});

redis.on('reconnecting', (time) => {
  console.warn(`[REDIS] 🟡 Trying to reconnect in ${time}ms...`);
});

redis.on('close', () => {
  console.warn('[REDIS] ⚪ Redis connection closed.');
});

module.exports = redis;
