const config = require('../configLoader');

/**
 * Build Cloudflare API Authentication Headers
 */
function getCloudflareHeaders() {
  const headers = {
    'Content-Type': 'application/json'
  };

  if (config.CLOUDFLARE_API_TOKEN) {
    headers['Authorization'] = `Bearer ${config.CLOUDFLARE_API_TOKEN.trim()}`;
  } else if (config.CLOUDFLARE_AUTH_EMAIL && config.CLOUDFLARE_API_KEY) {
    headers['X-Auth-Email'] = config.CLOUDFLARE_AUTH_EMAIL.trim();
    headers['X-Auth-Key'] = config.CLOUDFLARE_API_KEY.trim();
  }

  return headers;
}

/**
 * Check if Cloudflare API credentials are configured
 */
function isCloudflareApiConfigured() {
  const hasAuth = Boolean(config.CLOUDFLARE_API_TOKEN || (config.CLOUDFLARE_AUTH_EMAIL && config.CLOUDFLARE_API_KEY));
  const hasZone = Boolean(config.CLOUDFLARE_ZONE_ID);
  return hasAuth && hasZone;
}

/**
 * Get Cloudflare Security Level Setting
 * GET https://api.cloudflare.com/client/v4/zones/{zone_id}/settings/security_level
 * @returns {Promise<{success: boolean, value?: string, raw?: Object, error?: string}>}
 */
async function getCloudflareSecurityLevel() {
  const zoneId = (config.CLOUDFLARE_ZONE_ID || 'your_zone_id_here').trim();

  if (!isCloudflareApiConfigured()) {
    return {
      success: false,
      error: 'CLOUDFLARE_API_TOKEN or CLOUDFLARE_AUTH_EMAIL + CLOUDFLARE_API_KEY is not configured in config.txt'
    };
  }

  const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/settings/security_level`;

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: getCloudflareHeaders()
    });

    const data = await response.json();

    if (data && data.success && data.result) {
      return {
        success: true,
        value: data.result.value,
        editable: data.result.editable,
        modifiedOn: data.result.modified_on,
        raw: data.result
      };
    } else {
      const errMsg = (data && data.errors && data.errors[0] && data.errors[0].message) || `HTTP ${response.status}`;
      return {
        success: false,
        error: errMsg,
        raw: data
      };
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * Change Cloudflare Security Level Setting
 * PATCH https://api.cloudflare.com/client/v4/zones/{zone_id}/settings/security_level
 * @param {'under_attack'|'high'|'medium'|'low'|'essentially_off'} level 
 * @returns {Promise<{success: boolean, value?: string, raw?: Object, error?: string}>}
 */
async function setCloudflareSecurityLevel(level = 'under_attack') {
  const zoneId = (config.CLOUDFLARE_ZONE_ID || 'your_zone_id_here').trim();

  if (!isCloudflareApiConfigured()) {
    return {
      success: false,
      error: 'CLOUDFLARE_API_TOKEN or CLOUDFLARE_AUTH_EMAIL + CLOUDFLARE_API_KEY is not configured in config.txt'
    };
  }

  const validLevels = ['under_attack', 'high', 'medium', 'low', 'essentially_off'];
  const targetLevel = String(level).toLowerCase().trim();

  if (!validLevels.includes(targetLevel)) {
    return {
      success: false,
      error: `Invalid security level "${level}". Supported: ${validLevels.join(', ')}`
    };
  }

  const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/settings/security_level`;

  try {
    const response = await fetch(url, {
      method: 'PATCH',
      headers: getCloudflareHeaders(),
      body: JSON.stringify({ value: targetLevel })
    });

    const data = await response.json();

    if (data && data.success && data.result) {
      return {
        success: true,
        value: data.result.value,
        modifiedOn: data.result.modified_on,
        raw: data.result
      };
    } else {
      const errMsg = (data && data.errors && data.errors[0] && data.errors[0].message) || `HTTP ${response.status}`;
      return {
        success: false,
        error: errMsg,
        raw: data
      };
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

module.exports = {
  isCloudflareApiConfigured,
  getCloudflareSecurityLevel,
  setCloudflareSecurityLevel
};
