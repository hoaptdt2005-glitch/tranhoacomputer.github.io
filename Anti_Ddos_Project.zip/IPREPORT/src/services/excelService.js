const ExcelJS = require('exceljs');
const path = require('path');
const fs = require('fs');
const redis = require('../redisClient');
const config = require('../configLoader');
const { isIgnoredIp } = require('../utils/serverPublicIp');

/**
 * Get absolute path of exported Excel file
 */
function getExcelFilePath() {
  const configuredPath = config.EXCEL_EXPORT_PATH || 'data/ip_report.xlsx';
  if (path.isAbsolute(configuredPath)) {
    return configuredPath;
  }
  return path.join(__dirname, '..', '..', configuredPath);
}

/**
 * Format timestamp to YYYY-MM-DD HH:mm:ss format
 */
function formatDateTime(timestamp) {
  if (!timestamp) return 'N/A';
  const num = Number(timestamp);
  if (isNaN(num) || num <= 0) return 'N/A';
  const d = new Date(num);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

/**
 * Read all IP data from Redis and export/overwrite Excel file
 * @returns {Promise<string>} Path of the written Excel file
 */
async function exportIpReportToExcel() {
  const filePath = getExcelFilePath();
  const dirPath = path.dirname(filePath);

  // 1. Automatically create directory if not exists
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }

  try {
    // 2. Collect list of IPs from Redis
    const ipSet = new Set();
    
    try {
      const trackedIps = await redis.smembers('tracked_ips_set');
      trackedIps.forEach(ip => {
        if (!isIgnoredIp(ip)) ipSet.add(ip);
      });
    } catch (e) {}

    try {
      const trackerKeys = await redis.keys('ip_tracker:*');
      trackerKeys.forEach(k => {
        const ip = k.replace('ip_tracker:', '');
        if (ip && !isIgnoredIp(ip)) ipSet.add(ip);
      });
    } catch (e) {}

    const ipList = Array.from(ipSet);

    // 3. Get detailed info of each IP via Redis Pipeline
    const ipDataList = [];
    if (ipList.length > 0) {
      const pipeline = redis.pipeline();
      ipList.forEach(ip => {
        pipeline.hgetall(`ip_tracker:${ip}`);
        pipeline.ttl(`blacklist:${ip}`);
      });

      const results = await pipeline.exec();
      const now = Date.now();

      for (let i = 0; i < ipList.length; i++) {
        const ip = ipList[i];
        const trackerRes = results[i * 2];
        const banTtlRes = results[i * 2 + 1];

        const trackerData = (trackerRes && !trackerRes[0]) ? (trackerRes[1] || {}) : {};
        const banTtl = (banTtlRes && !banTtlRes[0]) ? Number(banTtlRes[1]) : -2;

        const count = parseInt(trackerData.count || 0, 10);
        const firstSeen = trackerData.first_seen ? Number(trackerData.first_seen) : null;
        const lastSeen = trackerData.last_seen ? Number(trackerData.last_seen) : null;

        const isBanned = banTtl > -2;
        let banRemaining = 'N/A';
        if (isBanned) {
          banRemaining = banTtl > 0 ? `${banTtl}s` : 'Permanent';
        }

        const isActive = lastSeen && (now - lastSeen < 5 * 60 * 1000);

        ipDataList.push({
          ip,
          count,
          firstSeenRaw: firstSeen,
          lastSeenRaw: lastSeen,
          firstSeen: formatDateTime(firstSeen),
          lastSeen: formatDateTime(lastSeen),
          blacklistStatus: isBanned ? 'BANNED' : 'NORMAL',
          remainingBanTime: banRemaining,
          activityStatus: isActive ? 'Active' : 'Idle'
        });
      }
    }

    // Sort descending by Request count
    ipDataList.sort((a, b) => b.count - a.count);

    // 4. Initialize Workbook & Worksheet with ExcelJS
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'IP Shield & Real-time Security System';
    workbook.lastModifiedBy = 'Auto-Sync Service';
    workbook.created = new Date();
    workbook.modified = new Date();

    const worksheet = workbook.addWorksheet('IP Security Report', {
      views: [{ showGridLines: true }],
      properties: { tabColor: { argb: 'FF00FF66' } }
    });

    // Configure data columns
    worksheet.columns = [
      { header: 'IP Address', key: 'ip', width: 22 },
      { header: 'Request Count', key: 'count', width: 18 },
      { header: 'First Seen', key: 'firstSeen', width: 24 },
      { header: 'Last Seen', key: 'lastSeen', width: 24 },
      { header: 'Blacklist Status', key: 'blacklistStatus', width: 20 },
      { header: 'Remaining Ban Time', key: 'remainingBanTime', width: 22 },
      { header: 'Activity (5m)', key: 'activityStatus', width: 16 }
    ];

    // Format Header Row (Dark Cyber Slate)
    const headerRow = worksheet.getRow(1);
    headerRow.height = 28;
    headerRow.eachCell((cell) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FF0B132B' }
      };
      cell.font = {
        color: { argb: 'FFFFFFFF' },
        bold: true,
        size: 11
      };
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
      cell.border = {
        top: { style: 'thin', color: { argb: 'FF1C2541' } },
        left: { style: 'thin', color: { argb: 'FF1C2541' } },
        bottom: { style: 'medium', color: { argb: 'FF00FF66' } },
        right: { style: 'thin', color: { argb: 'FF1C2541' } }
      };
    });

    // Fill IP data rows
    let currentRowIndex = 2;
    ipDataList.forEach(data => {
      const row = worksheet.addRow(data);
      row.height = 22;

      row.getCell('ip').alignment = { vertical: 'middle', horizontal: 'left' };
      row.getCell('count').alignment = { vertical: 'middle', horizontal: 'right' };
      row.getCell('count').numFmt = '#,##0';
      row.getCell('firstSeen').alignment = { vertical: 'middle', horizontal: 'center' };
      row.getCell('lastSeen').alignment = { vertical: 'middle', horizontal: 'center' };
      row.getCell('blacklistStatus').alignment = { vertical: 'middle', horizontal: 'center' };
      row.getCell('remainingBanTime').alignment = { vertical: 'middle', horizontal: 'center' };
      row.getCell('activityStatus').alignment = { vertical: 'middle', horizontal: 'center' };

      if (data.blacklistStatus === 'BANNED') {
        row.getCell('blacklistStatus').font = { color: { argb: 'FFFF003C' }, bold: true };
        row.getCell('blacklistStatus').fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFFFEBEF' }
        };
      } else {
        row.getCell('blacklistStatus').font = { color: { argb: 'FF008744' }, bold: true };
      }

      if (data.activityStatus === 'Active') {
        row.getCell('activityStatus').font = { color: { argb: 'FF0077B6' }, bold: true };
      }

      row.eachCell((cell) => {
        cell.border = {
          top: { style: 'thin', color: { argb: 'FFE2E8F0' } },
          left: { style: 'thin', color: { argb: 'FFE2E8F0' } },
          bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } },
          right: { style: 'thin', color: { argb: 'FFE2E8F0' } }
        };
      });

      currentRowIndex++;
    });

    // Add Summary Row
    if (ipDataList.length > 0) {
      const summaryRow = worksheet.addRow({
        ip: `Total: ${ipDataList.length} IPs`,
        count: { formula: `=SUM(B2:B${currentRowIndex - 1})`, result: ipDataList.reduce((acc, cur) => acc + cur.count, 0) },
        firstSeen: '',
        lastSeen: '',
        blacklistStatus: `Banned: ${ipDataList.filter(i => i.blacklistStatus === 'BANNED').length}`,
        remainingBanTime: '',
        activityStatus: `Active: ${ipDataList.filter(i => i.activityStatus === 'Active').length}`
      });

      summaryRow.height = 26;
      summaryRow.font = { bold: true, size: 11, color: { argb: 'FF0B132B' } };
      summaryRow.getCell('count').numFmt = '#,##0';
      summaryRow.eachCell((cell) => {
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFF1F5F9' }
        };
        cell.border = {
          top: { style: 'medium', color: { argb: 'FF0B132B' } },
          bottom: { style: 'double', color: { argb: 'FF0B132B' } }
        };
      });
    }

    // 5. Atomic write with PID and Timestamp to prevent race conditions in PM2 Cluster
    const tempFilePath = `${filePath}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`;
    try {
      await workbook.xlsx.writeFile(tempFilePath);
      if (fs.existsSync(tempFilePath)) {
        fs.renameSync(tempFilePath, filePath);
      }
    } catch (writeErr) {
      if (fs.existsSync(tempFilePath)) {
        try { fs.unlinkSync(tempFilePath); } catch (e) {}
      }
      throw writeErr;
    }

    console.log(`[EXCEL SERVICE] 📊 Excel report synced: ${filePath} (${ipDataList.length} IPs)`);
    return filePath;
  } catch (error) {
    console.error('[EXCEL SERVICE ERROR] Error creating Excel file:', error.message);
    throw error;
  }
}

// Auto-sync periodically every 5 minutes on Master Worker
const isMasterWorker = !process.env.NODE_APP_INSTANCE || process.env.NODE_APP_INSTANCE === '0' || process.env.pm_id === '0';

if (isMasterWorker) {
  const AUTO_SYNC_INTERVAL_MS = 5 * 60 * 1000;
  setInterval(() => {
    exportIpReportToExcel().catch(err => {
      console.error('[EXCEL AUTO-SYNC ERROR]', err.message);
    });
  }, AUTO_SYNC_INTERVAL_MS);

  setTimeout(() => {
    exportIpReportToExcel().catch(() => {});
  }, 5000);
}

module.exports = {
  exportIpReportToExcel,
  getExcelFilePath
};
