const TelegramBotPackage = require('node-telegram-bot-api');
const TelegramBot = TelegramBotPackage.TelegramBot || TelegramBotPackage.default || TelegramBotPackage;
const { exec } = require('child_process');
const util = require('util');
const os = require('os');
const execPromise = util.promisify(exec);

const config = require('../configLoader');
const redis = require('../redisClient');
const { addOwnerIp, removeOwnerIp, getAllOwnerIps, getCachedPublicIp, isOwnerIp, isIgnoredIp } = require('../utils/serverPublicIp');
const { lookupIpGeo } = require('../utils/geoLookup');
const { getFullSystemMetrics } = require('../utils/systemInfo');
const { banSubnet24, unbanSubnet24, getAllBannedSubnets, normalizeSubnet24Cidr } = require('../utils/subnetManager');
const { generateForensicSnapshot, formatForensicsTelegramHtml } = require('../utils/forensicsCollector');

let bot = null;
const isMasterWorker = !process.env.NODE_APP_INSTANCE || process.env.NODE_APP_INSTANCE === '0' || process.env.pm_id === '0';

// Live DDoS Attack State
let currentAttackSession = null;
let monitorIntervalTimer = null;
let timedLockdownTimer = null;
let hardwareAlertTimer = null;
let digestTimer = null;
let lastCpuAlertTime = 0;

// In-Memory Set of Authenticated User IDs for 0ms ultra-fast lookup
const authenticatedUserIds = new Set();

// Valid Bot Commands registered with Telegram Menu Button
const BOT_COMMANDS = [
  { command: 'menu', description: '🎛️ C2 Control Panel' },
  { command: 'live', description: '📡 Live Radar: View active incoming IPs & live DDoS flooders' },
  { command: 'underattack', description: '🔥 JS Proof-of-Work Challenge: /underattack on|off' },
  { command: 'cflevel', description: '☁️ Cloudflare Security Level: /cflevel [level]' },
  { command: 'snapshot', description: '📸 Attack Snapshot & Forensic Report' },
  { command: 'blockcountry', description: '🌍 Block Country: /blockcountry CN RU' },
  { command: 'unblockcountry', description: '🌐 Unblock Country: /unblockcountry CN' },
  { command: 'countryrules', description: '🗺️ Active Blocked Countries List' },
  { command: 'bansubnet', description: '🚫 Ban Subnet /24: /bansubnet <ip/24>' },
  { command: 'unbansubnet', description: '🔓 Unban Subnet /24: /unbansubnet <ip/24>' },
  { command: 'subnets', description: '📋 List Active Banned Subnets' },
  { command: 'dropproxy', description: '🏢 Drop Datacenter/Cloud Proxies: /dropproxy on|off' },
  { command: 'autodigest', description: '📈 Automated Digest: /autodigest on|off' },
  { command: 'adduser', description: '👥 Add Admin ID: /adduser <telegram_id>' },
  { command: 'deluser', description: '❌ Remove Admin ID: /deluser <telegram_id>' },
  { command: 'users', description: '👥 List Authorized Admin IDs' },
  { command: 'auth', description: '🔑 Authenticate: /auth <password>' },
  { command: 'logout', description: '🔒 Revoke Current Session' },
  { command: 'whoami', description: '👤 View Auth Status & User ID' },
  { command: 'blockall', description: '🚨 Emergency Lockdown: /blockall [time]' },
  { command: 'unblockall', description: '🟢 Lift Emergency Lockdown' },
  { command: 'banall', description: '🚫 Ban All Active Clients (Excl. Owner)' },
  { command: 'unbanall', description: '🔓 Unban All Blacklisted IPs' },
  { command: 'whois', description: '🌍 IP Geo & ISP Lookup: /whois <ip>' },
  { command: 'sysinfo', description: '💻 Host CPU, RAM, Cluster Metrics' },
  { command: 'logs', description: '📜 Recent Security Event Logs' },
  { command: 'rules', description: '⚙️ Security Rules & Thresholds' },
  { command: 'setlimit', description: '🎯 Set Rate Limit: /setlimit <reqs>' },
  { command: 'setburst', description: '⚡ Set Burst Limit: /setburst <reqs>' },
  { command: 'setbandur', description: '⏱️ Set Ban Duration: /setbandur <time>' },
  { command: 'whitelist', description: '👑 Add Protected Owner IP: /whitelist <ip>' },
  { command: 'ownerlist', description: '👑 List Protected Owner IPs' },
  { command: 'stats', description: '📊 Real-time Traffic Telemetry' },
  { command: 'top', description: '🏆 Top Ingress Clients' },
  { command: 'banned', description: '⛔ Active Blacklisted IPs' },
  { command: 'inspect', description: '🔍 Inspect Target IP: /inspect <ip>' },
  { command: 'ban', description: '🚫 Ban Target IP: /ban <ip> [time] [reason]' },
  { command: 'unban', description: '🔓 Unban Target IP: /unban <ip>' },
  { command: 'flush', description: '🧹 Flush Sliding Rate Limit Counters' },
  { command: 'reload', description: '🔄 Hot Reload PM2 Cluster' },
  { command: 'export', description: '📁 Export & Download Excel Report' },
  { command: 'clear', description: '🗑️ Clear Ingress Client Records' },
  { command: 'ping', description: '🏓 Check Cluster Latency' }
];

/**
 * Check if Telegram Bot is configured
 */
function isTelegramConfigured() {
  return Boolean(config.TELEGRAM_BOT_TOKEN && config.TELEGRAM_CHAT_ID);
}

/**
 * Load authenticated users from Redis on startup
 */
async function loadAuthenticatedUsers() {
  try {
    const users = await redis.smembers('bot:authenticated_users');
    if (Array.isArray(users)) {
      users.forEach(u => authenticatedUserIds.add(String(u)));
      console.log(`[TELEGRAM AUTH] 🔐 Loaded ${users.length} authenticated admin session(s) from Redis.`);
    }
  } catch (err) {
    console.warn('[TELEGRAM AUTH] ⚠️ Failed to load auth users from Redis:', err.message);
  }
}

/**
 * Check if a user is authenticated
 */
async function isUserAuthenticated(userId) {
  const configuredPassword = (config.TELEGRAM_BOT_PASSWORD || config.ADMIN_API_KEY || '').trim();
  if (!configuredPassword) {
    return true;
  }

  const uId = String(userId);
  if (authenticatedUserIds.has(uId)) {
    return true;
  }

  try {
    const exists = await redis.sismember('bot:authenticated_users', uId);
    if (exists === 1) {
      authenticatedUserIds.add(uId);
      return true;
    }
  } catch (e) {}

  return false;
}

/**
 * Authenticate a user against TELEGRAM_BOT_PASSWORD with brute-force protection
 */
async function authenticateUser(userId, inputPassword) {
  const targetPassword = (config.TELEGRAM_BOT_PASSWORD || config.ADMIN_API_KEY || '').trim();
  const uId = String(userId);

  if (!targetPassword) {
    authenticatedUserIds.add(uId);
    await redis.sadd('bot:authenticated_users', uId).catch(() => {});
    return { success: true };
  }

  // 1. Check if user is locked out
  const lockoutTtl = await redis.ttl(`bot:lockout:${uId}`).catch(() => -2);
  if (lockoutTtl > 0) {
    return { success: false, locked: true, remainingSec: lockoutTtl };
  }

  // 2. Strict Password Verification
  const givenPass = String(inputPassword || '').trim();
  const isValid = givenPass.length > 0 && givenPass === targetPassword;

  if (isValid) {
    await redis.del(`bot:failed_attempts:${uId}`).catch(() => {});
    await redis.sadd('bot:authenticated_users', uId).catch(() => {});
    authenticatedUserIds.add(uId);
    console.log(`[TELEGRAM AUTH] 🔓 User ${uId} successfully authenticated as Administrator.`);
    return { success: true };
  } else {
    const attempts = await redis.incr(`bot:failed_attempts:${uId}`).catch(() => 1);
    await redis.expire(`bot:failed_attempts:${uId}`, 600).catch(() => {});

    console.warn(`[TELEGRAM AUTH] ❌ Failed login attempt from User ${uId} (Attempt: ${attempts}/5).`);

    if (attempts >= 5) {
      await redis.set(`bot:lockout:${uId}`, '1', 'EX', 900).catch(() => {});
      return { success: false, locked: true, remainingSec: 900 };
    }

    return { success: false, attempts, maxAttempts: 5 };
  }
}

/**
 * Revoke authentication session
 */
async function deauthenticateUser(userId) {
  const uId = String(userId);
  authenticatedUserIds.delete(uId);
  await redis.srem('bot:authenticated_users', uId).catch(() => {});
  console.log(`[TELEGRAM AUTH] 🔒 User ${uId} logged out.`);
}

/**
 * Parse human duration string (s, m, h, d, y, perm)
 */
function parseDuration(inputStr, defaultSec = 1800) {
  if (!inputStr) {
    return { seconds: defaultSec, human: formatDurationHuman(defaultSec), isPermanent: defaultSec <= 0 };
  }
  const str = inputStr.trim().toLowerCase();
  if (['perm', 'permanent', 'forever', 'inf', 'none', 'unlimited'].includes(str)) {
    return { seconds: 0, human: 'Indefinite / Permanent', isPermanent: true };
  }

  const match = str.match(/^(\d+)\s*([smhdy]?)$/);
  if (!match) {
    return { seconds: defaultSec, human: formatDurationHuman(defaultSec), isPermanent: defaultSec <= 0 };
  }

  const num = parseInt(match[1], 10);
  const unit = match[2] || 's';

  switch (unit) {
    case 's':
      return { seconds: num, human: `${num}s`, isPermanent: false };
    case 'm':
      return { seconds: num * 60, human: `${num}m`, isPermanent: false };
    case 'h':
      return { seconds: num * 3600, human: `${num}h`, isPermanent: false };
    case 'd':
      return { seconds: num * 86400, human: `${num}d`, isPermanent: false };
    case 'y':
      return { seconds: num * 31536000, human: `${num}y`, isPermanent: false };
    default:
      return { seconds: num, human: `${num}s`, isPermanent: false };
  }
}

/**
 * Human readable duration formatter
 */
function formatDurationHuman(seconds) {
  if (!seconds || seconds <= 0 || seconds >= 315360000) return 'Indefinite';
  if (seconds >= 31536000) return `${Math.round((seconds / 31536000) * 10) / 10}y`;
  if (seconds >= 86400) return `${Math.round((seconds / 86400) * 10) / 10}d`;
  if (seconds >= 3600) return `${Math.round((seconds / 3600) * 10) / 10}h`;
  if (seconds >= 60) return `${Math.round((seconds / 60) * 10) / 10}m`;
  return `${seconds}s`;
}

/**
 * Report command execution error to Admin
 */
function reportCommandError(chatId, commandName, error) {
  console.error(`[TELEGRAM C2 BUG] ❌ Command execution failed on '${commandName}':`, error.stack || error.message);
  const errorMsg = `
⚠️ <b>[COMMAND EXECUTION ERROR]</b>
━━━━━━━━━━━━━━━━━━━━
• <b>Command:</b> <code>${commandName}</code>
• <b>Error:</b> <code>${error.message || 'Unknown Error'}</code>
• <b>Time:</b> <code>${new Date().toISOString()}</code>
━━━━━━━━━━━━━━━━━━━━
🛠️ <i>Logged to server telemetry for debugging.</i>
  `.trim();
  bot.sendMessage(chatId, errorMsg, { parse_mode: 'HTML' });
}

/**
 * Activate Emergency Lockdown mode
 */
async function activateLockdown(durationSec = 0, activatedBy = 'Telegram Admin') {
  if (timedLockdownTimer) {
    clearTimeout(timedLockdownTimer);
    timedLockdownTimer = null;
  }

  if (durationSec > 0) {
    await redis.set('system:lockdown_mode', '1', 'EX', durationSec);
    timedLockdownTimer = setTimeout(async () => {
      await deactivateLockdown('Auto-unlock on timer expiry');
      if (bot && config.TELEGRAM_CHAT_ID) {
        bot.sendMessage(config.TELEGRAM_CHAT_ID, `
🟢 <b>[LOCKDOWN EXPIRED - TRAFFIC RESTORED]</b> 🟢
━━━━━━━━━━━━━━━━━━━━
✅ Emergency Lockdown timer (${formatDurationHuman(durationSec)}) has ended.
🌐 Public gateway reopened for legitimate traffic.
🕒 ${new Date().toISOString()}
━━━━━━━━━━━━━━━━━━━━
        `.trim(), { parse_mode: 'HTML' });
      }
    }, durationSec * 1000);
  } else {
    await redis.set('system:lockdown_mode', '1');
  }

  await redis.publish('anti_ddos_sync', 'LOCKDOWN:ON').catch(() => {});
  console.warn(`[SECURITY ACTION] 🚨 EMERGENCY LOCKDOWN ACTIVATED (${formatDurationHuman(durationSec)}) BY ${activatedBy}.`);
}

/**
 * Deactivate Emergency Lockdown mode
 */
async function deactivateLockdown(reason = 'Manual Unlock') {
  if (timedLockdownTimer) {
    clearTimeout(timedLockdownTimer);
    timedLockdownTimer = null;
  }
  await redis.del('system:lockdown_mode');
  await redis.publish('anti_ddos_sync', 'LOCKDOWN:OFF').catch(() => {});
  console.log(`[SECURITY ACTION] 🟢 EMERGENCY LOCKDOWN LIFTED (${reason}).`);
}

/**
 * Real-time Live DDoS Attack Monitor (Updates every 5 seconds)
 */
async function startDdosLiveMonitor() {
  if (!isMasterWorker || !isTelegramConfigured()) return;
  if (monitorIntervalTimer) clearInterval(monitorIntervalTimer);

  const CHECK_INTERVAL_SEC = 5;
  const DDOS_START_THRESHOLD_RPS = Number(config.DDOS_NOTIFY_THRESHOLD_RPS) || 8;

  monitorIntervalTimer = setInterval(async () => {
    try {
      const nowSec = Math.floor(Date.now() / 1000);
      const ddosKeys = [];
      const cleanKeys = [];

      for (let s = nowSec - CHECK_INTERVAL_SEC; s < nowSec; s++) {
        ddosKeys.push(`ddos_sec:${s}`);
        cleanKeys.push(`traffic_sec:${s}`);
      }

      const pipeline = redis.pipeline();
      ddosKeys.forEach(k => pipeline.get(k));
      cleanKeys.forEach(k => pipeline.get(k));
      pipeline.keys('blacklist:*');

      const results = await pipeline.exec();

      let ddosSum = 0;
      let cleanSum = 0;

      for (let i = 0; i < CHECK_INTERVAL_SEC; i++) {
        const val = results[i] && results[i][1] ? parseInt(results[i][1], 10) : 0;
        ddosSum += val;
      }
      for (let i = CHECK_INTERVAL_SEC; i < CHECK_INTERVAL_SEC * 2; i++) {
        const val = results[i] && results[i][1] ? parseInt(results[i][1], 10) : 0;
        cleanSum += val;
      }

      const bannedKeysRes = results[CHECK_INTERVAL_SEC * 2];
      const bannedCount = (bannedKeysRes && !bannedKeysRes[0] && Array.isArray(bannedKeysRes[1])) ? bannedKeysRes[1].length : 0;

      const currentDdosRps = Math.round((ddosSum / CHECK_INTERVAL_SEC) * 10) / 10;
      const currentCleanRps = Math.round((cleanSum / CHECK_INTERVAL_SEC) * 10) / 10;

      const activeBot = bot || initTelegramBot();
      if (!activeBot) return;

      // CASE 1: NEW ATTACK DETECTED
      if (!currentAttackSession && currentDdosRps >= DDOS_START_THRESHOLD_RPS) {
        currentAttackSession = {
          startTime: Date.now(),
          peakDdosRps: currentDdosRps,
          totalDroppedPackets: ddosSum,
          quietCycles: 0,
          messageId: null
        };

        const alertHtml = `
🚨 <b>[ALERT: DDOS ATTACK IN PROGRESS]</b> 🚨
━━━━━━━━━━━━━━━━━━━━
⚡ <b>Attack Rate:</b> <code>${currentDdosRps} Rq /s</code>
🔥 <b>Peak Rate:</b> <code>${currentDdosRps} Rq /s</code>
🌐 <b>Clean Traffic:</b> <code>${currentCleanRps} req/s</code>
🛡️ <b>Defense:</b> <b>AUTOMATIC FAST DROP ACTIVE</b>
⛔ <b>Blacklisted IPs:</b> <code>${bannedCount} IPs</code>
⏱️ <b>Attack Duration:</b> <code>${CHECK_INTERVAL_SEC}s</code>
━━━━━━━━━━━━━━━━━━━━
📡 <i>Live telemetry auto-updating every 5s...</i>
🕒 ${new Date().toISOString()}
        `.trim();

        try {
          const sent = await activeBot.sendMessage(config.TELEGRAM_CHAT_ID, alertHtml, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: {
              inline_keyboard: [
                [
                  { text: '🔥 UNDER ATTACK MODE', callback_data: 'cmd_underattack_on' },
                  { text: '🚨 LOCKDOWN 15m', callback_data: 'cmd_blockall_15m' }
                ],
                [
                  { text: '🚫 BAN ALL Botnets', callback_data: 'cmd_banall' },
                  { text: '📸 Attack Snapshot', callback_data: 'cmd_snapshot' }
                ]
              ]
            }
          });
          currentAttackSession.messageId = sent.message_id;
          console.warn(`[TELEGRAM DDOS ALERT] 🚨 Attack detected (${currentDdosRps} Rq /s).`);
        } catch (sendErr) {
          console.error('[TELEGRAM SEND ERROR]', sendErr.message);
        }
      }

      // CASE 2: ONGOING ATTACK (UPDATE IN-PLACE)
      else if (currentAttackSession && currentDdosRps >= 4) {
        currentAttackSession.totalDroppedPackets += ddosSum;
        if (currentDdosRps > currentAttackSession.peakDdosRps) {
          currentAttackSession.peakDdosRps = currentDdosRps;
        }
        currentAttackSession.quietCycles = 0;

        const durationSec = Math.round((Date.now() - currentAttackSession.startTime) / 1000);
        const updateHtml = `
🚨 <b>[DDOS ATTACK LIVE TELEMETRY]</b> 🚨
━━━━━━━━━━━━━━━━━━━━
⚡ <b>Current Attack Rate:</b> <code>${currentDdosRps} Rq /s</code>
🔥 <b>Peak Rate:</b> <code>${currentAttackSession.peakDdosRps} Rq /s</code>
🌐 <b>Clean Traffic:</b> <code>${currentCleanRps} req/s</code>
🛡️ <b>Total Dropped Packets:</b> <code>${currentAttackSession.totalDroppedPackets.toLocaleString()} requests</code>
⛔ <b>Blacklisted Botnets:</b> <code>${bannedCount} IPs</code>
⏱️ <b>Duration:</b> <code>${durationSec}s</code>
━━━━━━━━━━━━━━━━━━━━
📡 <i>Auto-updating live every 5s</i>
🕒 ${new Date().toISOString()}
        `.trim();

        if (currentAttackSession.messageId) {
          try {
            await activeBot.editMessageText(updateHtml, {
              chat_id: config.TELEGRAM_CHAT_ID,
              message_id: currentAttackSession.messageId,
              parse_mode: 'HTML',
              disable_web_page_preview: true,
              reply_markup: {
                inline_keyboard: [
                  [
                    { text: '🔥 UNDER ATTACK MODE', callback_data: 'cmd_underattack_on' },
                    { text: '🚨 LOCKDOWN 15m', callback_data: 'cmd_blockall_15m' }
                  ],
                  [
                    { text: '🚫 BAN ALL Botnets', callback_data: 'cmd_banall' },
                    { text: '📸 Attack Snapshot', callback_data: 'cmd_snapshot' }
                  ]
                ]
              }
            });
          } catch (editErr) {}
        }
      }

      // CASE 3: ATTACK MITIGATED & SYSTEM STABILIZED
      else if (currentAttackSession && currentDdosRps < 4) {
        currentAttackSession.quietCycles++;

        if (currentAttackSession.quietCycles >= 3) {
          const finalDurationSec = Math.round((Date.now() - currentAttackSession.startTime) / 1000);
          const finishHtml = `
✅ <b>[DDOS ATTACK MITIGATED & SUBSIDED]</b> ✅
━━━━━━━━━━━━━━━━━━━━
⏱️ <b>Total Attack Duration:</b> <code>${finalDurationSec}s</code>
🔥 <b>Peak Attack Intensity:</b> <code>${currentAttackSession.peakDdosRps} Rq /s</code>
🛡️ <b>Total Requests Blocked:</b> <code>${currentAttackSession.totalDroppedPackets.toLocaleString()}</code>
⛔ <b>Total Botnets Blacklisted:</b> <code>${bannedCount} IPs</code>
🟢 <b>System Health:</b> <b>STABLE & OPERATIONAL</b>
━━━━━━━━━━━━━━━━━━━━
🕒 ${new Date().toISOString()}
          `.trim();

          if (currentAttackSession.messageId) {
            try {
              await activeBot.editMessageText(finishHtml, {
                chat_id: config.TELEGRAM_CHAT_ID,
                message_id: currentAttackSession.messageId,
                parse_mode: 'HTML'
              });
            } catch (finishErr) {
              await activeBot.sendMessage(config.TELEGRAM_CHAT_ID, finishHtml, { parse_mode: 'HTML' });
            }
          }

          console.log(`[TELEGRAM DDOS ALERT] ✅ Attack ended after ${finalDurationSec}s.`);
          currentAttackSession = null;
        }
      }
    } catch (loopErr) {
      console.error('[DDOS MONITOR ERROR]', loopErr.message);
    }
  }, CHECK_INTERVAL_SEC * 1000);
}

/**
 * Background Hardware Overload Monitor (Alerts if CPU > 85% or RAM > 90%)
 */
function startHardwareMonitor() {
  if (!isMasterWorker || !isTelegramConfigured()) return;
  if (hardwareAlertTimer) clearInterval(hardwareAlertTimer);

  hardwareAlertTimer = setInterval(async () => {
    try {
      const now = Date.now();
      if (now - lastCpuAlertTime < 15 * 60 * 1000) return; // Rate limit alerts to once every 15m

      const totalMem = os.totalmem();
      const freeMem = os.freemem();
      const memPercent = Math.round(((totalMem - freeMem) / totalMem) * 100);
      const cpus = os.cpus();
      const load1m = os.loadavg()[0];
      const loadPercent = Math.round((load1m / cpus.length) * 100);

      if (memPercent >= 92 || loadPercent >= 90) {
        lastCpuAlertTime = now;
        const alertText = `
⚠️ <b>[HARDWARE OVERLOAD WARNING]</b> ⚠️
━━━━━━━━━━━━━━━━━━━━
🖥️ <b>Host CPU Load:</b> <code>${loadPercent}%</code> (${load1m.toFixed(2)} on ${cpus.length} Cores)
🧠 <b>Memory (RAM):</b> <code>${memPercent}%</code> (${(freeMem / 1048576).toFixed(0)} MB free)
⚡ <b>Cluster Status:</b> PM2 Cluster Under Heavy Load
━━━━━━━━━━━━━━━━━━━━
💡 <i>Consider enabling <code>/underattack on</code> or <code>/blockall 15m</code> to shed traffic load.</i>
        `.trim();
        bot.sendMessage(config.TELEGRAM_CHAT_ID, alertText, { parse_mode: 'HTML' });
      }
    } catch (e) {}
  }, 20000);
}

/**
 * Background Automated Scheduled Telemetry Digest (Every 6h / 24h)
 */
function startScheduledDigest() {
  if (!isMasterWorker || !isTelegramConfigured()) return;
  if (digestTimer) clearInterval(digestTimer);

  digestTimer = setInterval(async () => {
    try {
      const isEnabled = (await redis.get('system:autodigest_enabled')) === '1';
      if (!isEnabled) return;

      const snap = await generateForensicSnapshot();
      const digestText = `
📈 <b>[SCHEDULED TELEMETRY DIGEST]</b> 📈
━━━━━━━━━━━━━━━━━━━━
📊 <b>Active Endpoints:</b> <code>${snap.totalTrackedEndpoints}</code>
⛔ <b>Blacklisted IPs:</b> <code>${snap.activeBlacklistedIps}</code>
🛡️ <b>Recent Incidents:</b> <code>${snap.totalRecentIncidents}</code>
🕒 <b>Report Time:</b> <code>${new Date().toISOString()}</code>
━━━━━━━━━━━━━━━━━━━━
<i>Automatic digest broadcast active. Toggle with <code>/autodigest off</code>.</i>
      `.trim();
      bot.sendMessage(config.TELEGRAM_CHAT_ID, digestText, { parse_mode: 'HTML' });
    } catch (e) {}
  }, 6 * 60 * 60 * 1000);
}

/**
 * Return concise, beautifully styled C2 Menu HTML
 */
function getMenuHtml() {
  return `
╔══════════════════════════════════╗
║  🛡️ <b>CYBER C2 DEFENDER • OPS V3.5</b>  ║
╚══════════════════════════════════╝

╭─ 🎛️ <b>DEFENSE CONTROL MATRIX</b> ──────────
│ 📡 <b>Live Radar:</b>   <code>/live</code>
│ 🔥 <b>Anti-Bot PoW:</b> <code>/underattack on|off</code>
│ ☁️ <b>Cloudflare:</b>   <code>/cflevel &lt;level&gt;</code>
│ 📸 <b>Forensics:</b>    <code>/snapshot</code>
│ 🏢 <b>Drop Proxies:</b> <code>/dropproxy on|off</code>
│ 🌍 <b>Geo-Defense:</b>   <code>/blockcountry &lt;CC&gt;</code>
│ 🚫 <b>Subnet /24:</b>    <code>/bansubnet &lt;cidr&gt;</code>
│ 🚨 <b>Emergency:</b>     <code>/blockall</code> | <code>/banall</code>
│ 📊 <b>Telemetry:</b>     <code>/stats</code> | <code>/top</code> | <code>/sysinfo</code>
│ ⚙️ <b>Rules & Ban:</b>   <code>/rules</code> | <code>/setlimit</code> | <code>/setburst</code>
╰──────────────────────────────────
💡 <i>Tap any quick-action button below or send a command:</i>
  `.trim();
}

/**
 * Return beautifully organized Inline Keyboard for C2 Menu
 */
function getMenuInlineKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: '📡 LIVE RADAR & DDOS', callback_data: 'cmd_live' },
        { text: '🔥 UNDER ATTACK', callback_data: 'cmd_underattack_prompt' }
      ],
      [
        { text: '☁️ CLOUDFLARE EDGE', callback_data: 'cmd_cf_menu' },
        { text: '📸 Threat Snapshot', callback_data: 'cmd_snapshot' }
      ],
      [
        { text: '🏢 Drop Cloud Proxies', callback_data: 'cmd_dropproxy_toggle' },
        { text: '🗺️ Geo-Blocked', callback_data: 'cmd_countryrules' }
      ],
      [
        { text: '🚨 LOCKDOWN 15M', callback_data: 'cmd_blockall_15m' },
        { text: '🟢 LIFT LOCKDOWN', callback_data: 'cmd_unblockall' }
      ],
      [
        { text: '🚫 BAN ALL Foreign', callback_data: 'cmd_banall' },
        { text: '🔓 UNBAN ALL IPs', callback_data: 'cmd_unbanall' }
      ],
      [
        { text: '📊 Live Telemetry', callback_data: 'cmd_stats' },
        { text: '🏆 Top Ingress IPs', callback_data: 'cmd_top' }
      ],
      [
        { text: '💻 Host Metrics', callback_data: 'cmd_sysinfo' },
        { text: '📜 Security Logs', callback_data: 'cmd_logs' }
      ],
      [
        { text: '⚙️ Defense Rules', callback_data: 'cmd_rules' },
        { text: '👑 Owner Whitelist', callback_data: 'cmd_ownerlist' }
      ],
      [
        { text: '📁 Export Excel', callback_data: 'cmd_export' },
        { text: '🔄 Reload PM2 Cluster', callback_data: 'cmd_reload' }
      ]
    ]
  };
}

const { getCloudflareSecurityLevel, setCloudflareSecurityLevel, isCloudflareApiConfigured } = require('./cloudflareService');

// ================= HANDLER FUNCTIONS FOR ADVANCED COMMANDS =================

async function handleUnderAttack(chatId, args) {
  const mode = (args[0] || '').toLowerCase();
  const current = (await redis.get('system:under_attack_mode')) === '1';

  let newState = !current;
  if (mode === 'on' || mode === 'enable') newState = true;
  if (mode === 'off' || mode === 'disable') newState = false;

  let cfStatusMsg = '';

  if (newState) {
    await redis.set('system:under_attack_mode', '1');
    await redis.publish('anti_ddos_sync', 'CHALLENGE:ON').catch(() => {});

    // Sync with Cloudflare API v4
    if (isCloudflareApiConfigured()) {
      const cfRes = await setCloudflareSecurityLevel('under_attack');
      if (cfRes.success) {
        cfStatusMsg = `\n☁️ <b>Cloudflare Edge:</b> <code>UNDER_ATTACK (Active)</code>`;
      } else {
        cfStatusMsg = `\n☁️ <b>Cloudflare API:</b> ⚠️ <i>${cfRes.error}</i>`;
      }
    } else {
      cfStatusMsg = `\n☁️ <b>Cloudflare Edge:</b> <i>(Add CLOUDFLARE_API_TOKEN in config.txt to auto-sync)</i>`;
    }

    bot.sendMessage(chatId, `
🔥 <b>[UNDER ATTACK MODE ACTIVATED]</b> 🔥
━━━━━━━━━━━━━━━━━━━━
🛡️ <b>Local Defense:</b> <b>JS Proof-of-Work Challenge (0.1s PoW)</b>
🎯 <b>Target:</b> All incoming client browsers receive verification challenge.
🚫 <b>Proxy & Bot Killer:</b> 100% of headless scripts (Python, Go, cURL, raw sockets) are dropped!${cfStatusMsg}
🕒 <b>Status:</b> <b>ACTIVE ACROSS 12 WORKERS + CLOUDFLARE EDGE</b>
━━━━━━━━━━━━━━━━━━━━
<i>To disable, run <code>/underattack off</code>.</i>
    `.trim(), {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [[{ text: '🟢 Turn OFF Under Attack Mode', callback_data: 'cmd_underattack_off' }]]
      }
    });
  } else {
    await redis.del('system:under_attack_mode');
    await redis.publish('anti_ddos_sync', 'CHALLENGE:OFF').catch(() => {});

    // Sync with Cloudflare API v4
    if (isCloudflareApiConfigured()) {
      const cfRes = await setCloudflareSecurityLevel('medium');
      if (cfRes.success) {
        cfStatusMsg = `\n☁️ <b>Cloudflare Edge:</b> <code>MEDIUM (Normal)</code>`;
      } else {
        cfStatusMsg = `\n☁️ <b>Cloudflare API:</b> ⚠️ <i>${cfRes.error}</i>`;
      }
    }

    bot.sendMessage(chatId, `
🟢 <b>[UNDER ATTACK MODE DEACTIVATED]</b> 🟢
━━━━━━━━━━━━━━━━━━━━
✅ Standard traffic flow restored (JS Challenge disabled).${cfStatusMsg}
🛡️ Multi-tier rate limiting & exploit protection active.
🕒 ${new Date().toISOString()}
━━━━━━━━━━━━━━━━━━━━
    `.trim(), { parse_mode: 'HTML' });
  }
}

async function handleCloudflareLevel(chatId, args) {
  const targetLevel = (args[0] || '').toLowerCase().trim();

  if (!isCloudflareApiConfigured()) {
    return bot.sendMessage(chatId, `
☁️ <b>[CLOUDFLARE API INTEGRATION]</b>
━━━━━━━━━━━━━━━━━━━━
⚠️ <b>Missing API Credentials:</b>
Please set <code>CLOUDFLARE_API_TOKEN</code> (or <code>CLOUDFLARE_AUTH_EMAIL</code> + <code>CLOUDFLARE_API_KEY</code>) in <code>config.txt</code> to enable Cloudflare Edge control.
• <b>Zone ID:</b> <code>${config.CLOUDFLARE_ZONE_ID || 'your_zone_id_here'}</code>
━━━━━━━━━━━━━━━━━━━━
    `.trim(), { parse_mode: 'HTML' });
  }

  if (!targetLevel) {
    const sent = await bot.sendMessage(chatId, '☁️ Querying Cloudflare API for current Security Level...');
    const result = await getCloudflareSecurityLevel();

    if (result.success) {
      const isUnderAttack = result.value === 'under_attack';
      bot.editMessageText(`
☁️ <b>[CLOUDFLARE SECURITY LEVEL]</b> ☁️
━━━━━━━━━━━━━━━━━━━━
🛡️ <b>Current Level:</b> <b><code>${(result.value || 'unknown').toUpperCase()}</code></b> ${isUnderAttack ? '🔥' : '🟢'}
🆔 <b>Zone ID:</b> <code>${config.CLOUDFLARE_ZONE_ID}</code>
✏️ <b>Editable:</b> <code>${result.editable ? 'Yes' : 'No'}</code>
🕒 <b>Modified On:</b> <code>${result.modifiedOn || 'N/A'}</code>
━━━━━━━━━━━━━━━━━━━━
💡 <b>Change Level Syntax:</b>
• <code>/cflevel under_attack</code> (Maximum Defense)
• <code>/cflevel high</code>
• <code>/cflevel medium</code> (Default)
• <code>/cflevel low</code>
• <code>/cflevel essentially_off</code>
      `.trim(), {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🔥 Set UNDER ATTACK', callback_data: 'cmd_cf_under_attack' },
              { text: '🛡️ Set HIGH', callback_data: 'cmd_cf_high' }
            ],
            [
              { text: '🟢 Set MEDIUM', callback_data: 'cmd_cf_medium' },
              { text: '⚪ Set LOW', callback_data: 'cmd_cf_low' }
            ]
          ]
        }
      });
    } else {
      bot.editMessageText(`❌ <b>[CLOUDFLARE API ERROR]</b>\n${result.error}`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: 'HTML'
      });
    }
    return;
  }

  const sent = await bot.sendMessage(chatId, `☁️ Patching Cloudflare Security Level to <code>${targetLevel}</code>...`, { parse_mode: 'HTML' });
  const patchRes = await setCloudflareSecurityLevel(targetLevel);

  if (patchRes.success) {
    if (targetLevel === 'under_attack') {
      await redis.set('system:under_attack_mode', '1');
      await redis.publish('anti_ddos_sync', 'CHALLENGE:ON').catch(() => {});
    } else {
      await redis.del('system:under_attack_mode');
      await redis.publish('anti_ddos_sync', 'CHALLENGE:OFF').catch(() => {});
    }

    bot.editMessageText(`
✅ <b>[CLOUDFLARE SECURITY LEVEL UPDATED]</b> ✅
━━━━━━━━━━━━━━━━━━━━
☁️ <b>New Security Level:</b> <b><code>${(patchRes.value || targetLevel).toUpperCase()}</code></b>
🆔 <b>Zone ID:</b> <code>${config.CLOUDFLARE_ZONE_ID}</code>
🕒 <b>Modified On:</b> <code>${patchRes.modifiedOn || new Date().toISOString()}</code>
🛡️ Synced with local Anti-DDoS engine across 12 Workers!
━━━━━━━━━━━━━━━━━━━━
    `.trim(), {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: 'HTML'
    });
  } else {
    bot.editMessageText(`❌ <b>[CLOUDFLARE PATCH FAILED]</b>\n${patchRes.error}`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: 'HTML'
    });
  }
}

async function handleSnapshot(chatId) {
  const sent = await bot.sendMessage(chatId, '📸 Analyzing real-time telemetry and generating forensic snapshot...');
  const snapshot = await generateForensicSnapshot();
  const html = formatForensicsTelegramHtml(snapshot);

  bot.editMessageText(html, {
    chat_id: chatId,
    message_id: sent.message_id,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '🔄 Refresh Snapshot', callback_data: 'cmd_snapshot' },
          { text: '🔥 Enable JS Challenge', callback_data: 'cmd_underattack_on' }
        ]
      ]
    }
  });
}

async function handleBlockCountry(chatId, args) {
  if (args.length === 0) {
    return bot.sendMessage(chatId, `
⚠️ <b>[MISSING COUNTRY CODE]</b>
━━━━━━━━━━━━━━━━━━━━
👉 <b>Syntax:</b> <code>/blockcountry &lt;CC1&gt; [CC2] [CC3]...</code>
<i>Example:</i> <code>/blockcountry CN RU BR</code>
<i>(Blocks 100% ingress from specified ISO 2-letter country codes)</i>
    `.trim(), { parse_mode: 'HTML' });
  }

  const countries = args.map(c => c.toUpperCase().trim()).filter(c => c.length === 2);
  if (countries.length === 0) {
    return bot.sendMessage(chatId, '⚠️ Please provide valid 2-letter ISO country codes (e.g. `CN`, `RU`, `US`).', { parse_mode: 'HTML' });
  }

  const pipeline = redis.pipeline();
  countries.forEach(cc => {
    pipeline.sadd('system:blocked_countries', cc);
    pipeline.publish('anti_ddos_sync', `BLOCK_COUNTRY:${cc}`);
  });
  await pipeline.exec();

  bot.sendMessage(chatId, `
🌍 <b>[GEO-BLOCKING ACTIVATED]</b> 🌍
━━━━━━━━━━━━━━━━━━━━
⛔ <b>Blocked Countries:</b> <code>${countries.join(', ')}</code>
🛡️ All traffic from these countries is now dropped at 0ms!
🕒 Synced across 12 PM2 Workers.
━━━━━━━━━━━━━━━━━━━━
<i>View active blocks: <code>/countryrules</code> | Unblock: <code>/unblockcountry &lt;CC&gt;</code></i>
  `.trim(), { parse_mode: 'HTML' });
}

async function handleUnblockCountry(chatId, args) {
  const target = (args[0] || '').toUpperCase().trim();
  if (!target) {
    return bot.sendMessage(chatId, '👉 <b>Syntax:</b> <code>/unblockcountry &lt;CC&gt;</code> (or <code>/unblockcountry all</code>)', { parse_mode: 'HTML' });
  }

  if (target === 'ALL' || target === '*') {
    await redis.del('system:blocked_countries');
    await redis.publish('anti_ddos_sync', 'UNBLOCK_COUNTRY:*').catch(() => {});
    return bot.sendMessage(chatId, '🌐 <b>[ALL COUNTRY BLOCKS LIFTED]</b>\nGeo-blocking rules cleared. International traffic restored.', { parse_mode: 'HTML' });
  }

  await redis.srem('system:blocked_countries', target);
  await redis.publish('anti_ddos_sync', `UNBLOCK_COUNTRY:${target}`).catch(() => {});
  bot.sendMessage(chatId, `🌐 <b>[COUNTRY UNBLOCKED]</b>\nTraffic from <code>${target}</code> restored.`, { parse_mode: 'HTML' });
}

async function handleCountryRules(chatId) {
  const list = await redis.smembers('system:blocked_countries');
  const countries = Array.isArray(list) ? list : [];

  let text = `🗺️ <b>[ACTIVE GEO-BLOCKING RULES (${countries.length})]</b> 🗺️\n━━━━━━━━━━━━━━━━━━━━\n`;
  if (countries.length === 0) {
    text += `• <i>No countries currently blocked. All global traffic permitted.</i>\n`;
  } else {
    countries.forEach(cc => {
      text += `• ⛔ <b>${cc}</b> (Blocked at 0ms Drop)\n`;
    });
  }
  text += `━━━━━━━━━━━━━━━━━━━━\n<i>Add: <code>/blockcountry &lt;CC&gt;</code> | Remove: <code>/unblockcountry &lt;CC&gt;</code></i>`;

  bot.sendMessage(chatId, text, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: countries.length > 0 ? [[{ text: '🌐 Unblock All Countries', callback_data: 'cmd_unblockcountry_all' }]] : []
    }
  });
}

async function handleBanSubnet(chatId, args) {
  const input = (args[0] || '').trim();
  if (!input) {
    return bot.sendMessage(chatId, `
⚠️ <b>[MISSING SUBGRADE / IP]</b>
━━━━━━━━━━━━━━━━━━━━
👉 <b>Syntax:</b> <code>/bansubnet &lt;ip/24&gt;</code>
<i>Example:</i> <code>/bansubnet 45.33.32.0/24</code> or <code>/bansubnet 45.33.32.1</code>
<i>(Bans all 254 IPs within the /24 subnet block)</i>
    `.trim(), { parse_mode: 'HTML' });
  }

  try {
    const result = await banSubnet24(input);
    bot.sendMessage(chatId, `
🚫 <b>[SUBNET /24 BANNED SUCCESSFULLY]</b> 🚫
━━━━━━━━━━━━━━━━━━━━
⛔ <b>Banned CIDR:</b> <code>${result.cidr}</code> (254 IPs)
🛡️ <b>Scope:</b> 0ms In-Memory CIDR Drop across 12 Workers
🕒 ${new Date().toISOString()}
━━━━━━━━━━━━━━━━━━━━
    `.trim(), { parse_mode: 'HTML' });
  } catch (err) {
    bot.sendMessage(chatId, `❌ Failed to ban subnet: ${err.message}`);
  }
}

async function handleUnbanSubnet(chatId, args) {
  const input = (args[0] || '').trim();
  if (!input) {
    return bot.sendMessage(chatId, '👉 <b>Syntax:</b> <code>/unbansubnet &lt;ip/24&gt;</code>', { parse_mode: 'HTML' });
  }

  try {
    const result = await unbanSubnet24(input);
    bot.sendMessage(chatId, `✅ <b>[SUBNET UNBANNED]</b>\nSubnet <code>${result.cidr}</code> removed from blacklist.`, { parse_mode: 'HTML' });
  } catch (err) {
    bot.sendMessage(chatId, `❌ Failed to unban subnet: ${err.message}`);
  }
}

async function handleSubnets(chatId) {
  const list = await getAllBannedSubnets();
  let text = `📋 <b>[ACTIVE BANNED SUBNETS /24 (${list.length})]</b> 📋\n━━━━━━━━━━━━━━━━━━━━\n`;
  if (list.length === 0) {
    text += `• <i>No subnets currently blacklisted.</i>\n`;
  } else {
    list.forEach(cidr => {
      text += `• ⛔ <code>${cidr}</code> (254 IPs dropped)\n`;
    });
  }
  text += `━━━━━━━━━━━━━━━━━━━━\n<i>Ban: <code>/bansubnet &lt;ip/24&gt;</code> | Unban: <code>/unbansubnet &lt;ip/24&gt;</code></i>`;
  bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
}

async function handleDropProxy(chatId, args) {
  const mode = (args[0] || '').toLowerCase();
  const current = (await redis.get('system:drop_datacenter_proxies')) === '1';

  let newState = !current;
  if (mode === 'on' || mode === 'enable') newState = true;
  if (mode === 'off' || mode === 'disable') newState = false;

  if (newState) {
    await redis.set('system:drop_datacenter_proxies', '1');
    await redis.publish('anti_ddos_sync', 'DROP_PROXY:ON').catch(() => {});
    bot.sendMessage(chatId, `
🏢 <b>[DATACENTER & CLOUD PROXY DROP ACTIVATED]</b> 🏢
━━━━━━━━━━━━━━━━━━━━
🛡️ <b>Filtered Networks:</b> AWS, DigitalOcean, Hetzner, OVH, Vultr, Linode, M247, Tor, Hosting ASNs.
🚫 Connections from cloud VPS botnets are now automatically dropped!
━━━━━━━━━━━━━━━━━━━━
<i>To disable, run <code>/dropproxy off</code>.</i>
    `.trim(), { parse_mode: 'HTML' });
  } else {
    await redis.del('system:drop_datacenter_proxies');
    await redis.publish('anti_ddos_sync', 'DROP_PROXY:OFF').catch(() => {});
    bot.sendMessage(chatId, `🟢 <b>[DATACENTER PROXY DROP DEACTIVATED]</b>\nCloud and hosting network traffic allowed.`, { parse_mode: 'HTML' });
  }
}

async function handleAutoDigest(chatId, args) {
  const mode = (args[0] || '').toLowerCase();
  const current = (await redis.get('system:autodigest_enabled')) === '1';

  let newState = !current;
  if (mode === 'on' || mode === 'enable') newState = true;
  if (mode === 'off' || mode === 'disable') newState = false;

  if (newState) {
    await redis.set('system:autodigest_enabled', '1');
    bot.sendMessage(chatId, `📈 <b>[AUTOMATED TELEMETRY DIGEST ENABLED]</b>\nBot will broadcast health & traffic summaries every 6 hours!`, { parse_mode: 'HTML' });
  } else {
    await redis.del('system:autodigest_enabled');
    bot.sendMessage(chatId, `🟢 <b>[AUTOMATED TELEMETRY DIGEST DISABLED]</b>`, { parse_mode: 'HTML' });
  }
}

async function handleAddUser(chatId, args) {
  const targetId = (args[0] || '').trim();
  if (!targetId || isNaN(Number(targetId))) {
    return bot.sendMessage(chatId, '👉 <b>Syntax:</b> <code>/adduser &lt;telegram_user_id&gt;</code>\n<i>Example:</i> <code>/adduser 123456789</code>', { parse_mode: 'HTML' });
  }

  await redis.sadd('bot:authenticated_users', targetId);
  authenticatedUserIds.add(targetId);
  bot.sendMessage(chatId, `👥 <b>[ADMIN USER AUTHORIZED]</b>\nTelegram User ID <code>${targetId}</code> granted full C2 administrator privileges!`, { parse_mode: 'HTML' });
}

async function handleDelUser(chatId, args) {
  const targetId = (args[0] || '').trim();
  if (!targetId) {
    return bot.sendMessage(chatId, '👉 <b>Syntax:</b> <code>/deluser &lt;telegram_user_id&gt;</code>', { parse_mode: 'HTML' });
  }

  await redis.srem('bot:authenticated_users', targetId);
  authenticatedUserIds.delete(targetId);
  bot.sendMessage(chatId, `❌ <b>[ADMIN USER REVOKED]</b>\nTelegram User ID <code>${targetId}</code> session revoked.`, { parse_mode: 'HTML' });
}

async function handleUsers(chatId) {
  const list = await redis.smembers('bot:authenticated_users');
  let text = `👥 <b>[AUTHORIZED C2 ADMINISTRATORS (${list.length})]</b> 👥\n━━━━━━━━━━━━━━━━━━━━\n`;
  list.forEach(id => {
    text += `• <code>${id}</code> (Full Admin Access)\n`;
  });
  text += `━━━━━━━━━━━━━━━━━━━━\n<i>Add: <code>/adduser &lt;id&gt;</code> | Remove: <code>/deluser &lt;id&gt;</code></i>`;
  bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
}

// ================= ORIGINAL CORE HANDLERS =================

async function handleMenu(chatId) {
  bot.sendMessage(chatId, getMenuHtml(), {
    parse_mode: 'HTML',
    reply_markup: getMenuInlineKeyboard()
  });
}

async function handleBlockAll(chatId, args) {
  const arg = (args[0] || '').toLowerCase();
  if (arg === 'off') {
    await deactivateLockdown('Telegram Admin');
    return bot.sendMessage(chatId, `
🟢 <b>[EMERGENCY LOCKDOWN LIFTED]</b> 🟢
━━━━━━━━━━━━━━━━━━━━
✅ <b>Status:</b> <b>PUBLIC GATEWAY REOPENED (NORMAL TRAFFIC ACTIVE)</b>
🛡️ Anti-DDoS and Rate Limiting operational.
🕒 ${new Date().toISOString()}
━━━━━━━━━━━━━━━━━━━━
    `.trim(), { parse_mode: 'HTML' });
  }

  const { seconds, human } = parseDuration(arg, 0);
  await activateLockdown(seconds, 'Telegram /blockall');

  const lockdownText = `
🚨 <b>[EMERGENCY LOCKDOWN ACTIVATED]</b> 🚨
━━━━━━━━━━━━━━━━━━━━
⛔ <b>Status:</b> <b>100% PUBLIC INGRESS CLOSED (DROP ALL AT 0ms)</b>
⏱️ <b>Duration:</b> <code>${human}</code>
🛡️ <b>Drop Latency:</b> <code>0ms Fast Drop (0% CPU Load)</code>
🕒 <b>Activated:</b> ${new Date().toISOString()}
━━━━━━━━━━━━━━━━━━━━
<i>To restore traffic, tap below or run <code>/unblockall</code>.</i>
  `.trim();

  bot.sendMessage(chatId, lockdownText, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [{ text: '🟢 LIFT LOCKDOWN (RESTORE TRAFFIC)', callback_data: 'cmd_unblockall' }],
        [
          { text: '⏱️ Lockdown 15m', callback_data: 'cmd_blockall_15m' },
          { text: '⏱️ Lockdown 1h', callback_data: 'cmd_blockall_1h' }
        ]
      ]
    }
  });
}

async function handleUnblockAll(chatId) {
  await deactivateLockdown('Telegram /unblockall');
  const unlockText = `
🟢 <b>[EMERGENCY LOCKDOWN LIFTED]</b> 🟢
━━━━━━━━━━━━━━━━━━━━
✅ <b>Status:</b> <b>NORMAL TRAFFIC FLOW RESTORED</b>
🛡️ Multi-tier protection and rate limiting active.
🕒 ${new Date().toISOString()}
━━━━━━━━━━━━━━━━━━━━
  `.trim();
  bot.sendMessage(chatId, unlockText, { parse_mode: 'HTML' });
}

async function handleBanAll(chatId, args) {
  const trackedIps = await redis.smembers('tracked_ips_set');
  const targetIps = trackedIps.filter(ip => !isOwnerIp(ip));

  if (targetIps.length === 0) {
    return bot.sendMessage(chatId, '📊 No foreign client IPs found (Owner IPs automatically protected).');
  }

  const durationInput = args[0];
  const customReason = args.slice(1).join(' ').trim() || 'Mass ban all active clients by C2 Admin';
  const { seconds, human } = parseDuration(durationInput, Number(config.BAN_DURATION_SEC) || 1800);

  const pipeline = redis.pipeline();
  targetIps.forEach(ip => {
    pipeline.set(`blacklist:${ip}`, customReason, 'EX', seconds);
  });
  await pipeline.exec();

  await redis.publish('anti_ddos_sync', 'BAN:*').catch(() => {});

  bot.sendMessage(chatId, `
🚫 <b>[MASS BAN EXECUTED SUCCESSFULLY]</b> 🚫
━━━━━━━━━━━━━━━━━━━━
⛔ <b>Banned:</b> <code>${targetIps.length} IPs</code> (Owner excluded)
⏱️ <b>Duration:</b> <code>${human}</code> (${seconds}s)
📝 <b>Reason:</b> <i>${customReason}</i>
👑 <b>Owner Protection:</b> <b>Safe (Owner retains full access)</b>
━━━━━━━━━━━━━━━━━━━━
  `.trim(), {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [{ text: '🔓 Unban All (Clear Blacklist)', callback_data: 'cmd_unbanall' }]
      ]
    }
  });
}

async function handleUnbanAll(chatId) {
  const bannedKeys = await redis.keys('blacklist:*');
  if (bannedKeys.length === 0) {
    return bot.sendMessage(chatId, '✅ Blacklist is currently empty. No active bans.');
  }

  const pipeline = redis.pipeline();
  bannedKeys.forEach(k => pipeline.del(k));
  await pipeline.exec();

  await redis.publish('anti_ddos_sync', 'UNBAN:*').catch(() => {});

  bot.sendMessage(chatId, `
🔓 <b>[ALL BLACKLISTED IPS UNBANNED]</b> 🔓
━━━━━━━━━━━━━━━━━━━━
✅ <b>Unbanned:</b> <code>${bannedKeys.length} IPs</code>
🛡️ In-memory cache cleared across all 12 PM2 Workers!
🕒 ${new Date().toISOString()}
━━━━━━━━━━━━━━━━━━━━
  `.trim(), { parse_mode: 'HTML' });
}

async function handleWhois(chatId, args) {
  const targetIp = (args[0] || '').trim();
  if (!targetIp) {
    return bot.sendMessage(chatId, '👉 <b>Syntax:</b> <code>/whois &lt;ip&gt;</code>\n<i>Example:</i> <code>/whois 8.8.8.8</code>', { parse_mode: 'HTML' });
  }

  const sent = await bot.sendMessage(chatId, `🔍 Querying Geolocation & ISP for <code>${targetIp}</code>...`, { parse_mode: 'HTML' });
  const geo = await lookupIpGeo(targetIp);

  const isBanned = Boolean(await redis.get(`blacklist:${targetIp}`));
  const isOwner = isOwnerIp(targetIp);

  const whoisText = `
🌍 <b>[GEOLOCATION & ISP TELEMETRY]</b> 🌍
━━━━━━━━━━━━━━━━━━━━
🎯 <b>Target IP:</b> <code>${targetIp}</code> ${geo.flag || '🌐'}
📍 <b>Location:</b> <b>${geo.country} (${geo.countryCode})</b> - <code>${geo.regionName}, ${geo.city}</code>
📡 <b>ISP:</b> <code>${geo.isp}</code>
🏢 <b>Organization:</b> <code>${geo.org}</code>
🔢 <b>ASN:</b> <code>${geo.as}</code>
🛡️ <b>Security Status:</b> ${isOwner ? '👑 OWNER / WHITELIST' : isBanned ? '⛔ BLACKLISTED' : '🟢 CLEAN'}
━━━━━━━━━━━━━━━━━━━━
  `.trim();

  const inlineButtons = [];
  if (isBanned) {
    inlineButtons.push([{ text: `🔓 Unban ${targetIp}`, callback_data: `unban_${targetIp}` }]);
  } else {
    inlineButtons.push([
      { text: `🚫 Ban 30m`, callback_data: `ban_${targetIp}_30m` },
      { text: `🚫 Ban 2h`, callback_data: `ban_${targetIp}_2h` }
    ]);
  }
  inlineButtons.push([{ text: `👑 Whitelist as Owner`, callback_data: `whitelist_${targetIp}` }]);

  bot.editMessageText(whoisText, {
    chat_id: chatId,
    message_id: sent.message_id,
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: inlineButtons }
  });
}

async function handleSysInfo(chatId) {
  const metrics = await getFullSystemMetrics();

  const text = `
╔══════════════════════════════════╗
║  💻 <b>HOST HARDWARE & CLUSTER OPS</b>  ║
╚══════════════════════════════════╝

╭─ ⚙️ <b>HOST INFRASTRUCTURE</b> ────────────
│ 🖥️ <b>Host:</b>      <code>${metrics.hostname}</code>
│ 🐧 <b>Kernel:</b>    <code>${metrics.platform} (${metrics.kernel})</code>
│ ⏱️ <b>Uptime:</b>    <code>${metrics.sysUptime}</code>
│ 🌐 <b>Public IP:</b> <code>${getCachedPublicIp() || '115.79.152.48'}</code>
╰──────────────────────────────────

╭─ 🧠 <b>MEMORY CONSUMPTION (RAM)</b> ────────
│ 📊 <b>Usage:</b>     <b>${metrics.memory.percent}%</b> [ <code>${metrics.memory.used} / ${metrics.memory.total}</code> ]
│ 🟢 <b>Available:</b> <code>${metrics.memory.free} Free</code>
╰──────────────────────────────────

╭─ ⚡ <b>CPU LOAD MATRIX</b> ─────────────────
│ 🏷️ <b>Chip:</b>      <code>${metrics.cpu.model.slice(0, 28)}...</code>
│ 🧵 <b>Cores:</b>     <code>${metrics.cpu.cores} Physical Cores</code>
│ 📈 <b>Load Avg:</b>  <code>${metrics.cpu.load1m} (1m) • ${metrics.cpu.load5m} (5m) • ${metrics.cpu.load15m} (15m)</code>
╰──────────────────────────────────

╭─ 🚀 <b>PM2 CLUSTER ORCHESTRATION</b> ───────
│ 🟢 <b>Workers:</b>   <b>${metrics.pm2.online} / ${metrics.pm2.total} Online</b>
│ 📦 <b>Node Heap:</b> <code>${metrics.node.heapUsed} / ${metrics.node.heapTotal}</code>
│ ⚡ <b>Node RSS:</b>  <code>${metrics.node.rss}</code>
╰──────────────────────────────────
🕒 <i>Updated: ${new Date().toISOString()}</i>
  `.trim();

  bot.sendMessage(chatId, text, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '🔄 Refresh Metrics', callback_data: 'cmd_sysinfo' },
          { text: '🔄 Reload Cluster', callback_data: 'cmd_reload' }
        ]
      ]
    }
  });
}

async function handleLogs(chatId, args) {
  const count = parseInt(args[0], 10) || 10;
  const rawLogs = await redis.lrange('system:security_logs', 0, count - 1);

  if (!rawLogs || rawLogs.length === 0) {
    return bot.sendMessage(chatId, '📜 No security incidents recorded in recent telemetry.');
  }

  let text = `
╔══════════════════════════════════╗
║   📜 <b>SECURITY INCIDENT LOGS</b>   ║
╚══════════════════════════════════╝
\n`;
  rawLogs.forEach(entryStr => {
    try {
      const e = JSON.parse(entryStr);
      const timeStr = new Date(e.time).toISOString().slice(11, 19);
      const icon = e.type === 'AUTO_BAN' ? '🚫' : e.type === 'MANUAL_UNBAN' ? '🔓' : e.type === 'LOCKDOWN_DROP' ? '🚨' : '⚠️';
      text += `${icon} <b>[${timeStr}]</b> <code>${e.ip}</code>\n└ <i>${e.reason}</i>\n`;
    } catch {}
  });
  text += `\n━━━━━━━━━━━━━━━━━━━━\n<i>Showing latest ${rawLogs.length} events from ring-buffer.</i>`;

  bot.sendMessage(chatId, text.trim(), {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [[{ text: '🔄 Refresh Logs', callback_data: 'cmd_logs' }]]
    }
  });
}

async function handleRules(chatId) {
  const limit = (await redis.get('system:config:rate_limit_max')) || config.RATE_LIMIT_MAX_REQUESTS || 50;
  const burst = (await redis.get('system:config:rate_limit_burst')) || config.RATE_LIMIT_BURST_MAX || 15;
  const dur = (await redis.get('system:config:ban_duration_sec')) || config.BAN_DURATION_SEC || 1800;
  const isLockdown = (await redis.get('system:lockdown_mode')) === '1';
  const isChallenge = (await redis.get('system:under_attack_mode')) === '1';
  const isDropProxies = (await redis.get('system:drop_datacenter_proxies')) === '1';

  const text = `
╔══════════════════════════════════╗
║  ⚙️ <b>ACTIVE THREAT DEFENSE RULES</b> ║
╚══════════════════════════════════╝

╭─ ⚡ <b>DYNAMIC RATE LIMITING THRESHOLDS</b> ──
│ ⚡ <b>Burst Peak (3s):</b>    <code>${burst} requests</code> (~${(burst / 3).toFixed(1)} req/s)
│ 🎯 <b>Sustained (60s):</b>   <code>${limit} requests</code>
│ ⏱️ <b>Auto-Ban Window:</b>  <code>${formatDurationHuman(parseInt(dur, 10))}</code> (${dur}s)
╰──────────────────────────────────

╭─ 🛡️ <b>AUTOMATED SHIELD STATUS</b> ──────────
│ 🚨 <b>Lockdown:</b>       ${isLockdown ? '🔴 <b>ARMED (BLOCK ALL)</b>' : '🟢 <b>STANDBY</b>'}
│ 🔥 <b>Anti-Bot PoW:</b>   ${isChallenge ? '🔴 <b>ARMED (CHALLENGE)</b>' : '⚪ <b>STANDBY</b>'}
│ 🏢 <b>Cloud Proxies:</b>  ${isDropProxies ? '🔴 <b>FILTERING (ACTIVE)</b>' : '⚪ <b>STANDBY</b>'}
│ 🛡️ <b>Exploit Scan:</b>   <b>ARMED (1h instant ban)</b> 🟢
│ 👑 <b>Owner Bypass:</b>   <b>ACTIVE (Full Immunity)</b> 👑
╰──────────────────────────────────
💡 <i>Tune values anytime via:</i>
• <code>/setlimit &lt;num&gt;</code> | <code>/setburst &lt;num&gt;</code> | <code>/setbandur &lt;time&gt;</code>
  `.trim();

  bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
}

async function handleSetLimit(chatId, args) {
  const val = parseInt(args[0], 10);
  if (isNaN(val) || val <= 0) {
    return bot.sendMessage(chatId, '⚠️ Enter valid request limit: <code>/setlimit &lt;number&gt;</code>', { parse_mode: 'HTML' });
  }

  await redis.set('system:config:rate_limit_max', val);
  await redis.publish('anti_ddos_sync', `CONFIG:LIMIT:${val}`);
  bot.sendMessage(chatId, `🎯 <b>[SUSTAINED RATE LIMIT UPDATED]</b>\nNew threshold: <code>${val} reqs / 60s</code> (Synced across 12 Workers).`, { parse_mode: 'HTML' });
}

async function handleSetBurst(chatId, args) {
  const val = parseInt(args[0], 10);
  if (isNaN(val) || val <= 0) {
    return bot.sendMessage(chatId, '⚠️ Enter valid burst limit: <code>/setburst &lt;number&gt;</code>', { parse_mode: 'HTML' });
  }

  await redis.set('system:config:rate_limit_burst', val);
  await redis.publish('anti_ddos_sync', `CONFIG:BURST:${val}`);
  bot.sendMessage(chatId, `⚡ <b>[BURST RATE LIMIT UPDATED]</b>\nNew threshold: <code>${val} reqs / 3s</code> (~${(val / 3).toFixed(1)} req/s).`, { parse_mode: 'HTML' });
}

async function handleSetBanDur(chatId, args) {
  const { seconds, human } = parseDuration(args[0], 1800);
  await redis.set('system:config:ban_duration_sec', seconds);
  await redis.publish('anti_ddos_sync', `CONFIG:DURATION:${seconds}`);
  bot.sendMessage(chatId, `⏱️ <b>[BAN DURATION UPDATED]</b>\nNew ban duration: <code>${human}</code> (${seconds}s).`, { parse_mode: 'HTML' });
}

async function handleFlush(chatId) {
  const rateKeys = await redis.keys('rate_limit:*');
  const burstKeys = await redis.keys('burst:*');
  const allKeys = [...rateKeys, ...burstKeys];

  if (allKeys.length > 0) {
    const pipeline = redis.pipeline();
    allKeys.forEach(k => pipeline.del(k));
    await pipeline.exec();
  }

  bot.sendMessage(chatId, `🧹 <b>[RATE LIMIT COUNTERS FLUSHED]</b>\nCleared <code>${allKeys.length}</code> sliding-window keys.`, { parse_mode: 'HTML' });
}

async function handleReload(chatId) {
  const sent = await bot.sendMessage(chatId, '🔄 Broadcasting hot reload signal to 12 PM2 Workers...');
  try {
    await execPromise('npx pm2 reload all');
    bot.editMessageText(`✅ <b>[PM2 CLUSTER HOT RELOAD SUCCESS]</b>\nAll 12 Workers reloaded zero-downtime with latest source code!\n🕒 ${new Date().toISOString()}`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: 'HTML'
    });
  } catch (err) {
    bot.editMessageText(`❌ Reload failed: ${err.message}`, {
      chat_id: chatId,
      message_id: sent.message_id
    });
  }
}

async function handleWhitelist(chatId, args) {
  const targetIp = (args[0] || '').trim();
  if (!targetIp) {
    return bot.sendMessage(chatId, '👉 <b>Syntax:</b> <code>/whitelist &lt;ip&gt;</code>\n<i>(Owner IPs are never banned by /banall or rate limiting)</i>', { parse_mode: 'HTML' });
  }

  await addOwnerIp(targetIp);
  bot.sendMessage(chatId, `👑 <b>[OWNER IP ADDED TO WHITELIST]</b>\nIP: <code>${targetIp}</code> granted full Owner privileges!`, { parse_mode: 'HTML' });
}

async function handleDelOwner(chatId, args) {
  const targetIp = (args[0] || '').trim();
  if (!targetIp) {
    return bot.sendMessage(chatId, '👉 <b>Syntax:</b> <code>/delowner &lt;ip&gt;</code>', { parse_mode: 'HTML' });
  }

  await removeOwnerIp(targetIp);
  bot.sendMessage(chatId, `✅ <b>[OWNER PRIVILEGE REMOVED]</b>\nIP: <code>${targetIp}</code> removed from Owner Whitelist.`, { parse_mode: 'HTML' });
}

async function handleOwnerList(chatId) {
  const ownerIps = await getAllOwnerIps();
  const publicIp = getCachedPublicIp() || '115.79.152.48';

  let listText = `👑 <b>[PROTECTED OWNER WHITELIST]</b> 👑\n━━━━━━━━━━━━━━━━━━━━\n`;
  ownerIps.forEach(ip => {
    const tag = (ip === publicIp || ip === '127.0.0.1') ? ' <i>(Host / Localhost)</i>' : ' <i>(Custom Owner)</i>';
    listText += `• <code>${ip}</code>${tag}\n`;
  });
  listText += `━━━━━━━━━━━━━━━━━━━━\n<i>Add: <code>/whitelist &lt;ip&gt;</code> | Remove: <code>/delowner &lt;ip&gt;</code></i>`;

  bot.sendMessage(chatId, listText, { parse_mode: 'HTML' });
}

async function handleWhoAmI(chatId, userObj) {
  const uId = userObj ? String(userObj.id) : String(chatId);
  const name = userObj ? (userObj.first_name + (userObj.last_name ? ' ' + userObj.last_name : '')) : 'Admin';
  const username = userObj && userObj.username ? `@${userObj.username}` : 'N/A';
  const isAuth = await isUserAuthenticated(uId);

  const text = `
👤 <b>[USER SESSION & IDENTITY TELEMETRY]</b>
━━━━━━━━━━━━━━━━━━━━
• <b>Telegram User ID:</b> <code>${uId}</code>
• <b>Full Name:</b> <code>${name}</code>
• <b>Username:</b> <code>${username}</code>
• <b>Security Authorization:</b> ${isAuth ? '🟢 <b>AUTHENTICATED (FULL ACCESS)</b>' : '🔴 <b>UNAUTHORIZED</b>'}
• <b>Server Public IP:</b> <code>${getCachedPublicIp() || '115.79.152.48'}</code>
━━━━━━━━━━━━━━━━━━━━
<i>To revoke this session, run <code>/logout</code>.</i>
  `.trim();

  bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
}

async function handlePing(chatId) {
  const start = Date.now();
  const sent = await bot.sendMessage(chatId, '🏓 Measuring cluster round-trip latency...');
  const latency = Date.now() - start;
  bot.editMessageText(`🏓 <b>PONG!</b>\n⚡ Latency: <code>${latency}ms</code>\n🟢 Node.js Cluster: <b>ONLINE (12 Workers)</b>\n🛡️ Real-time DDoS Engine: <b>ACTIVE (5s polling)</b>`, {
    chat_id: chatId,
    message_id: sent.message_id,
    parse_mode: 'HTML'
  });
}

async function handleStats(chatId) {
  const nowSec = Math.floor(Date.now() / 1000);
  const ddosKeys = [];
  const cleanKeys = [];
  for (let s = nowSec - 5; s < nowSec; s++) {
    ddosKeys.push(`ddos_sec:${s}`);
    cleanKeys.push(`traffic_sec:${s}`);
  }

  const pipeline = redis.pipeline();
  pipeline.smembers('tracked_ips_set');
  pipeline.keys('blacklist:*');
  pipeline.get('system:lockdown_mode');
  pipeline.ttl('system:lockdown_mode');
  pipeline.get('system:lockdown_dropped_total');
  pipeline.get('system:total_ddos_mitigated_cumulative');
  pipeline.get('system:under_attack_mode');
  pipeline.get('system:drop_datacenter_proxies');
  ddosKeys.forEach(k => pipeline.get(k));
  cleanKeys.forEach(k => pipeline.get(k));

  const res = await pipeline.exec();
  const trackedIps = (res[0] && res[0][1]) || [];
  const bannedKeys = (res[1] && res[1][1]) || [];
  const isLockdownActive = res[2] && res[2][1] === '1';
  const lockdownTtl = (res[3] && res[3][1]) ? parseInt(res[3][1], 10) : -1;
  const lockdownDropped = (res[4] && res[4][1]) ? parseInt(res[4][1], 10) : 0;
  const ddosMitigatedTotal = (res[5] && res[5][1]) ? parseInt(res[5][1], 10) : 0;
  const isUnderAttack = res[6] && res[6][1] === '1';
  const isDropProxies = res[7] && res[7][1] === '1';

  let ddosSum = 0;
  let cleanSum = 0;
  for (let i = 8; i < 13; i++) {
    ddosSum += res[i] && res[i][1] ? parseInt(res[i][1], 10) : 0;
  }
  for (let i = 13; i < 18; i++) {
    cleanSum += res[i] && res[i][1] ? parseInt(res[i][1], 10) : 0;
  }

  const currentDdosRps = Math.round((ddosSum / 5) * 10) / 10;
  const currentCleanRps = Math.round((cleanSum / 5) * 10) / 10;

  // Calculate clean requests sum from all tracked IPs
  let totalCleanRequests = 0;
  if (trackedIps.length > 0) {
    const pipe2 = redis.pipeline();
    trackedIps.forEach(ip => pipe2.hget(`ip_tracker:${ip}`, 'count'));
    const r2 = await pipe2.exec();
    r2.forEach(item => {
      if (item && item[1]) totalCleanRequests += parseInt(item[1], 10) || 0;
    });
  }

  const grandTotal = totalCleanRequests;

  let lockdownBadge = isLockdownActive
    ? `🔴 <b>ACTIVE</b> [${formatDurationHuman(lockdownTtl)}]`
    : `🟢 <b>INACTIVE (OPEN)</b>`;

  const statsText = `
╔══════════════════════════════════╗
║  📊 <b>TRAFFIC & THREAT TELEMETRY</b>  ║
╚══════════════════════════════════╝

╭─ 📡 <b>REAL-TIME INGRESS (5s AVG)</b> ────────
│ 🟢 <b>Clean Traffic:</b>    <code>${currentCleanRps} req/s</code>
│ 🚨 <b>Mitigated Attack:</b> <code>${currentDdosRps} Rq /s</code> ${currentDdosRps >= 4 ? '🔥' : '🛡️'}
╰──────────────────────────────────

╭─ 📦 <b>ACCUMULATED VOLUME</b> ─────────────
│ 📈 <b>Total Volume:</b>     <b>${grandTotal.toLocaleString()} requests</b>
│ 👥 <b>Unique Clients:</b>   <b>${trackedIps.length} endpoints</b>
│ ⛔ <b>Blacklisted IPs:</b>  <b>${bannedKeys.length} targets</b>
╰──────────────────────────────────

╭─ 🛡️ <b>DEFENSE POSTURE STATUS</b> ───────────
│ 🚨 <b>Emergency Mode:</b>   ${lockdownBadge}
│ 🔥 <b>Under Attack PoW:</b> <b>${isUnderAttack ? 'ARMED' : 'STANDBY'}</b> ${isUnderAttack ? '🔥' : '⚪'}
│ 🏢 <b>Drop VPS Proxies:</b>  <b>${isDropProxies ? 'ARMED' : 'STANDBY'}</b> ${isDropProxies ? '🏢' : '⚪'}
╰──────────────────────────────────
🕒 <i>Synced live across 12 PM2 Cluster Workers</i>
  `.trim();

  bot.sendMessage(chatId, statsText, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '🔄 Refresh Stats', callback_data: 'cmd_stats' },
          { text: '🏆 Top Clients', callback_data: 'cmd_top' }
        ]
      ]
    }
  });
}

async function handleBanned(chatId) {
  const bannedKeys = await redis.keys('blacklist:*');
  if (bannedKeys.length === 0) {
    return bot.sendMessage(chatId, '✅ Blacklist is currently clean. No blocked targets.');
  }

  const pipeline = redis.pipeline();
  const sampleKeys = bannedKeys.slice(0, 15);
  sampleKeys.forEach(k => {
    pipeline.get(k);
    pipeline.ttl(k);
  });

  const results = await pipeline.exec();
  let listText = `
╔══════════════════════════════════╗
║   ⛔ <b>ACTIVE BLACKLISTED TARGETS</b>   ║
╚══════════════════════════════════╝

╭─ 🎯 <b>ENFORCED DROP TARGETS (${bannedKeys.length})</b> ──
`;

  const inlineButtons = [];

  for (let i = 0; i < sampleKeys.length; i++) {
    const ip = sampleKeys[i].replace('blacklist:', '');
    const reason = results[i * 2][1] || 'Rate limit';
    const ttl = results[i * 2 + 1][1] || 0;
    listText += `│ • <code>${ip}</code> <i>[${formatDurationHuman(ttl)}]</i>\n│   └ <i>${reason.slice(0, 30)}</i>\n`;

    if (i < 6) {
      inlineButtons.push([{ text: `🔓 Unban ${ip}`, callback_data: `unban_${ip}` }]);
    }
  }

  listText += `╰──────────────────────────────────\n💡 <i>Use <code>/unban &lt;ip&gt;</code> or tap below to unban:</i>`;
  inlineButtons.push([{ text: '🔓 UNBAN ALL (PURGE BLACKLIST)', callback_data: 'cmd_unbanall' }]);
  bot.sendMessage(chatId, listText, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: inlineButtons }
  });
}

async function handleTop(chatId) {
  const ipSet = new Set(await redis.smembers('tracked_ips_set'));
  const trackerKeys = await redis.keys('ip_tracker:*');
  trackerKeys.forEach(k => ipSet.add(k.replace('ip_tracker:', '')));
  const trackedIps = Array.from(ipSet).filter(ip => !isIgnoredIp(ip));

  if (trackedIps.length === 0) {
    return bot.sendMessage(chatId, '📊 No client traffic records tracked yet.');
  }

  const pipeline = redis.pipeline();
  trackedIps.forEach(ip => {
    pipeline.hgetall(`ip_tracker:${ip}`);
    pipeline.ttl(`blacklist:${ip}`);
  });
  const trackerResults = await pipeline.exec();

  const ipList = [];
  for (let i = 0; i < trackedIps.length; i++) {
    const data = (trackerResults[i * 2] && trackerResults[i * 2][1]) || {};
    const banTtl = (trackerResults[i * 2 + 1] && trackerResults[i * 2 + 1][1]) ? Number(trackerResults[i * 2 + 1][1]) : -2;
    const isBanned = banTtl > -2;

    const count = parseInt(data.count || 0, 10);
    const blocked = parseInt(data.blocked_count || 0, 10);

    if (count > 0 || blocked > 0 || isBanned) {
      ipList.push({
        ip: trackedIps[i],
        count,
        blocked,
        isBanned,
        lastSeen: data.last_seen || ''
      });
    }
  }

  ipList.sort((a, b) => b.count - a.count);
  const top10 = ipList.slice(0, 10);

  let topText = `🏆 <b>[TOP INGRESS CLIENTS (BY TOTAL REQUESTS)]</b> 🏆\n━━━━━━━━━━━━━━━━━━━━\n`;
  for (let index = 0; index < top10.length; index++) {
    const item = top10[index];
    const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `<b>#${index + 1}</b>`;
    const geo = await lookupIpGeo(item.ip);
    const banBadge = item.isBanned ? ' ⛔ [BANNED]' : '';
    const blockedDetail = item.blocked > 0 ? ` <i>(${item.blocked} dropped)</i>` : '';
    topText += `${medal} <code>${item.ip}</code> ${geo.flag || '🌐'}: <b>${item.count.toLocaleString()}</b> reqs${banBadge}${blockedDetail}\n`;
  }
  topText += `━━━━━━━━━━━━━━━━━━━━\n<i>Inspect: <code>/inspect &lt;ip&gt;</code> | <code>/whois &lt;ip&gt;</code></i>`;

  bot.sendMessage(chatId, topText, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [[{ text: '🚫 BAN ALL Foreign Clients', callback_data: 'cmd_banall' }]]
    }
  });
}

async function handleInspect(chatId, args) {
  const targetIp = (args[0] || '').trim();
  if (!targetIp) {
    return bot.sendMessage(chatId, '👉 <b>Syntax:</b> <code>/inspect &lt;ip&gt;</code>', { parse_mode: 'HTML' });
  }

  const pipeline = redis.pipeline();
  pipeline.hgetall(`ip_tracker:${targetIp}`);
  pipeline.get(`rate_limit:${targetIp}`);
  pipeline.get(`blacklist:${targetIp}`);
  pipeline.ttl(`blacklist:${targetIp}`);

  const [trackerRes, rateRes, banReasonRes, banTtlRes] = await pipeline.exec();
  const trackerData = (trackerRes && trackerRes[1]) || {};
  const currentRate = (rateRes && rateRes[1]) ? parseInt(rateRes[1], 10) : 0;
  const isBanned = Boolean(banReasonRes && banReasonRes[1]);
  const banReason = (banReasonRes && banReasonRes[1]) || 'N/A';
  const banTtl = (banTtlRes && banTtlRes[1]) ? parseInt(banTtlRes[1], 10) : 0;

  const totalRequests = parseInt(trackerData.count || 0, 10);
  const firstSeen = trackerData.firstSeen ? new Date(trackerData.firstSeen).toISOString() : 'N/A';
  const lastSeen = trackerData.lastSeen ? new Date(trackerData.lastSeen).toISOString() : 'N/A';

  const geo = await lookupIpGeo(targetIp);
  const statusSymbol = isBanned ? '⛔ BLACKLISTED' : '🟢 ACTIVE / CLEAN';

  const inspectText = `
╔══════════════════════════════════╗
║  🔍 <b>TARGET DOSSIER: <code>${targetIp}</code></b> ${geo.flag || '🌐'}  ║
╚══════════════════════════════════╝

╭─ 📍 <b>GEOLOCATION & NETWORK</b> ─────────
│ 🌍 <b>Country:</b>   <b>${geo.country} (${geo.countryCode})</b>
│ 🏙️ <b>City:</b>      <code>${geo.regionName}, ${geo.city}</code>
│ 📡 <b>ISP:</b>       <code>${geo.isp}</code>
│ 🔢 <b>ASN:</b>       <code>${geo.as}</code>
│ 🏢 <b>Org:</b>       <code>${geo.org}</code>
╰──────────────────────────────────

╭─ 📊 <b>TRAFFIC & INGRESS ACTIVITY</b> ─────
│ 📈 <b>Total Volume:</b>   <b>${totalRequests.toLocaleString()} requests</b>
│ ⚡ <b>Current Rate:</b>   <code>${currentRate} reqs in 60s</code>
│ ⏱️ <b>First Seen:</b>     <code>${firstSeen}</code>
│ 🕒 <b>Last Seen:</b>      <code>${lastSeen}</code>
╰──────────────────────────────────

╭─ 🛡️ <b>SECURITY & REPUTATION STATUS</b> ───
│ 🛡️ <b>Status:</b>     <b>${statusSymbol}</b>
${isBanned ? `│ ⛔ <b>Reason:</b>     <i>${banReason}</i>\n│ ⏳ <b>TTL Left:</b>   <code>${formatDurationHuman(banTtl)}</code>\n` : ''}╰──────────────────────────────────
  `.trim();

  const inlineKeyboard = isBanned
    ? [
        [
          { text: `🔓 Unban ${targetIp}`, callback_data: `unban_${targetIp}` },
          { text: `🌍 Whois / ASN`, callback_data: `whois_${targetIp}` }
        ]
      ]
    : [
        [
          { text: `🚫 Ban 30m`, callback_data: `ban_${targetIp}_30m` },
          { text: `🚫 Ban 2h`, callback_data: `ban_${targetIp}_2h` },
          { text: `🚫 Ban Perm`, callback_data: `ban_${targetIp}_perm` }
        ],
        [
          { text: `🌍 Whois / ASN`, callback_data: `whois_${targetIp}` },
          { text: `👑 Whitelist Owner`, callback_data: `whitelist_${targetIp}` }
        ]
      ];

  bot.sendMessage(chatId, inspectText, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: inlineKeyboard }
  });
}

async function handleLive(chatId) {
  const sent = await bot.sendMessage(chatId, '📡 <b>[LIVE RADAR]</b> Scanning active incoming streams across 12 Workers...', { parse_mode: 'HTML' });

  const ipSet = new Set(await redis.smembers('tracked_ips_set'));
  const trackerKeys = await redis.keys('ip_tracker:*');
  trackerKeys.forEach(k => ipSet.add(k.replace('ip_tracker:', '')));
  const allIps = Array.from(ipSet).filter(ip => !isIgnoredIp(ip));

  if (allIps.length === 0) {
    return bot.editMessageText(`
╔══════════════════════════════════╗
║     📡 <b>LIVE INGRESS RADAR</b>     ║
╚══════════════════════════════════╝

🟢 <b>ALL QUIET:</b> No endpoints recorded yet.
🛡️ <i>12 Cluster Workers in Standby Mode.</i>
    `.trim(), {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[{ text: '🔄 Rescan Live Stream', callback_data: 'cmd_live' }]] }
    });
  }

  const now = Date.now();
  const pipeline = redis.pipeline();
  allIps.forEach(ip => {
    pipeline.hgetall(`ip_tracker:${ip}`);
    pipeline.get(`burst:${ip}`);
    pipeline.get(`rate_limit:${ip}`);
    pipeline.get(`blacklist:${ip}`);
    pipeline.ttl(`blacklist:${ip}`);
  });

  const results = await pipeline.exec();
  const liveNodes = [];

  for (let i = 0; i < allIps.length; i++) {
    const ip = allIps[i];
    const trackerData = (results[i * 5] && results[i * 5][1]) || {};
    const burst = parseInt((results[i * 5 + 1] && results[i * 5 + 1][1]) || '0', 10);
    const rateLimit = parseInt((results[i * 5 + 2] && results[i * 5 + 2][1]) || '0', 10);
    const banReason = results[i * 5 + 3] && results[i * 5 + 3][1];
    const banTtl = parseInt((results[i * 5 + 4] && results[i * 5 + 4][1]) || '-2', 10);

    const isBanned = banTtl > -2;
    const lastSeen = trackerData.last_seen ? Number(trackerData.last_seen) : null;
    const diffSec = lastSeen ? Math.max(0, Math.round((now - lastSeen) / 1000)) : 9999;
    const totalCount = parseInt(trackerData.count || 0, 10);
    const droppedCount = parseInt(trackerData.blocked_count || 0, 10);

    // Active in last 60s or currently has burst/rate counters or recently banned
    if (diffSec <= 60 || burst > 0 || rateLimit > 0 || (isBanned && diffSec <= 300)) {
      const liveRps = burst > 0 ? (burst / 3).toFixed(1) : (rateLimit > 0 && diffSec <= 10 ? (rateLimit / 10).toFixed(1) : '0.0');
      liveNodes.push({
        ip,
        burst,
        rateLimit,
        liveRps: parseFloat(liveRps),
        diffSec,
        totalCount,
        droppedCount,
        isBanned,
        banReason,
        banTtl
      });
    }
  }

  if (liveNodes.length === 0) {
    return bot.editMessageText(`
╔══════════════════════════════════╗
║     📡 <b>LIVE INGRESS RADAR</b>     ║
╚══════════════════════════════════╝

🟢 <b>ALL QUIET:</b> No active traffic in the last 60 seconds.
🛡️ <i>12 Cluster Workers running at 0% idle load.</i>
🕒 <i>${new Date().toISOString()}</i>
    `.trim(), {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🔄 Rescan Live Stream', callback_data: 'cmd_live' },
            { text: '📊 Full Stats', callback_data: 'cmd_stats' }
          ]
        ]
      }
    });
  }

  // Sort by live attack rate descending, then burst descending, then recency
  liveNodes.sort((a, b) => b.liveRps - a.liveRps || b.burst - a.burst || a.diffSec - b.diffSec);

  let liveText = `
╔══════════════════════════════════╗
║   📡 <b>LIVE ATTACK & INGRESS RADAR</b> ║
╚══════════════════════════════════╝

╭─ ⚡ <b>ACTIVE INGRESS STREAMS (${liveNodes.length})</b> ──
`;

  const inlineButtons = [];

  for (let idx = 0; idx < Math.min(liveNodes.length, 8); idx++) {
    const node = liveNodes[idx];
    const geo = await lookupIpGeo(node.ip);
    const isAttacker = node.liveRps >= 3 || node.isBanned || node.burst >= 8;
    const badge = node.isBanned ? '⛔ <b>[BANNED - 0ms DROP]</b>' : isAttacker ? '🔥 <b>[FLOODING ATTACK]</b>' : '🟢 <b>[ACTIVE CLEAN]</b>';
    const seenStr = node.diffSec <= 1 ? 'Just now' : `${node.diffSec}s ago`;

    liveText += `│
│ ${isAttacker ? '🚨' : '🟢'} <code>${node.ip}</code> ${geo.flag || '🌐'}
│   ⚡ <b>Live Rate:</b> <code>${node.liveRps} Rq /s</code> • ${badge}
│   📡 <b>ISP:</b> <code>${geo.isp.slice(0, 25)}</code>
│   📊 <b>Volume:</b> <code>${node.totalCount} reqs</code> (${node.droppedCount} dropped) • <i>${seenStr}</i>
`;

    if (!node.isBanned && isAttacker) {
      inlineButtons.push([{ text: `🚫 Ban Flooder ${node.ip}`, callback_data: `ban_${node.ip}_2h` }]);
    }
  }

  liveText += `╰──────────────────────────────────\n💡 <i>Live radar auto-updates on demand.</i>`;

  inlineButtons.push([
    { text: '🔄 Rescan Live', callback_data: 'cmd_live' },
    { text: '📸 Threat Snapshot', callback_data: 'cmd_snapshot' }
  ]);
  inlineButtons.push([
    { text: '🚫 BAN ALL Foreign', callback_data: 'cmd_banall' },
    { text: '🚨 LOCKDOWN 15M', callback_data: 'cmd_blockall_15m' }
  ]);

  bot.editMessageText(liveText.trim(), {
    chat_id: chatId,
    message_id: sent.message_id,
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: inlineButtons }
  });
}

async function handleBan(chatId, args) {
  const targetIp = (args[0] || '').trim();

  if (targetIp.toLowerCase() === 'all') {
    return handleBanAll(chatId, args.slice(1));
  }

  if (!targetIp) {
    return bot.sendMessage(chatId, '👉 <b>Syntax:</b> <code>/ban &lt;ip&gt; [duration] [reason]</code>', { parse_mode: 'HTML' });
  }

  const durationInput = args[1];
  const customReason = args.slice(2).join(' ').trim() || 'Manual ban by C2 Admin';
  const { seconds, human } = parseDuration(durationInput, Number(config.BAN_DURATION_SEC) || 1800);

  await redis.set(`blacklist:${targetIp}`, customReason, 'EX', seconds);
  await redis.publish('anti_ddos_sync', `BAN:${targetIp}`).catch(() => {});

  const confirmText = `
🚫 <b>[TARGET BANNED SUCCESSFULLY]</b> 🚫
━━━━━━━━━━━━━━━━━━━━
🎯 <b>Target IP:</b> <code>${targetIp}</code>
⏱️ <b>Duration:</b> <code>${human}</code> (${seconds}s)
📝 <b>Reason:</b> <i>${customReason}</i>
🛡️ <b>Scope:</b> Cluster-wide (0ms In-Memory Drop)
━━━━━━━━━━━━━━━━━━━━
  `.trim();

  bot.sendMessage(chatId, confirmText, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [[{ text: `🔓 Unban Target`, callback_data: `unban_${targetIp}` }]]
    }
  });
}

async function handleUnban(chatId, args) {
  const targetIp = (args[0] || '').trim();

  if (targetIp.toLowerCase() === 'all') {
    return handleUnbanAll(chatId);
  }

  if (!targetIp) {
    return bot.sendMessage(chatId, '👉 <b>Syntax:</b> <code>/unban &lt;ip&gt;</code>', { parse_mode: 'HTML' });
  }

  await redis.del(`blacklist:${targetIp}`, `rate_limit:${targetIp}`, `burst:${targetIp}`);
  await redis.publish('anti_ddos_sync', `UNBAN:${targetIp}`).catch(() => {});
  bot.sendMessage(chatId, `✅ <b>[TARGET UNBANNED]</b>\nIP: <code>${targetIp}</code> removed from global blacklist.`, { parse_mode: 'HTML' });
}

async function handleClear(chatId) {
  const trackedIps = await redis.smembers('tracked_ips_set');
  const pipeline = redis.pipeline();
  trackedIps.forEach(ip => pipeline.del(`ip_tracker:${ip}`));
  pipeline.del('tracked_ips_set');
  const trackerKeys = await redis.keys('ip_tracker:*');
  trackerKeys.forEach(k => pipeline.del(k));
  await pipeline.exec();

  bot.sendMessage(chatId, `🗑️ <b>[INGRESS RECORDS CLEARED]</b>\nPurged <code>${trackedIps.length}</code> tracked client records from Redis!`, { parse_mode: 'HTML' });
}

async function handleExport(chatId) {
  const excelService = require('./excelService');
  bot.sendMessage(chatId, '⏳ Generating telemetry Excel report...');
  const filePath = await excelService.exportIpReportToExcel();
  await bot.sendDocument(chatId, filePath, {
    caption: `📊 <b>IP Telemetry Report</b>\n🕒 Generated: ${new Date().toISOString()}`,
    parse_mode: 'HTML'
  });
}

/**
 * Unified Type-Safe Command Dispatcher with Mandatory Security Authentication
 */
async function dispatchTelegramMessage(msg) {
  const userId = String(msg.from ? msg.from.id : msg.chat.id);
  const chatId = msg.chat.id;
  const text = (msg.text || '').trim();

  // 1. Check User Authentication Status
  const isAuth = await isUserAuthenticated(userId);

  // ================= UNAUTHENTICATED USERS GATEWAY =================
  if (!isAuth) {
    const tokens = text.split(/\s+/);
    const firstWord = tokens[0].toLowerCase();

    // Check if user is attempting to authenticate
    if (firstWord === '/auth' || firstWord === '/login' || firstWord === 'auth' || firstWord === 'login') {
      const candidatePass = tokens.slice(1).join(' ').trim();
      if (!candidatePass) {
        return bot.sendMessage(chatId, `
🔒 <b>[AUTHENTICATION REQUIRED]</b>
━━━━━━━━━━━━━━━━━━━━
Please provide the security password:
👉 <b>Syntax:</b> <code>/auth &lt;password&gt;</code>
<i>(Password is configured in server config.txt)</i>
━━━━━━━━━━━━━━━━━━━━
        `.trim(), { parse_mode: 'HTML' });
      }

      const result = await authenticateUser(userId, candidatePass);
      if (result.success) {
        await bot.sendMessage(chatId, `
🔓 <b>[AUTHENTICATION SUCCESSFUL]</b> 🔓
━━━━━━━━━━━━━━━━━━━━
✅ Welcome, Administrator!
🛡️ Your Telegram ID (<code>${userId}</code>) is verified & authorized.
━━━━━━━━━━━━━━━━━━━━
        `.trim(), { parse_mode: 'HTML' });
        return handleMenu(chatId);
      } else if (result.locked) {
        return bot.sendMessage(chatId, `
⛔ <b>[SECURITY LOCKOUT: TOO MANY ATTEMPTS]</b> ⛔
━━━━━━━━━━━━━━━━━━━━
Your account is temporarily locked for <b>${Math.ceil(result.remainingSec / 60)} minutes</b> due to multiple failed authentication attempts.
━━━━━━━━━━━━━━━━━━━━
        `.trim(), { parse_mode: 'HTML' });
      } else {
        return bot.sendMessage(chatId, `
❌ <b>[AUTHENTICATION FAILED]</b>
━━━━━━━━━━━━━━━━━━━━
Invalid security password! (Attempt <b>${result.attempts} / ${result.maxAttempts}</b>).
👉 <b>Syntax:</b> <code>/auth &lt;password&gt;</code>
━━━━━━━━━━━━━━━━━━━━
        `.trim(), { parse_mode: 'HTML' });
      }
    }

    // Direct password input
    if (!text.startsWith('/') && text.length > 0) {
      const result = await authenticateUser(userId, text);
      if (result.success) {
        await bot.sendMessage(chatId, `
🔓 <b>[AUTHENTICATION SUCCESSFUL]</b> 🔓
━━━━━━━━━━━━━━━━━━━━
✅ Welcome, Administrator!
🛡️ Your Telegram ID (<code>${userId}</code>) is verified & authorized.
━━━━━━━━━━━━━━━━━━━━
        `.trim(), { parse_mode: 'HTML' });
        return handleMenu(chatId);
      } else if (result.locked) {
        return bot.sendMessage(chatId, `
⛔ <b>[SECURITY LOCKOUT: TOO MANY ATTEMPTS]</b> ⛔
━━━━━━━━━━━━━━━━━━━━
Your account is temporarily locked for <b>${Math.ceil(result.remainingSec / 60)} minutes</b> due to repeated unauthorized attempts.
━━━━━━━━━━━━━━━━━━━━
        `.trim(), { parse_mode: 'HTML' });
      } else {
        return bot.sendMessage(chatId, `
❌ <b>[AUTHENTICATION FAILED]</b>
━━━━━━━━━━━━━━━━━━━━
Invalid security password! (Attempt <b>${result.attempts} / ${result.maxAttempts}</b>).
👉 <b>Syntax:</b> <code>/auth &lt;password&gt;</code>
━━━━━━━━━━━━━━━━━━━━
        `.trim(), { parse_mode: 'HTML' });
      }
    }

    // Default Gatekeeper Message
    return bot.sendMessage(chatId, `
🔒 <b>[C2 SECURITY ACCESS GATEWAY]</b> 🔒
━━━━━━━━━━━━━━━━━━━━
⚠️ <b>Authentication Required:</b> Access to this Defense Command Center is strictly protected.

👉 Please authenticate to continue:
<b>Syntax:</b> <code>/auth &lt;password&gt;</code>
<i>(Password is configured in server config.txt)</i>
━━━━━━━━━━━━━━━━━━━━
🛡️ <i>Unauthorized requests are blocked and logged.</i>
    `.trim(), { parse_mode: 'HTML' });
  }

  // ================= AUTHENTICATED COMMANDS DISPATCHER =================
  if (!text.startsWith('/')) return;

  const tokens = text.split(/\s+/);
  const commandRaw = tokens[0].slice(1).split('@')[0].toLowerCase();
  const args = tokens.slice(1);

  try {
    switch (commandRaw) {
      case 'start':
      case 'help':
      case 'menu':
        await handleMenu(chatId);
        break;

      case 'live':
      case 'radar':
      case 'attackers':
      case 'ddos':
        await handleLive(chatId);
        break;

      case 'underattack':
      case 'challenge':
      case 'jschallenge':
        await handleUnderAttack(chatId, args);
        break;

      case 'cflevel':
      case 'cf':
      case 'cloudflare':
        await handleCloudflareLevel(chatId, args);
        break;

      case 'snapshot':
      case 'forensics':
      case 'threatintel':
        await handleSnapshot(chatId);
        break;

      case 'blockcountry':
      case 'geoblock':
        await handleBlockCountry(chatId, args);
        break;

      case 'unblockcountry':
      case 'ungeoblock':
        await handleUnblockCountry(chatId, args);
        break;

      case 'countryrules':
      case 'blockedcountries':
      case 'countries':
        await handleCountryRules(chatId);
        break;

      case 'bansubnet':
      case 'blocksubnet':
        await handleBanSubnet(chatId, args);
        break;

      case 'unbansubnet':
      case 'unblocksubnet':
        await handleUnbanSubnet(chatId, args);
        break;

      case 'subnets':
      case 'bannedsubnets':
        await handleSubnets(chatId);
        break;

      case 'dropproxy':
      case 'blockproxy':
      case 'antiproxy':
        await handleDropProxy(chatId, args);
        break;

      case 'autodigest':
      case 'digest':
        await handleAutoDigest(chatId, args);
        break;

      case 'adduser':
      case 'addadmin':
        await handleAddUser(chatId, args);
        break;

      case 'deluser':
      case 'deladmin':
        await handleDelUser(chatId, args);
        break;

      case 'users':
      case 'admins':
        await handleUsers(chatId);
        break;

      case 'auth':
      case 'login':
        bot.sendMessage(chatId, '✅ <b>[ALREADY AUTHENTICATED]</b>\nYour session is active with full Administrator privileges.', { parse_mode: 'HTML' });
        break;

      case 'logout':
        await deauthenticateUser(userId);
        bot.sendMessage(chatId, '🔒 <b>[SESSION REVOKED]</b>\nYou have been logged out. Send <code>/auth &lt;password&gt;</code> to re-authenticate.', { parse_mode: 'HTML' });
        break;

      case 'whoami':
      case 'authstatus':
      case 'user':
        await handleWhoAmI(chatId, msg.from);
        break;

      case 'blockall':
      case 'lockdown':
        await handleBlockAll(chatId, args);
        break;

      case 'unblockall':
      case 'unlockdown':
      case 'unlock':
        await handleUnblockAll(chatId);
        break;

      case 'banall':
        await handleBanAll(chatId, args);
        break;

      case 'unbanall':
        await handleUnbanAll(chatId);
        break;

      case 'whois':
      case 'geo':
        await handleWhois(chatId, args);
        break;

      case 'sysinfo':
      case 'host':
      case 'server':
        await handleSysInfo(chatId);
        break;

      case 'logs':
      case 'lastlogs':
      case 'securitylogs':
        await handleLogs(chatId, args);
        break;

      case 'rules':
      case 'config':
      case 'thresholds':
        await handleRules(chatId);
        break;

      case 'setlimit':
        await handleSetLimit(chatId, args);
        break;

      case 'setburst':
        await handleSetBurst(chatId, args);
        break;

      case 'setbandur':
        await handleSetBanDur(chatId, args);
        break;

      case 'flush':
        await handleFlush(chatId);
        break;

      case 'reload':
      case 'restart':
        await handleReload(chatId);
        break;

      case 'ban':
        await handleBan(chatId, args);
        break;

      case 'unban':
        await handleUnban(chatId, args);
        break;

      case 'whitelist':
      case 'addowner':
        await handleWhitelist(chatId, args);
        break;

      case 'delowner':
      case 'unwhitelist':
        await handleDelOwner(chatId, args);
        break;

      case 'ownerlist':
      case 'owners':
      case 'myip':
        await handleOwnerList(chatId);
        break;

      case 'stats':
        await handleStats(chatId);
        break;

      case 'top':
      case 'topips':
        await handleTop(chatId);
        break;

      case 'banned':
      case 'blacklist':
        await handleBanned(chatId);
        break;

      case 'inspect':
      case 'ip':
      case 'check':
        await handleInspect(chatId, args);
        break;

      case 'clear':
        await handleClear(chatId);
        break;

      case 'export':
        await handleExport(chatId);
        break;

      case 'ping':
        await handlePing(chatId);
        break;

      default:
        bot.sendMessage(chatId, `
❓ <b>[UNKNOWN COMMAND: <code>/${commandRaw}</code>]</b>
━━━━━━━━━━━━━━━━━━━━
The command does not exist or has invalid syntax.

👉 Tap the <b>Menu [/]</b> button or send <b>/menu</b> to view all available commands.
        `.trim(), { parse_mode: 'HTML' });
        break;
    }
  } catch (err) {
    reportCommandError(chatId, `/${commandRaw}`, err);
  }
}

/**
 * Initialize Telegram Bot & Listeners
 */
function initTelegramBot() {
  if (!isTelegramConfigured()) {
    console.log('[TELEGRAM BOT] ⚠️ TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID missing in config.txt. Bot disabled.');
    return null;
  }

  if (bot) return bot;

  try {
    const pollingEnabled = isMasterWorker;
    bot = new TelegramBot(config.TELEGRAM_BOT_TOKEN, { polling: pollingEnabled });

    if (pollingEnabled) {
      console.log('[TELEGRAM BOT] 🤖 Bot initialized and polling commands on Master Worker (ID: 0).');

      // Load existing authenticated users from Redis
      loadAuthenticatedUsers();

      bot.setMyCommands(BOT_COMMANDS).then(() => {
        console.log('[TELEGRAM BOT] 📋 Registered extended command shortcuts with Telegram Menu button.');
      }).catch(err => {
        console.warn('[TELEGRAM BOT] ⚠️ Failed to register commands with Telegram:', err.message);
      });

      startDdosLiveMonitor();
      startHardwareMonitor();
      startScheduledDigest();

      // ================= MESSAGE LISTENER =================
      bot.on('message', async (msg) => {
        await dispatchTelegramMessage(msg);
      });

      // ================= CALLBACK QUERY LISTENER (INLINE BUTTONS) =================
      bot.on('callback_query', async (query) => {
        const userId = String(query.from ? query.from.id : query.message.chat.id);
        const chatId = query.message.chat.id;

        // Security check for button clicks
        const isAuth = await isUserAuthenticated(userId);
        if (!isAuth) {
          return bot.answerCallbackQuery(query.id, {
            text: '🔒 Authentication required! Please send /auth <password>',
            show_alert: true
          });
        }

        const data = query.data || '';

        try {
          if (data === 'cmd_live') {
            bot.answerCallbackQuery(query.id, { text: 'Scanning live ingress & DDoS streams...' });
            await handleLive(chatId);
          } else if (data === 'cmd_underattack_prompt' || data === 'cmd_underattack_on') {
            bot.answerCallbackQuery(query.id, { text: 'Enabling Under Attack Mode...' });
            await handleUnderAttack(chatId, ['on']);
          } else if (data === 'cmd_underattack_off') {
            bot.answerCallbackQuery(query.id, { text: 'Disabling Under Attack Mode...' });
            await handleUnderAttack(chatId, ['off']);
          } else if (data === 'cmd_cf_menu') {
            bot.answerCallbackQuery(query.id, { text: 'Loading Cloudflare Edge Settings...' });
            await handleCloudflareLevel(chatId, []);
          } else if (data === 'cmd_cf_under_attack') {
            bot.answerCallbackQuery(query.id, { text: 'Setting Cloudflare to Under Attack...' });
            await handleCloudflareLevel(chatId, ['under_attack']);
          } else if (data === 'cmd_cf_high') {
            bot.answerCallbackQuery(query.id, { text: 'Setting Cloudflare to High...' });
            await handleCloudflareLevel(chatId, ['high']);
          } else if (data === 'cmd_cf_medium') {
            bot.answerCallbackQuery(query.id, { text: 'Setting Cloudflare to Medium...' });
            await handleCloudflareLevel(chatId, ['medium']);
          } else if (data === 'cmd_cf_low') {
            bot.answerCallbackQuery(query.id, { text: 'Setting Cloudflare to Low...' });
            await handleCloudflareLevel(chatId, ['low']);
          } else if (data === 'cmd_snapshot') {
            bot.answerCallbackQuery(query.id, { text: 'Generating Threat Snapshot...' });
            await handleSnapshot(chatId);
          } else if (data === 'cmd_dropproxy_toggle') {
            bot.answerCallbackQuery(query.id, { text: 'Toggling Datacenter Proxy Drop...' });
            await handleDropProxy(chatId, []);
          } else if (data === 'cmd_countryrules') {
            bot.answerCallbackQuery(query.id, { text: 'Fetching Geo-blocking Rules...' });
            await handleCountryRules(chatId);
          } else if (data === 'cmd_unblockcountry_all') {
            bot.answerCallbackQuery(query.id, { text: 'Unblocking all countries...' });
            await handleUnblockCountry(chatId, ['all']);
          } else if (data === 'cmd_blockall_prompt' || data === 'cmd_blockall') {
            bot.answerCallbackQuery(query.id, { text: 'Activating Lockdown...' });
            await handleBlockAll(chatId, []);
          } else if (data === 'cmd_blockall_15m') {
            bot.answerCallbackQuery(query.id, { text: 'Lockdown 15m...' });
            await handleBlockAll(chatId, ['15m']);
          } else if (data === 'cmd_blockall_1h') {
            bot.answerCallbackQuery(query.id, { text: 'Lockdown 1h...' });
            await handleBlockAll(chatId, ['1h']);
          } else if (data === 'cmd_unblockall') {
            bot.answerCallbackQuery(query.id, { text: 'Lifting Lockdown...' });
            await handleUnblockAll(chatId);
          } else if (data === 'cmd_banall') {
            bot.answerCallbackQuery(query.id, { text: 'Banning all foreign clients...' });
            await handleBanAll(chatId, ['2h']);
          } else if (data === 'cmd_unbanall') {
            bot.answerCallbackQuery(query.id, { text: 'Unbanning all clients...' });
            await handleUnbanAll(chatId);
          } else if (data === 'cmd_sysinfo') {
            bot.answerCallbackQuery(query.id, { text: 'Fetching Host Metrics...' });
            await handleSysInfo(chatId);
          } else if (data === 'cmd_logs') {
            bot.answerCallbackQuery(query.id, { text: 'Fetching Security Logs...' });
            await handleLogs(chatId, []);
          } else if (data === 'cmd_rules') {
            bot.answerCallbackQuery(query.id, { text: 'Fetching Rules...' });
            await handleRules(chatId);
          } else if (data === 'cmd_flush') {
            bot.answerCallbackQuery(query.id, { text: 'Flushing Rate Limits...' });
            await handleFlush(chatId);
          } else if (data === 'cmd_reload') {
            bot.answerCallbackQuery(query.id, { text: 'Reloading Cluster...' });
            await handleReload(chatId);
          } else if (data === 'cmd_ownerlist') {
            bot.answerCallbackQuery(query.id, { text: 'Fetching Owner List...' });
            await handleOwnerList(chatId);
          } else if (data === 'cmd_stats') {
            bot.answerCallbackQuery(query.id, { text: 'Updating Stats...' });
            await handleStats(chatId);
          } else if (data === 'cmd_banned') {
            bot.answerCallbackQuery(query.id, { text: 'Fetching Blacklist...' });
            await handleBanned(chatId);
          } else if (data === 'cmd_top') {
            bot.answerCallbackQuery(query.id, { text: 'Fetching Top IPs...' });
            await handleTop(chatId);
          } else if (data === 'cmd_export') {
            bot.answerCallbackQuery(query.id, { text: 'Exporting Excel...' });
            await handleExport(chatId);
          } else if (data === 'cmd_ping') {
            bot.answerCallbackQuery(query.id, { text: 'Pinging...' });
            await handlePing(chatId);
          } else if (data === 'cmd_clear') {
            bot.answerCallbackQuery(query.id, { text: 'Clearing Data...' });
            await handleClear(chatId);
          } else if (data.startsWith('whois_')) {
            const ip = data.replace('whois_', '').trim();
            bot.answerCallbackQuery(query.id, { text: `Querying ${ip}...` });
            await handleWhois(chatId, [ip]);
          } else if (data.startsWith('whitelist_')) {
            const ip = data.replace('whitelist_', '').trim();
            bot.answerCallbackQuery(query.id, { text: `Whitelisting ${ip}...` });
            await handleWhitelist(chatId, [ip]);
          } else if (data.startsWith('unban_')) {
            const ip = data.replace('unban_', '').trim();
            await redis.del(`blacklist:${ip}`, `rate_limit:${ip}`, `burst:${ip}`);
            await redis.publish('anti_ddos_sync', `UNBAN:${ip}`).catch(() => {});
            bot.answerCallbackQuery(query.id, { text: `Unbanned ${ip}!` });
            bot.sendMessage(chatId, `✅ <b>[UNBANNED]</b> IP: <code>${ip}</code> unbanned via button action.`, { parse_mode: 'HTML' });
          } else if (data.startsWith('ban_')) {
            const parts = data.split('_');
            const ip = parts[1];
            const durationStr = parts[2] || '30m';
            const { seconds, human } = parseDuration(durationStr, 1800);
            await redis.set(`blacklist:${ip}`, `Ban via Telegram button (${human})`, 'EX', seconds);
            await redis.publish('anti_ddos_sync', `BAN:${ip}`).catch(() => {});
            bot.answerCallbackQuery(query.id, { text: `Banned ${ip} (${human})!` });
            bot.sendMessage(chatId, `🚫 <b>[TARGET BANNED]</b>\nIP: <code>${ip}</code> banned for <b>${human}</b>!`, {
              parse_mode: 'HTML',
              reply_markup: {
                inline_keyboard: [[{ text: `🔓 Unban Now`, callback_data: `unban_${ip}` }]]
              }
            });
          }
        } catch (cbErr) {
          reportCommandError(chatId, `Callback Query: ${data}`, cbErr);
        }
      });

      bot.on('polling_error', (error) => {
        if (error.code !== 'EFATAL') {
          console.warn('[TELEGRAM POLLING WARNING]', error.message);
        }
      });
    }

    return bot;
  } catch (error) {
    console.error('[TELEGRAM INIT ERROR] Failed to initialize Telegram Bot:', error.message);
    return null;
  }
}

module.exports = {
  initTelegramBot,
  isTelegramConfigured,
  startDdosLiveMonitor,
  activateLockdown,
  deactivateLockdown,
  isUserAuthenticated,
  authenticateUser,
  deauthenticateUser
};
