const excelService = require('./excelService');

module.exports = {
  writeIpReport: excelService.exportIpReportToExcel,
  EXCEL_FILE_PATH: excelService.getExcelFilePath()
};