/**
 * Middleware to intercept requests scanning for secret configuration files and immediately return 404 Not Found
 */
const SENSITIVE_PATTERNS = [
  /(^\/|\/)(\.env|\.git|\.svn|config\.txt|package\.json|package-lock\.json|ecosystem\.config\.js)(\/|$|\?)/i,
  /(^\/|\/)(certs|data|backups)(\/|$|\?)/i,
  /\.(pem|key|crt|rdb|enc|bak|swp|sql|log|tmp|conf|ini|sh|bash)$/i,
  /(\.\.|\%2e\%2e|\%00|\%2f\.\.)/i
];

function blockSensitiveFiles(req, res, next) {
  const requestedUrl = decodeURIComponent(req.originalUrl || req.url || '');

  const isSensitive = SENSITIVE_PATTERNS.some(pattern => pattern.test(requestedUrl));

  if (isSensitive) {
    return res.status(404).json({
      success: false,
      message: 'Not Found'
    });
  }

  next();
}

module.exports = blockSensitiveFiles;
