const redis = require('../redisClient');
const getRealIp = require('../utils/getRealIp');
const config = require('../configLoader');
const { isOwnerIp } = require('../utils/serverPublicIp');
const { verifyClearanceCookie, renderChallengePage } = require('../utils/challengeEngine');
const { isSubnetBanned, loadBannedSubnets } = require('../utils/subnetManager');
const { lookupIpGeo } = require('../utils/geoLookup');

// In-memory Blacklist Cache (0ms local lookup)
const localBlacklist = new Set();
const blockedCountries = new Set();
let isEmergencyLockdown = false;
let isUnderAttackMode = false;
let dropDatacenterProxies = false;
let lastSyncTime = 0;
const SYNC_INTERVAL_MS = 3000;

// Dynamic In-Memory Overrides for Security Thresholds
let dynamicBurstMax = null;
let dynamicRateLimitMax = null;
let dynamicBanDurationSec = null;

// Known Datacenter / Cloud Proxy Hosting Keywords
const DATACENTER_KEYWORDS_REGEX = /(digitalocean|amazon|aws|hetzner|ovh|vultr|linode|choopa|m247|leaseweb|datapacket|contabo|hostinger|kamatera|cogent|psychz|servermania|datacenter|hosting|proxy|tor|vpn)/i;

// Redis Subscriber for Real-time Cluster Sync across 12 PM2 Workers
let subClient = null;
try {
  subClient = redis.duplicate();
  subClient.subscribe('anti_ddos_sync', (err) => {
    if (err) {
      console.warn('[REDIS PUB/SUB] ⚠️ Failed to subscribe to anti_ddos_sync:', err.message);
    }
  });

  subClient.on('message', (channel, message) => {
    if (channel === 'anti_ddos_sync') {
      if (message.startsWith('BAN:')) {
        const ip = message.slice(4).trim();
        if (ip === '*') {
          syncBlacklistFromRedis();
        } else if (ip) {
          localBlacklist.add(ip);
        }
      } else if (message.startsWith('UNBAN:')) {
        const ip = message.slice(6).trim();
        if (ip === '*') {
          localBlacklist.clear();
        } else if (ip) {
          localBlacklist.delete(ip);
        }
      } else if (message === 'LOCKDOWN:ON') {
        isEmergencyLockdown = true;
        console.warn('[SECURITY ALERT] 🚨 EMERGENCY LOCKDOWN ACTIVATED (100% Ingress Dropped).');
      } else if (message === 'LOCKDOWN:OFF') {
        isEmergencyLockdown = false;
        console.log('[SECURITY ALERT] 🟢 EMERGENCY LOCKDOWN LIFTED (Normal Traffic Resumed).');
      } else if (message === 'CHALLENGE:ON') {
        isUnderAttackMode = true;
        console.warn('[SECURITY ALERT] 🔥 UNDER ATTACK MODE (JS CHALLENGE) ENABLED.');
      } else if (message === 'CHALLENGE:OFF') {
        isUnderAttackMode = false;
        console.log('[SECURITY ALERT] 🟢 UNDER ATTACK MODE (JS CHALLENGE) DISABLED.');
      } else if (message === 'DROP_PROXY:ON') {
        dropDatacenterProxies = true;
        console.warn('[SECURITY ALERT] 🏢 DATACENTER & CLOUD PROXY DROP ACTIVATED.');
      } else if (message === 'DROP_PROXY:OFF') {
        dropDatacenterProxies = false;
        console.log('[SECURITY ALERT] 🟢 DATACENTER & CLOUD PROXY DROP DEACTIVATED.');
      } else if (message.startsWith('BLOCK_COUNTRY:')) {
        const cc = message.slice(14).trim().toUpperCase();
        if (cc) blockedCountries.add(cc);
      } else if (message.startsWith('UNBLOCK_COUNTRY:')) {
        const cc = message.slice(16).trim().toUpperCase();
        if (cc === '*') blockedCountries.clear();
        else if (cc) blockedCountries.delete(cc);
      } else if (message.startsWith('CONFIG:')) {
        const parts = message.split(':');
        const key = parts[1];
        const val = parseInt(parts[2], 10);
        if (key === 'BURST' && !isNaN(val)) dynamicBurstMax = val;
        if (key === 'LIMIT' && !isNaN(val)) dynamicRateLimitMax = val;
        if (key === 'DURATION' && !isNaN(val)) dynamicBanDurationSec = val;
      }
    }
  });
} catch (e) {
  console.warn('[REDIS PUB/SUB ERROR]:', e.message);
}

/**
 * Record a security incident in Redis Ring-Buffer (max 100 entries)
 */
function recordSecurityLog(type, ip, reason) {
  const entry = JSON.stringify({
    time: new Date().toISOString(),
    type,
    ip,
    reason: reason ? String(reason).slice(0, 120) : 'Security Violation'
  });
  redis.pipeline()
    .lpush('system:security_logs', entry)
    .ltrim('system:security_logs', 0, 99)
    .exec()
    .catch(() => {});
}

/**
 * Record blocked DDoS request for Real-time Speedometer & Per-IP Tracking
 */
function recordDdosHit(clientIp) {
  const now = Date.now();
  const currentSec = Math.floor(now / 1000);
  const key = `ddos_sec:${currentSec}`;
  const pipeline = redis.pipeline();
  pipeline.incr(key);
  pipeline.expire(key, 300);
  pipeline.incr('system:total_ddos_mitigated_cumulative');

  if (clientIp) {
    const trackerKey = `ip_tracker:${clientIp}`;
    const ttl = Number(config.TRACKER_TTL_SEC) || 86400;
    pipeline.hincrby(trackerKey, 'count', 1);
    pipeline.hincrby(trackerKey, 'blocked_count', 1);
    pipeline.hsetnx(trackerKey, 'first_seen', now);
    pipeline.hset(trackerKey, 'last_seen', now);
    pipeline.expire(trackerKey, ttl);
    pipeline.sadd('tracked_ips_set', clientIp);
  }

  pipeline.exec().catch(() => {});
}

/**
 * Record requests dropped during Emergency Lockdown
 */
function recordLockdownDrop(clientIp) {
  recordDdosHit(clientIp);
  recordSecurityLog('LOCKDOWN_DROP', clientIp, 'Dropped during Emergency Lockdown');
  redis.incr('system:lockdown_dropped_total').catch(() => {});
}

/**
 * Sync Blacklist, Lockdown, Subnets, and Rules from Redis into Worker RAM
 */
async function syncBlacklistFromRedis() {
  const now = Date.now();
  if (now - lastSyncTime < SYNC_INTERVAL_MS) return;
  lastSyncTime = now;

  try {
    const pipeline = redis.pipeline();
    pipeline.keys('blacklist:*');
    pipeline.get('system:lockdown_mode');
    pipeline.get('system:under_attack_mode');
    pipeline.get('system:drop_datacenter_proxies');
    pipeline.smembers('system:blocked_countries');
    pipeline.get('system:config:rate_limit_max');
    pipeline.get('system:config:rate_limit_burst');
    pipeline.get('system:config:ban_duration_sec');

    const results = await pipeline.exec();

    const keysRes = results[0];
    const lockdownRes = results[1];
    const challengeRes = results[2];
    const proxyRes = results[3];
    const countriesRes = results[4];
    const limitRes = results[5];
    const burstRes = results[6];
    const durRes = results[7];

    if (keysRes && !keysRes[0] && Array.isArray(keysRes[1])) {
      localBlacklist.clear();
      keysRes[1].forEach(k => {
        const ip = k.replace('blacklist:', '');
        if (ip) localBlacklist.add(ip);
      });
    }

    isEmergencyLockdown = (lockdownRes && lockdownRes[1] === '1');
    isUnderAttackMode = (challengeRes && challengeRes[1] === '1');
    dropDatacenterProxies = (proxyRes && proxyRes[1] === '1');

    if (countriesRes && Array.isArray(countriesRes[1])) {
      blockedCountries.clear();
      countriesRes[1].forEach(cc => blockedCountries.add(String(cc).toUpperCase()));
    }

    if (limitRes && limitRes[1]) dynamicRateLimitMax = parseInt(limitRes[1], 10);
    if (burstRes && burstRes[1]) dynamicBurstMax = parseInt(burstRes[1], 10);
    if (durRes && durRes[1]) dynamicBanDurationSec = parseInt(durRes[1], 10);

    await loadBannedSubnets();
  } catch (err) {
    console.error('[REDIS SYNC ERROR] Failed to sync security state:', err.message);
  }
}

// Initial sync on startup
syncBlacklistFromRedis();
setInterval(syncBlacklistFromRedis, SYNC_INTERVAL_MS);

/**
 * Ban IP and broadcast to entire PM2 cluster
 */
async function banIp(ip, reason = 'Rate limit exceeded', durationSec = null) {
  const duration = durationSec || dynamicBanDurationSec || Number(config.BAN_DURATION_SEC) || 1800;
  const blacklistKey = `blacklist:${ip}`;

  try {
    localBlacklist.add(ip);
    await redis.set(blacklistKey, reason, 'EX', duration);
    await redis.publish('anti_ddos_sync', `BAN:${ip}`).catch(() => {});
    recordSecurityLog('AUTO_BAN', ip, `${reason} (${duration}s)`);
    console.warn(`[SECURITY BAN] 🚫 Banned ${ip} for ${duration}s. Reason: ${reason}`);
  } catch (error) {
    console.error(`[REDIS BAN ERROR] Failed to ban IP ${ip}:`, error.message);
  }
}

/**
 * Unban local IP from Worker RAM
 */
function unbanLocalIp(ip) {
  localBlacklist.delete(ip);
}

// Exploit Probing URL Signatures
const EXPLOIT_PROBE_REGEX = /\.(env|git|htaccess|htpasswd|ini|bak|conf|config|sql|dump|tar|gz|zip)$|(\/phpmyadmin|\/pma|\/adminer|\/wp-admin|\/wp-login|\/xmlrpc|\/setup\.cgi|\/shell|\/solr|\/actuator|\/eval-stdin|\/cgi-bin|\/\.aws\/credentials|\/\.ssh\/id_rsa|\/etc\/passwd|\/etc\/shadow)/i;

// Malicious Automated Scanner User-Agents
const MALICIOUS_UA_REGEX = /(sqlmap|nikto|nmap|nuclei|masscan|zgrab|gobuster|dirbuster|wpscan|hydra|acunetix|nessus|openvas|python-requests\/|go-http-client|curl\/[1-6]\.|libwww-perl)/i;

/**
 * High-Performance Anti-DDoS & Multi-Tier Rate Limiting Middleware
 */
const rateLimiterAndBlacklist = async (req, res, next) => {
  const ip = getRealIp(req);

  // 1. OWNER WHITELIST PRIVILEGE (Bypass all security checks)
  if (isOwnerIp(ip)) {
    return next();
  }

  // 2. TIER 0: Emergency Lockdown (Drop 100% Ingress at 0ms)
  if (isEmergencyLockdown) {
    recordLockdownDrop(ip);
    res.writeHead(503, {
      'Content-Type': 'application/json',
      'Retry-After': '60',
      'Connection': 'close'
    });
    return res.end(JSON.stringify({
      error: 'Service Unavailable',
      message: 'Server is in Emergency Lockdown mode. Access denied.',
      ip
    }));
  }

  // 3. TIER 1: In-Memory Fast Drop (0ms local RAM check)
  if (localBlacklist.has(ip)) {
    recordDdosHit(ip);
    res.writeHead(403, {
      'Content-Type': 'application/json',
      'Connection': 'close'
    });
    return res.end(JSON.stringify({
      error: 'Forbidden',
      message: 'Your IP is blacklisted due to malicious activity.',
      ip
    }));
  }

  // 4. TIER 1.5: Subnet /24 Blocking
  if (isSubnetBanned(ip)) {
    recordDdosHit(ip);
    res.writeHead(403, {
      'Content-Type': 'application/json',
      'Connection': 'close'
    });
    return res.end(JSON.stringify({
      error: 'Forbidden',
      message: 'Your IP subnet is blacklisted.',
      ip
    }));
  }

  const requestedUrl = req.url || '';
  const userAgent = req.headers['user-agent'] || '';

  // 5. TIER 2: Signature Exploit Scanner Scan (Instant 1-hour Ban)
  if (EXPLOIT_PROBE_REGEX.test(requestedUrl)) {
    recordDdosHit(ip);
    await banIp(ip, `Exploit probe attempt: ${requestedUrl.slice(0, 50)}`, 3600);
    res.writeHead(403, { 'Content-Type': 'application/json', 'Connection': 'close' });
    return res.end(JSON.stringify({ error: 'Forbidden', message: 'Malicious activity detected.', ip }));
  }

  if (MALICIOUS_UA_REGEX.test(userAgent)) {
    recordDdosHit(ip);
    await banIp(ip, `Malicious Scanner User-Agent: ${userAgent.slice(0, 50)}`, 3600);
    res.writeHead(403, { 'Content-Type': 'application/json', 'Connection': 'close' });
    return res.end(JSON.stringify({ error: 'Forbidden', message: 'Scanner tool blocked.', ip }));
  }

  // 6. TIER 2.5: Geo-Blocking & Datacenter Proxy Drop
  if (blockedCountries.size > 0 || dropDatacenterProxies) {
    const geo = await lookupIpGeo(ip);

    // Country Block Check
    if (blockedCountries.size > 0 && geo.countryCode && blockedCountries.has(geo.countryCode.toUpperCase())) {
      recordDdosHit(ip);
      res.writeHead(403, { 'Content-Type': 'application/json', 'Connection': 'close' });
      return res.end(JSON.stringify({
        error: 'Forbidden',
        message: `Traffic from ${geo.country} (${geo.countryCode}) is currently restricted.`,
        ip
      }));
    }

    // Datacenter Cloud Proxy Drop Check
    if (dropDatacenterProxies) {
      const ispOrg = `${geo.isp} ${geo.org} ${geo.as}`;
      if (DATACENTER_KEYWORDS_REGEX.test(ispOrg)) {
        recordDdosHit(ip);
        res.writeHead(403, { 'Content-Type': 'application/json', 'Connection': 'close' });
        return res.end(JSON.stringify({
          error: 'Forbidden',
          message: 'Datacenter / Cloud Proxy connections are blocked.',
          ip
        }));
      }
    }
  }

  // 7. TIER 3: Under Attack Mode (JavaScript Proof-of-Work Challenge)
  if (isUnderAttackMode) {
    const isStaticAsset = /\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|map)$/i.test(requestedUrl);
    const isChallengeEndpoint = requestedUrl.startsWith('/api/challenge-verify');

    if (!isStaticAsset && !isChallengeEndpoint) {
      const hasClearance = verifyClearanceCookie(ip, req.headers.cookie);
      if (!hasClearance) {
        recordDdosHit(ip);
        const html = renderChallengePage(ip, req.url);
        res.writeHead(429, {
          'Content-Type': 'text/html; charset=utf-8',
          'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0'
        });
        return res.end(html);
      }
    }
  }

  // 8. TIER 4: Dual-Window Rate Limiter (Burst 3s + Sustained 60s)
  const blacklistKey = `blacklist:${ip}`;
  const burstKey = `burst:${ip}`;
  const rateLimitKey = `rate_limit:${ip}`;

  const maxBurst = dynamicBurstMax || Number(config.RATE_LIMIT_BURST_MAX) || 15;
  const maxSustained = dynamicRateLimitMax || Number(config.RATE_LIMIT_MAX_REQUESTS) || 50;
  const sustainedWindow = Number(config.RATE_LIMIT_WINDOW_SEC) || 60;
  const banDuration = dynamicBanDurationSec || Number(config.BAN_DURATION_SEC) || 1800;

  try {
    const pipeline = redis.pipeline();
    pipeline.ttl(blacklistKey);
    pipeline.incr(burstKey);
    pipeline.incr(rateLimitKey);

    const [ttlRes, burstRes, sustainedRes] = await pipeline.exec();

    const banTtl = (ttlRes && !ttlRes[0]) ? Number(ttlRes[1]) : -2;
    const currentBurst = (burstRes && !burstRes[0]) ? Number(burstRes[1]) : 1;
    const currentSustained = (sustainedRes && !sustainedRes[0]) ? Number(sustainedRes[1]) : 1;

    if (banTtl > -2) {
      recordDdosHit(ip);
      localBlacklist.add(ip);
      res.writeHead(403, { 'Content-Type': 'application/json', 'Connection': 'close' });
      return res.end(JSON.stringify({
        error: 'Forbidden',
        message: 'Your IP has been blacklisted.',
        ip,
        timeRemainingSec: banTtl > 0 ? banTtl : 'Indefinitely'
      }));
    }

    if (currentBurst === 1) {
      redis.expire(burstKey, 3).catch(() => {});
    }
    if (currentSustained === 1) {
      redis.expire(rateLimitKey, sustainedWindow).catch(() => {});
    }

    // A. Check Burst Limit
    if (currentBurst > maxBurst) {
      recordDdosHit(ip);
      await banIp(ip, `HTTP Flood Burst exceeded (${currentBurst}/${maxBurst} reqs in 3s)`, banDuration);
      res.writeHead(429, { 'Content-Type': 'application/json', 'Connection': 'close' });
      return res.end(JSON.stringify({
        error: 'Too Many Requests',
        message: `Burst flood limit exceeded. IP blacklisted for ${banDuration}s.`,
        ip
      }));
    }

    // B. Check Sustained Limit
    if (currentSustained > maxSustained) {
      recordDdosHit(ip);
      await banIp(ip, `Sustained Rate Limit exceeded (${currentSustained}/${maxSustained} reqs in ${sustainedWindow}s)`, banDuration);
      res.writeHead(429, { 'Content-Type': 'application/json', 'Connection': 'close' });
      return res.end(JSON.stringify({
        error: 'Too Many Requests',
        message: `Rate limit exceeded. IP blacklisted for ${banDuration}s.`,
        ip
      }));
    }

    next();
  } catch (error) {
    console.error(`[RATE LIMITER ERROR] Processing error for IP ${ip}:`, error.message);
    next();
  }
};

module.exports = rateLimiterAndBlacklist;
module.exports.banIp = banIp;
module.exports.unbanLocalIp = unbanLocalIp;
module.exports.recordDdosHit = recordDdosHit;
module.exports.recordLockdownDrop = recordLockdownDrop;
module.exports.recordSecurityLog = recordSecurityLog;
module.exports.isLockdown = () => isEmergencyLockdown;
module.exports.isUnderAttack = () => isUnderAttackMode;
module.exports.isDropProxies = () => dropDatacenterProxies;
module.exports.getBlockedCountries = () => Array.from(blockedCountries);
