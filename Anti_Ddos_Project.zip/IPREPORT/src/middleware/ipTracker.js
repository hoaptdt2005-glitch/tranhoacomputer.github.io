const redis = require('../redisClient');
const getRealIp = require('../utils/getRealIp');
const { isIgnoredIp } = require('../utils/serverPublicIp');
const config = require('../configLoader');

/**
 * Format timestamp to YYYY-MM-DD-HH:mm format for time-series traffic stats
 * @param {number} timestamp 
 * @returns {string}
 */
function getMinuteKey(timestamp = Date.now()) {
  const d = new Date(timestamp);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}-${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/**
 * Middleware to track and store IP & traffic information over time
 */
const ipTracker = async (req, res, next) => {
  const ip = getRealIp(req);

  // Do not record statistics for Localhost or Public IP of the server itself
  if (isIgnoredIp(ip)) {
    return next();
  }

  const trackerKey = `ip_tracker:${ip}`;
  const now = Date.now();
  const ttl = Number(config.TRACKER_TTL_SEC) || 86400;
  const minuteKey = getMinuteKey(now);
  const trafficKey = `traffic_stats:${minuteKey}`;

  try {
    // Use Redis Pipeline to group write commands, optimizing I/O and high performance
    const pipeline = redis.pipeline();

    // 1. Update IP information in Hash ip_tracker:{ip}
    pipeline.hincrby(trackerKey, 'count', 1);
    pipeline.hsetnx(trackerKey, 'first_seen', now);
    pipeline.hset(trackerKey, 'last_seen', now);
    pipeline.expire(trackerKey, ttl);

    // 2. Add IP to Set list to query IP list quickly
    pipeline.sadd('tracked_ips_set', ip);

    // 3. Record number of requests by timeframe (seconds & minutes) for Chart.js
    const currentSec = Math.floor(now / 1000);
    pipeline.incr(trafficKey);
    pipeline.expire(trafficKey, 86400); // Store for 24 hours
    pipeline.incr(`traffic_sec:${currentSec}`);
    pipeline.expire(`traffic_sec:${currentSec}`, 3600); // Store by second for 1 hour

    // Execute pipeline
    await pipeline.exec();
  } catch (error) {
    // Do not interrupt the request flow if Redis encounters an issue
    console.error(`[IP TRACKER ERROR] Error tracking IP ${ip}:`, error.message);
  }

  next();
};

module.exports = ipTracker;
module.exports.getMinuteKey = getMinuteKey;
