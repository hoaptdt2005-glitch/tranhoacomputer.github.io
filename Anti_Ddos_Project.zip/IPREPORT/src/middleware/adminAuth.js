const crypto = require('crypto');
const config = require('../configLoader');

/**
 * Safely compare Secret Key string using crypto.timingSafeEqual (Prevent Timing Attack)
 * @param {string} provided 
 * @param {string} expected 
 * @returns {boolean}
 */
function timingSafeCompare(provided, expected) {
  if (!provided || !expected || typeof provided !== 'string' || typeof expected !== 'string') {
    return false;
  }

  const hashProvided = crypto.createHash('sha256').update(provided).digest();
  const hashExpected = crypto.createHash('sha256').update(expected).digest();

  return crypto.timingSafeEqual(hashProvided, hashExpected);
}

/**
 * Extract API Key from Header or Query Parameter
 * @param {import('express').Request} req 
 * @returns {string}
 */
function extractApiKey(req) {
  if (req.headers && req.headers['x-admin-key']) {
    return String(req.headers['x-admin-key']).trim();
  }

  if (req.headers && req.headers['authorization']) {
    const auth = String(req.headers['authorization']).trim();
    if (auth.toLowerCase().startsWith('bearer ')) {
      return auth.slice(7).trim();
    }
    return auth;
  }

  if (req.query && req.query.key) {
    return String(req.query.key).trim();
  }

  return '';
}

/**
 * Middleware to protect sensitive administrative APIs
 */
function adminAuth(req, res, next) {
  const expectedKey = config.ADMIN_API_KEY ? String(config.ADMIN_API_KEY).trim() : '';

  // If ADMIN_API_KEY is not configured (default open for dev)
  if (!expectedKey) {
    return next();
  }

  const providedKey = extractApiKey(req);

  if (!providedKey || !timingSafeCompare(providedKey, expectedKey)) {
    return res.status(401).json({
      success: false,
      message: 'Unauthorized: Invalid or missing administrative credentials'
    });
  }

  next();
}

module.exports = adminAuth;
module.exports.adminAuth = adminAuth;
module.exports.timingSafeCompare = timingSafeCompare;
