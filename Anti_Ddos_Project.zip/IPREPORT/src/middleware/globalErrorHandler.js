const config = require('../configLoader');
const getRealIp = require('../utils/getRealIp');

/**
 * System-wide centralized error handling middleware (Global Error Handler)
 * OWASP API Security Standard: Completely hide Stack Trace in Production environment
 */
function globalErrorHandler(err, req, res, next) {
  const isProduction = (config.NODE_ENV || process.env.NODE_ENV) === 'production';
  const clientIp = getRealIp(req);
  const statusCode = err.status || err.statusCode || 500;

  // Handle Malformed JSON error from Body Parser
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({
      success: false,
      message: 'Invalid JSON payload structure'
    });
  }

  // Secure internal error logging on Server (Console / PM2)
  console.error(`[GLOBAL ERROR] ❌ ${req.method} ${req.originalUrl} | IP: ${clientIp} | Status: ${statusCode}`);
  console.error(err.stack || err.message || err);

  if (isProduction) {
    return res.status(statusCode).json({
      success: false,
      message: statusCode === 404 ? 'Resource not found' : 'Internal Server Error'
    });
  }

  return res.status(statusCode).json({
    success: false,
    message: err.message || 'Internal Server Error',
    stack: err.stack
  });
}

module.exports = globalErrorHandler;
