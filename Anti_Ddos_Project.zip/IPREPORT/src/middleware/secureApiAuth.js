const crypto = require('crypto');
const config = require('../configLoader');

/**
 * Compare two security strings using SHA-256 Buffer and crypto.timingSafeEqual
 * Absolutely prevent Timing Attack (Exploiting character matching time difference).
 * @param {string} provided - Key sent by Client
 * @param {string} expected - Admin Key configured on Server
 * @returns {boolean}
 */
function timingSafeCompare(provided, expected) {
  if (!provided || !expected || typeof provided !== 'string' || typeof expected !== 'string') {
    return false;
  }

  // Hash both strings to SHA-256 to convert to 32 bytes Buffer with fixed length
  const hashProvided = crypto.createHash('sha256').update(provided).digest();
  const hashExpected = crypto.createHash('sha256').update(expected).digest();

  return crypto.timingSafeEqual(hashProvided, hashExpected);
}

/**
 * Extract API Key from Request (Header x-admin-key, Authorization: Bearer, or Query Param)
 * @param {import('express').Request} req 
 * @returns {string}
 */
function extractApiKey(req) {
  // 1. Header: x-admin-key
  if (req.headers && req.headers['x-admin-key']) {
    return String(req.headers['x-admin-key']).trim();
  }

  // 2. Header: Authorization: Bearer <key>
  if (req.headers && req.headers['authorization']) {
    const authHeader = String(req.headers['authorization']).trim();
    if (authHeader.toLowerCase().startsWith('bearer ')) {
      return authHeader.slice(7).trim();
    }
    return authHeader;
  }

  // 3. Query Param: ?key=... (Support direct Excel file download / via browser)
  if (req.query && req.query.key) {
    return String(req.query.key).trim();
  }

  return '';
}

/**
 * Middleware to protect sensitive APIs using Secret Admin Key
 */
function requireAdminAuth(req, res, next) {
  const expectedKey = config.ADMIN_API_KEY ? String(config.ADMIN_API_KEY).trim() : '';

  // If ADMIN_API_KEY is not set in config file (default open mode for dev)
  if (!expectedKey) {
    return next();
  }

  const providedKey = extractApiKey(req);

  if (!providedKey || !timingSafeCompare(providedKey, expectedKey)) {
    // Return unified 401 Unauthorized, DO NOT reveal detailed information
    return res.status(401).json({
      success: false,
      message: 'Unauthorized: Invalid or missing authentication credentials'
    });
  }

  next();
}

module.exports = {
  requireAdminAuth,
  timingSafeCompare
};
