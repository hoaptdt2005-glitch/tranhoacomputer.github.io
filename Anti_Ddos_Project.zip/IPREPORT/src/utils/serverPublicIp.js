const https = require('https');
const http = require('http');
const config = require('../configLoader');
const redis = require('../redisClient');

let cachedPublicIp = null;
let lastFetchTime = 0;
const CACHE_TTL_MS = 30 * 60 * 1000; // Auto-refresh once every 30 minutes

// Dynamic Owner IPs Cache in Memory across workers
const dynamicOwnerIps = new Set();

/**
 * Send HTTP/HTTPS request to fetch IP from external services
 */
function fetchIpFromUrl(url, isJson = false) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const req = client.get(url, { timeout: 4000 }, (res) => {
      if (res.statusCode < 200 || res.statusCode >= 300) {
        return reject(new Error(`HTTP Status ${res.statusCode}`));
      }
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          if (isJson) {
            const parsed = JSON.parse(data);
            resolve(parsed.ip || parsed.query || '');
          } else {
            resolve(data.trim());
          }
        } catch (e) {
          reject(e);
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Connection timeout'));
    });
  });
}

/**
 * Automatically find and get the Public IP address of the PC/Server
 * @returns {Promise<string|null>}
 */
async function getHostPublicIp() {
  const now = Date.now();
  if (cachedPublicIp && (now - lastFetchTime < CACHE_TTL_MS)) {
    return cachedPublicIp;
  }

  const providers = [
    { url: 'https://api.ipify.org?format=json', isJson: true },
    { url: 'https://ifconfig.me/ip', isJson: false },
    { url: 'https://icanhazip.com', isJson: false },
    { url: 'https://api.my-ip.io/v2/ip.json', isJson: true }
  ];

  for (const provider of providers) {
    try {
      const ip = await fetchIpFromUrl(provider.url, provider.isJson);
      if (ip && typeof ip === 'string' && ip.length >= 7) {
        cachedPublicIp = ip.trim().replace(/^::ffff:/, '');
        lastFetchTime = now;
        console.log(`[SERVER INFO] 🌐 Identified Server Public IP: ${cachedPublicIp}`);
        return cachedPublicIp;
      }
    } catch (e) {
      // Try the next backup service
    }
  }

  return cachedPublicIp;
}

/**
 * Sync Owner IPs list from Redis
 */
async function syncOwnerIpsFromRedis() {
  try {
    const ips = await redis.smembers('system:owner_ips');
    dynamicOwnerIps.clear();
    ips.forEach(ip => {
      if (ip) dynamicOwnerIps.add(ip.trim());
    });
  } catch (err) {
    // Do not interrupt the flow
  }
}

// Start syncing Owner IPs
syncOwnerIpsFromRedis().catch(() => {});
setInterval(syncOwnerIpsFromRedis, 5000);

/**
 * Add an IP to the Owner Whitelist
 */
async function addOwnerIp(ip) {
  if (!ip) return;
  const cleanIp = String(ip).trim().replace(/^::ffff:/, '');
  dynamicOwnerIps.add(cleanIp);
  try {
    await redis.sadd('system:owner_ips', cleanIp);
    redis.publish('anti_ddos_sync', `OWNER_ADD:${cleanIp}`).catch(() => {});
  } catch (e) {}
}

/**
 * Remove an IP from the Owner Whitelist
 */
async function removeOwnerIp(ip) {
  if (!ip) return;
  const cleanIp = String(ip).trim().replace(/^::ffff:/, '');
  dynamicOwnerIps.delete(cleanIp);
  try {
    await redis.srem('system:owner_ips', cleanIp);
    redis.publish('anti_ddos_sync', `OWNER_DEL:${cleanIp}`).catch(() => {});
  } catch (e) {}
}

/**
 * Get all current Owner IPs
 */
async function getAllOwnerIps() {
  const result = new Set();
  result.add('127.0.0.1');
  if (cachedPublicIp) result.add(cachedPublicIp);
  if (config.IGNORE_IPS) {
    String(config.IGNORE_IPS).split(',').forEach(i => {
      const clean = i.trim();
      if (clean) result.add(clean);
    });
  }
  dynamicOwnerIps.forEach(i => result.add(i));
  return Array.from(result);
}

/**
 * Check if an IP is an exempt Owner / Admin / Whitelisted IP
 * @param {string} ip 
 * @returns {boolean}
 */
function isOwnerIp(ip) {
  if (!ip) return true;
  const cleanIp = String(ip).trim().replace(/^::ffff:/, '');

  // 1. Localhost
  if (
    cleanIp === '127.0.0.1' ||
    cleanIp === 'localhost' ||
    cleanIp === '::1' ||
    cleanIp === '0.0.0.0' ||
    cleanIp === 'unknown'
  ) {
    return true;
  }

  // 2. Public IP of the running server/PC itself
  if (cachedPublicIp && (cleanIp === cachedPublicIp || ip === cachedPublicIp)) {
    return true;
  }

  // 3. IPs in config.txt file (IGNORE_IPS)
  if (config.IGNORE_IPS) {
    const list = String(config.IGNORE_IPS).split(',').map(i => i.trim());
    if (list.includes(cleanIp) || list.includes(ip)) {
      return true;
    }
  }

  // 4. IPs in the dynamic owner whitelist
  if (dynamicOwnerIps.has(cleanIp) || dynamicOwnerIps.has(ip)) {
    return true;
  }

  return false;
}

// Execute fetching Public IP as soon as the app starts
getHostPublicIp().catch((err) => {
  console.warn('[SERVER INFO] Could not fetch Public IP on startup:', err.message);
});

// Automatically check and update Public IP periodically
setInterval(() => {
  getHostPublicIp().catch(() => {});
}, CACHE_TTL_MS);

module.exports = {
  getHostPublicIp,
  isIgnoredIp: isOwnerIp,
  isOwnerIp,
  addOwnerIp,
  removeOwnerIp,
  getAllOwnerIps,
  getCachedPublicIp: () => cachedPublicIp
};
