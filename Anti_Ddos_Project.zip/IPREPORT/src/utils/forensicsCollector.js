const redis = require('../redisClient');
const { lookupIpGeo } = require('./geoLookup');
const { isOwnerIp } = require('./serverPublicIp');

/**
 * Generate full Threat Intelligence & Attack Snapshot Forensic Report
 * @returns {Promise<Object>}
 */
async function generateForensicSnapshot() {
  const trackedIps = await redis.smembers('tracked_ips_set');
  const bannedKeys = await redis.keys('blacklist:*');
  const recentLogs = await redis.lrange('system:security_logs', 0, 99);

  const countryCount = {};
  const asnIspCount = {};
  const topAttackers = [];

  // 1. Analyze Top Ingress / Attacking IPs
  const pipeline = redis.pipeline();
  trackedIps.forEach(ip => pipeline.hgetall(`ip_tracker:${ip}`));
  const trackerResults = await pipeline.exec();

  const ipList = [];
  for (let i = 0; i < trackedIps.length; i++) {
    const data = trackerResults[i] && trackerResults[i][1];
    if (data && data.count) {
      ipList.push({
        ip: trackedIps[i],
        count: parseInt(data.count, 10) || 0,
        lastSeen: data.lastSeen || ''
      });
    }
  }

  ipList.sort((a, b) => b.count - a.count);
  const sampleTop = ipList.slice(0, 25);

  // 2. Perform Geolocation & ASN Analysis on Top Ingress Endpoints
  for (const item of sampleTop) {
    if (isOwnerIp(item.ip)) continue;
    const geo = await lookupIpGeo(item.ip);
    const cKey = `${geo.flag || '🌐'} ${geo.country} (${geo.countryCode})`;
    countryCount[cKey] = (countryCount[cKey] || 0) + item.count;

    const ispKey = geo.isp || geo.org || 'Unknown ISP';
    asnIspCount[ispKey] = (asnIspCount[ispKey] || 0) + item.count;

    topAttackers.push({
      ip: item.ip,
      count: item.count,
      flag: geo.flag,
      country: geo.country,
      isp: geo.isp,
      as: geo.as
    });
  }

  // 3. Sort country and ASN distributions
  const sortedCountries = Object.entries(countryCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8);

  const sortedIsps = Object.entries(asnIspCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8);

  // 4. Analyze Attack Types from Security Logs
  let exploitScanCount = 0;
  let burstFloodCount = 0;
  let sustainedCount = 0;
  let manualBans = 0;

  recentLogs.forEach(entryStr => {
    try {
      const e = JSON.parse(entryStr);
      const r = (e.reason || '').toLowerCase();
      if (r.includes('exploit') || r.includes('scanner')) exploitScanCount++;
      else if (r.includes('burst')) burstFloodCount++;
      else if (r.includes('sustained') || r.includes('rate limit')) sustainedCount++;
      else if (e.type === 'AUTO_BAN') burstFloodCount++;
      else manualBans++;
    } catch {}
  });

  return {
    timestamp: new Date().toISOString(),
    totalTrackedEndpoints: trackedIps.length,
    activeBlacklistedIps: bannedKeys.length,
    totalRecentIncidents: recentLogs.length,
    incidentBreakdown: {
      exploitScans: exploitScanCount,
      burstFloods: burstFloodCount,
      sustainedRateLimits: sustainedCount,
      manualActions: manualBans
    },
    topCountries: sortedCountries,
    topIsps: sortedIsps,
    topAttackers: topAttackers.slice(0, 8)
  };
}

/**
 * Format Forensic Snapshot into rich, compact Telegram HTML message
 * @param {Object} snap 
 * @returns {string}
 */
function formatForensicsTelegramHtml(snap) {
  let text = `
📸 <b>[ATTACK SNAPSHOT & FORENSIC INTELLIGENCE]</b> 📸
━━━━━━━━━━━━━━━━━━━━
📊 <b>Tracked Ingress Endpoints:</b> <code>${snap.totalTrackedEndpoints}</code>
⛔ <b>Active Blacklisted IPs:</b> <code>${snap.activeBlacklistedIps}</code>
🕒 <b>Telemetry Window:</b> <code>${snap.timestamp.slice(11, 19)} UTC</code>

🛡️ <b>THREAT VECTOR BREAKDOWN:</b>
• ⚡ <b>Burst / HTTP Floods:</b> <code>${snap.incidentBreakdown.burstFloods}</code>
• 🕵️ <b>Exploit & Scanner Probes:</b> <code>${snap.incidentBreakdown.exploitScans}</code>
• 🎯 <b>Sustained Rate Limits:</b> <code>${snap.incidentBreakdown.sustainedRateLimits}</code>

🗺️ <b>TOP ATTACK ORIGIN COUNTRIES:</b>
`;

  if (snap.topCountries.length === 0) {
    text += `• <i>No significant foreign ingress recorded.</i>\n`;
  } else {
    snap.topCountries.forEach(([country, count]) => {
      text += `• ${country}: <b>${count.toLocaleString()}</b> reqs\n`;
    });
  }

  text += `\n📡 <b>TOP ATTACKING ASNs & ISPs:</b>\n`;
  if (snap.topIsps.length === 0) {
    text += `• <i>No ISP telemetry available.</i>\n`;
  } else {
    snap.topIsps.forEach(([isp, count]) => {
      text += `• <code>${isp.slice(0, 24)}</code>: <b>${count.toLocaleString()}</b> reqs\n`;
    });
  }

  text += `\n🎯 <b>TOP IDENTIFIED ATTACKERS:</b>\n`;
  if (snap.topAttackers.length === 0) {
    text += `• <i>All active clients are clean.</i>\n`;
  } else {
    snap.topAttackers.slice(0, 5).forEach((item, idx) => {
      text += `<b>#${idx + 1}</b> <code>${item.ip}</code> ${item.flag || '🌐'} (<b>${item.count.toLocaleString()}</b> reqs) - <i>${item.isp || 'N/A'}</i>\n`;
    });
  }

  text += `━━━━━━━━━━━━━━━━━━━━\n<i>Generated automatically by Cyber C2 Forensics Engine.</i>`;
  return text.trim();
}

module.exports = {
  generateForensicSnapshot,
  formatForensicsTelegramHtml
};
