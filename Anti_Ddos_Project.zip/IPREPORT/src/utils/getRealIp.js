/**
 * Extract real IP address of the Client by priority:
 * 1. cf-connecting-ip (Cloudflare standard)
 * 2. true-client-ip (Cloudflare Enterprise / Akamai)
 * 3. x-forwarded-for (First IP in the list, trimmed)
 * 4. req.ip (Express trust proxy)
 * 5. req.socket.remoteAddress (Fallback)
 * 
 * @param {import('express').Request} req
 * @returns {string} Standardized client IP address
 */
function getRealIp(req) {
  if (!req) return '127.0.0.1';

  let rawIp = '';

  // 1. Standard Cloudflare Header
  const cfConnectingIp = req.headers && req.headers['cf-connecting-ip'];
  if (cfConnectingIp) {
    rawIp = String(cfConnectingIp);
  }
  // 2. True-Client-IP (Cloudflare Enterprise / Premium CDN)
  else if (req.headers && req.headers['true-client-ip']) {
    rawIp = String(req.headers['true-client-ip']);
  }
  // 3. X-Forwarded-For (Get the first IP of the original Client)
  else if (req.headers && req.headers['x-forwarded-for']) {
    rawIp = String(req.headers['x-forwarded-for']);
  }
  // 4. req.ip (Express when trust proxy is enabled)
  else if (req.ip) {
    rawIp = String(req.ip);
  }
  // 5. Fallback socket remote address
  else if (req.socket && req.socket.remoteAddress) {
    rawIp = String(req.socket.remoteAddress);
  }

  // Extract the first IP if there is a comma-separated list
  if (rawIp.includes(',')) {
    rawIp = rawIp.split(',')[0];
  }

  rawIp = rawIp.trim();

  // Standardize IPv6-mapped IPv4 (::ffff:1.2.3.4 -> 1.2.3.4)
  if (rawIp.startsWith('::ffff:')) {
    rawIp = rawIp.replace('::ffff:', '');
  }

  // Standardize localhost IPv6
  if (rawIp === '::1') {
    rawIp = '127.0.0.1';
  }

  return rawIp || '127.0.0.1';
}

module.exports = getRealIp;
