const redis = require('../redisClient');

/**
 * Generate country flag emoji from 2-character code (ISO 3166-1 alpha-2)
 * @param {string} countryCode Example: 'VN', 'US', 'RU', 'CN'
 * @returns {string}
 */
function getFlagEmoji(countryCode) {
  if (!countryCode || countryCode.length !== 2) return '🌐';
  const codePoints = countryCode
    .toUpperCase()
    .split('')
    .map(char => 127397 + char.charCodeAt(0));
  try {
    return String.fromCodePoint(...codePoints);
  } catch {
    return '🌐';
  }
}

/**
 * Lookup Geolocation & ISP info for IP with 7-day Redis Cache
 * @param {string} ip 
 * @returns {Promise<Object>}
 */
async function lookupIpGeo(ip) {
  if (!ip || ip === '127.0.0.1' || ip === '::1' || ip.startsWith('192.168.') || ip.startsWith('10.')) {
    return {
      status: 'success',
      country: 'Local Network / Host',
      countryCode: 'VN',
      flag: '🏠',
      city: 'Localhost',
      regionName: 'Internal',
      isp: 'Loopback / Private LAN',
      org: 'Local System',
      as: 'N/A',
      query: ip
    };
  }

  // 1. Check Redis cache
  const cacheKey = `geo_cache:${ip}`;
  try {
    const cached = await redis.get(cacheKey);
    if (cached) {
      return JSON.parse(cached);
    }
  } catch (err) {
    console.warn('[GEO LOOKUP] Error reading Redis cache:', err.message);
  }

  // 2. Call ip-api.com API
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);

    const res = await fetch(`http://ip-api.com/json/${ip}?fields=status,message,country,countryCode,regionName,city,zip,lat,lon,timezone,isp,org,as,query`, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    if (data.status === 'success') {
      data.flag = getFlagEmoji(data.countryCode);
      // Save cache for 7 days (604800s)
      await redis.set(cacheKey, JSON.stringify(data), 'EX', 604800).catch(() => {});
      return data;
    }
  } catch (err) {
    console.warn(`[GEO LOOKUP] Cannot get geo for ${ip}:`, err.message);
  }

  return {
    status: 'fail',
    country: 'Unknown',
    countryCode: 'XX',
    flag: '🌐',
    city: 'Unknown',
    regionName: 'Unknown',
    isp: 'Unknown',
    org: 'Unknown',
    as: 'N/A',
    query: ip
  };
}

module.exports = {
  lookupIpGeo,
  getFlagEmoji
};
