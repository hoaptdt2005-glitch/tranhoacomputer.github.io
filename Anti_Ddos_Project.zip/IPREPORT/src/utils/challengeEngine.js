const crypto = require('crypto');
const config = require('../configLoader');

// Secret key for signing clearance cookies (derived from ADMIN_API_KEY or random fallback)
const CHALLENGE_SECRET = config.ADMIN_API_KEY || crypto.randomBytes(32).toString('hex');
const COOKIE_NAME = '__c2_clearance';
const CLEARANCE_TTL_SEC = 86400; // Cookie valid for 24 hours

/**
 * Generate a Proof-of-Work challenge for an IP address
 * @param {string} ip 
 * @returns {Object} { nonce, difficulty, targetPrefix, timestamp, signature }
 */
function createPoWChallenge(ip) {
  const timestamp = Math.floor(Date.now() / 1000);
  const nonce = crypto.randomBytes(16).toString('hex');
  const difficulty = 3; // Number of leading zero hex chars required (takes ~30-80ms in browser JS)
  const targetPrefix = '0'.repeat(difficulty);

  const payload = `${ip}:${nonce}:${timestamp}:${difficulty}`;
  const signature = crypto.createHmac('sha256', CHALLENGE_SECRET).update(payload).digest('hex');

  return {
    nonce,
    difficulty,
    targetPrefix,
    timestamp,
    signature
  };
}

/**
 * Verify Proof-of-Work answer from client
 * @param {string} ip 
 * @param {string} nonce 
 * @param {number} timestamp 
 * @param {number} difficulty 
 * @param {string} solution 
 * @param {string} signature 
 * @returns {boolean}
 */
function verifyPoWSolution(ip, nonce, timestamp, difficulty, solution, signature) {
  const nowSec = Math.floor(Date.now() / 1000);
  // Timestamp must be within last 5 minutes (300 seconds)
  if (nowSec - timestamp > 300 || timestamp > nowSec + 10) {
    return false;
  }

  // Verify HMAC signature of the challenge parameters
  const payload = `${ip}:${nonce}:${timestamp}:${difficulty}`;
  const expectedSig = crypto.createHmac('sha256', CHALLENGE_SECRET).update(payload).digest('hex');
  if (expectedSig !== signature) {
    return false;
  }

  // Verify that sha256(nonce + solution) starts with targetPrefix
  const targetPrefix = '0'.repeat(difficulty);
  const hash = crypto.createHash('sha256').update(`${nonce}:${solution}`).digest('hex');
  return hash.startsWith(targetPrefix);
}

/**
 * Generate a cryptographically signed clearance token for an IP
 * @param {string} ip 
 * @returns {string}
 */
function generateClearanceCookie(ip) {
  const expiry = Math.floor(Date.now() / 1000) + CLEARANCE_TTL_SEC;
  const data = `${ip}:${expiry}`;
  const hmac = crypto.createHmac('sha256', CHALLENGE_SECRET).update(data).digest('hex');
  return `${expiry}.${hmac}`;
}

/**
 * Verify a clearance cookie from an incoming HTTP request
 * @param {string} ip 
 * @param {string} cookieHeader 
 * @returns {boolean}
 */
function verifyClearanceCookie(ip, cookieHeader) {
  if (!cookieHeader || typeof cookieHeader !== 'string') return false;

  const cookies = cookieHeader.split(';').map(c => c.trim());
  let targetCookie = null;

  for (const c of cookies) {
    if (c.startsWith(`${COOKIE_NAME}=`)) {
      targetCookie = c.slice(COOKIE_NAME.length + 1).trim();
      break;
    }
  }

  if (!targetCookie) return false;

  const parts = targetCookie.split('.');
  if (parts.length !== 2) return false;

  const expiry = parseInt(parts[0], 10);
  const hmac = parts[1];

  const nowSec = Math.floor(Date.now() / 1000);
  if (isNaN(expiry) || expiry < nowSec) {
    return false; // Expired
  }

  const expectedData = `${ip}:${expiry}`;
  const expectedHmac = crypto.createHmac('sha256', CHALLENGE_SECRET).update(expectedData).digest('hex');

  return crypto.timingSafeEqual(Buffer.from(hmac, 'utf8'), Buffer.from(expectedHmac, 'utf8'));
}

/**
 * Render Ultra-Fast 0.1s HTML JavaScript Challenge Page
 * @param {string} ip 
 * @param {string} returnUrl 
 * @returns {string} HTML content
 */
function renderChallengePage(ip, returnUrl = '/') {
  const challenge = createPoWChallenge(ip);

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Security Verification | Cyber C2 Shield</title>
  <style>
    :root { --bg: #090d16; --card: #111827; --primary: #38bdf8; --text: #f1f5f9; --text-muted: #94a3b8; }
    body { background-color: var(--bg); color: var(--text); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 1rem; }
    .card { background-color: var(--card); border: 1px solid #1e293b; border-radius: 12px; padding: 2.5rem; max-width: 440px; width: 100%; text-align: center; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); }
    .spinner { width: 44px; height: 44px; border: 3px solid rgba(56, 189, 248, 0.2); border-top-color: var(--primary); border-radius: 50%; animation: spin 0.8s linear infinite; margin: 0 auto 1.5rem; }
    @keyframes spin { to { transform: rotate(360deg); } }
    h1 { font-size: 1.25rem; font-weight: 700; margin: 0 0 0.5rem; letter-spacing: -0.025em; }
    p { font-size: 0.85rem; color: var(--text-muted); line-height: 1.5; margin: 0 0 1.5rem; }
    .badge { display: inline-block; padding: 0.25rem 0.75rem; background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.2); color: var(--primary); border-radius: 9999px; font-size: 0.75rem; font-family: monospace; font-weight: 600; }
  </style>
</head>
<body>
  <div class="card">
    <div class="spinner" id="spinner"></div>
    <h1>Checking your browser before accessing...</h1>
    <p>This automated security check verifies legitimate browser connections to prevent DDoS attacks.</p>
    <div class="badge" id="status">Verifying Proof of Work...</div>
  </div>

  <script>
    (async function() {
      const ip = "${ip}";
      const nonce = "${challenge.nonce}";
      const timestamp = ${challenge.timestamp};
      const difficulty = ${challenge.difficulty};
      const targetPrefix = "${challenge.targetPrefix}";
      const signature = "${challenge.signature}";
      const returnUrl = "${encodeURIComponent(returnUrl)}";

      async function sha256(str) {
        const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
        return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
      }

      let solution = 0;
      const startTime = performance.now();

      while (true) {
        solution++;
        const hash = await sha256(nonce + ":" + solution);
        if (hash.startsWith(targetPrefix)) {
          break;
        }
        if (solution > 2000000) break;
      }

      document.getElementById('status').innerText = "Security verified! Redirecting...";

      try {
        const res = await fetch("/api/challenge-verify", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ nonce, timestamp, difficulty, solution, signature })
        });
        const data = await res.json();
        if (data.success) {
          window.location.href = decodeURIComponent(returnUrl) || "/";
        } else {
          document.getElementById('status').innerText = "Verification failed. Please refresh.";
        }
      } catch (e) {
        document.getElementById('status').innerText = "Connection error. Retrying...";
        setTimeout(() => window.location.reload(), 1500);
      }
    })();
  </script>
</body>
</html>`;
}

module.exports = {
  COOKIE_NAME,
  createPoWChallenge,
  verifyPoWSolution,
  generateClearanceCookie,
  verifyClearanceCookie,
  renderChallengePage
};
