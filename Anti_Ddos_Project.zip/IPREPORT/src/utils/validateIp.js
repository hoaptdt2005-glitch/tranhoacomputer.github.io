const net = require('net');

/**
 * Regex to check valid IPv4 and IPv6 formats
 */
const IPV4_REGEX = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
const IPV6_REGEX = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;

/**
 * Clean and standardize IP address string (remove protocol, port, whitespace, IPv6-mapped)
 * @param {string} ip
 * @returns {string}
 */
function cleanIpString(ip) {
  if (!ip || typeof ip !== 'string') return '';
  let clean = ip.trim()
    .replace(/^https?:\/\//i, '')
    .replace(/^::ffff:/, '')
    .replace(/[/?#].*$/, '')
    .trim();

  // Remove port if IPv4 (1.2.3.4:8080 -> 1.2.3.4)
  if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+$/.test(clean)) {
    clean = clean.split(':')[0];
  }
  // Remove port if IPv6 with brackets ([2001:db8::1]:8080 -> 2001:db8::1)
  if (/^\[([0-9a-fA-F:]+)\]:\d+$/.test(clean)) {
    const match = clean.match(/^\[([0-9a-fA-F:]+)\]:\d+$/);
    if (match) clean = match[1];
  }

  return clean;
}

/**
 * Check if the input string is a valid IPv4 or IPv6 address
 * @param {string} ip - The IP address string to check
 * @returns {boolean}
 */
function isValidIp(ip) {
  if (!ip || typeof ip !== 'string') return false;

  const cleanIp = cleanIpString(ip);

  // 1. Check length
  if (cleanIp.length < 3 || cleanIp.length > 45) return false;

  // 2. Block dangerous characters: semicolons, whitespaces, HTML tags, quotes, path traversal, SQL keywords
  const dangerousPatterns = /[;'"<>\s\0\\]|\.\.|\b(DROP|SELECT|INSERT|UNION|DELETE|EXEC)\b/i;
  if (dangerousPatterns.test(cleanIp)) return false;

  // 3. Check using net.isIP (4 = IPv4, 6 = IPv6)
  return net.isIP(cleanIp) !== 0;
}

/**
 * Remove dangerous control characters from the input string
 * @param {string} input 
 * @returns {string}
 */
function sanitizeInputString(input) {
  if (typeof input !== 'string') return '';
  return input
    .replace(/[\0\r\n\t]/g, '')
    .replace(/[<>]/g, '')
    .trim();
}

/**
 * Express middleware to validate IP parameter in URL (/api/unban/:ip, /api/ip-stats/:ip)
 * @param {string} paramName - URL parameter name (default is 'ip')
 */
function validateIpMiddleware(paramName = 'ip') {
  return (req, res, next) => {
    const rawIp = req.params[paramName] || req.query[paramName] || (req.body && req.body[paramName]);

    if (!rawIp) {
      return res.status(400).json({
        success: false,
        message: 'Missing IP address parameter'
      });
    }

    const cleanIp = cleanIpString(String(rawIp));
    if (!isValidIp(cleanIp)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid IP address format'
      });
    }

    req.params[paramName] = cleanIp;
    if (req.query) req.query[paramName] = cleanIp;
    next();
  };
}

module.exports = {
  cleanIpString,
  isValidIp,
  sanitizeInputString,
  validateIpMiddleware
};
