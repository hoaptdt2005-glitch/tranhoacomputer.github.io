const redis = require('../redisClient');
const { isValidIp, cleanIpString } = require('./validateIp');
const { isOwnerIp } = require('./serverPublicIp');

// In-Memory Set of Banned /24 Subnet Prefixes (e.g. "1.2.3")
const bannedSubnets = new Set();

/**
 * Extract /24 prefix from IPv4 address (e.g. "1.2.3.4" -> "1.2.3")
 * @param {string} ip 
 * @returns {string|null}
 */
function getSubnet24Prefix(ip) {
  const clean = cleanIpString(ip);
  const parts = clean.split('.');
  if (parts.length === 4) {
    return `${parts[0]}.${parts[1]}.${parts[2]}`;
  }
  return null;
}

/**
 * Format CIDR string from IP or /24 string
 * @param {string} input 
 * @returns {string|null} e.g. "1.2.3.0/24"
 */
function normalizeSubnet24Cidr(input) {
  const clean = (input || '').trim().replace(/\/24$/, '');
  const prefix = getSubnet24Prefix(clean);
  if (prefix) {
    return `${prefix}.0/24`;
  }
  return null;
}

/**
 * Check if an IP address belongs to any banned /24 subnets (0ms RAM lookup)
 * @param {string} ip 
 * @returns {boolean}
 */
function isSubnetBanned(ip) {
  if (bannedSubnets.size === 0) return false;
  if (isOwnerIp(ip)) return false;

  const prefix = getSubnet24Prefix(ip);
  if (!prefix) return false;
  return bannedSubnets.has(prefix);
}

/**
 * Load banned subnets from Redis into RAM
 */
async function loadBannedSubnets() {
  try {
    const list = await redis.smembers('system:banned_subnets');
    if (Array.isArray(list)) {
      bannedSubnets.clear();
      list.forEach(cidr => {
        const prefix = getSubnet24Prefix(cidr.split('/')[0]);
        if (prefix) bannedSubnets.add(prefix);
      });
      if (bannedSubnets.size > 0) {
        console.log(`[SUBNET DEFENSE] 🛡️ Loaded ${bannedSubnets.size} banned /24 subnet(s) from Redis.`);
      }
    }
  } catch (err) {
    console.warn('[SUBNET DEFENSE] ⚠️ Failed to load banned subnets from Redis:', err.message);
  }
}

/**
 * Ban a /24 subnet across cluster
 * @param {string} ipOrCidr 
 * @param {number} durationSec 
 * @returns {Promise<{success: boolean, cidr: string}>}
 */
async function banSubnet24(ipOrCidr, durationSec = 86400) {
  const cidr = normalizeSubnet24Cidr(ipOrCidr);
  if (!cidr) {
    throw new Error('Invalid IPv4 address or /24 subnet format');
  }

  const prefix = getSubnet24Prefix(cidr.split('/')[0]);
  bannedSubnets.add(prefix);

  await redis.sadd('system:banned_subnets', cidr);
  await redis.publish('anti_ddos_sync', `BAN_SUBNET:${cidr}`).catch(() => {});

  console.warn(`[SUBNET BAN] 🚫 Subnet ${cidr} (254 IPs) banned for ${durationSec}s.`);
  return { success: true, cidr };
}

/**
 * Unban a /24 subnet across cluster
 * @param {string} ipOrCidr 
 * @returns {Promise<{success: boolean, cidr: string}>}
 */
async function unbanSubnet24(ipOrCidr) {
  const cidr = normalizeSubnet24Cidr(ipOrCidr);
  if (!cidr) {
    throw new Error('Invalid IPv4 address or /24 subnet format');
  }

  const prefix = getSubnet24Prefix(cidr.split('/')[0]);
  bannedSubnets.delete(prefix);

  await redis.srem('system:banned_subnets', cidr);
  await redis.publish('anti_ddos_sync', `UNBAN_SUBNET:${cidr}`).catch(() => {});

  console.log(`[SUBNET UNBAN] 🔓 Subnet ${cidr} unbanned.`);
  return { success: true, cidr };
}

/**
 * Get all active banned subnets
 * @returns {Promise<string[]>}
 */
async function getAllBannedSubnets() {
  const list = await redis.smembers('system:banned_subnets');
  return list || [];
}

module.exports = {
  getSubnet24Prefix,
  normalizeSubnet24Cidr,
  isSubnetBanned,
  loadBannedSubnets,
  banSubnet24,
  unbanSubnet24,
  getAllBannedSubnets
};
