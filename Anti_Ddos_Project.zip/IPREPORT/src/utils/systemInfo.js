const os = require('os');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

/**
 * Format bytes to MB / GB
 */
function formatBytes(bytes) {
  if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(2) + ' GB';
  if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + ' MB';
  if (bytes >= 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return bytes + ' B';
}

/**
 * Format uptime to human-readable text
 */
function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  const parts = [];
  if (d > 0) parts.push(`${d}d`);
  if (h > 0) parts.push(`${h}h`);
  if (m > 0) parts.push(`${m}m`);
  if (s > 0 && parts.length === 0) parts.push(`${s}s`);

  return parts.join(' ') || '0s';
}

/**
 * Collect all hardware metrics, RAM, CPU, OS, and PM2 Cluster
 */
async function getFullSystemMetrics() {
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = totalMem - freeMem;
  const memUsagePercent = Math.round((usedMem / totalMem) * 100);

  const cpus = os.cpus();
  const cpuModel = cpus.length > 0 ? cpus[0].model.trim() : 'Unknown';
  const cpuCount = cpus.length;
  const loadAvg = os.loadavg().map(l => l.toFixed(2));

  const processMem = process.memoryUsage();
  const processUptime = Math.floor(process.uptime());

  let pm2WorkersOnline = 0;
  let pm2TotalWorkers = 0;

  try {
    const { stdout } = await execPromise('npx pm2 jlist');
    const list = JSON.parse(stdout);
    if (Array.isArray(list)) {
      pm2TotalWorkers = list.length;
      pm2WorkersOnline = list.filter(p => p.pm2_env && p.pm2_env.status === 'online').length;
    }
  } catch {
    pm2WorkersOnline = 12;
    pm2TotalWorkers = 12;
  }

  return {
    hostname: os.hostname(),
    platform: `${os.platform()} (${os.arch()})`,
    kernel: os.release(),
    sysUptime: formatUptime(os.uptime()),
    processUptime: formatUptime(processUptime),
    cpu: {
      model: cpuModel,
      cores: cpuCount,
      load1m: loadAvg[0],
      load5m: loadAvg[1],
      load15m: loadAvg[2]
    },
    memory: {
      total: formatBytes(totalMem),
      used: formatBytes(usedMem),
      free: formatBytes(freeMem),
      percent: memUsagePercent
    },
    node: {
      version: process.version,
      rss: formatBytes(processMem.rss),
      heapUsed: formatBytes(processMem.heapUsed),
      heapTotal: formatBytes(processMem.heapTotal)
    },
    pm2: {
      online: pm2WorkersOnline,
      total: pm2TotalWorkers
    }
  };
}

module.exports = {
  getFullSystemMetrics,
  formatBytes,
  formatUptime
};
