const express = require('express');
const path = require('path');
const fs = require('fs');
const http = require('http');
const https = require('https');

const config = require('./configLoader');
const redis = require('./redisClient');
const getRealIp = require('./utils/getRealIp');
const { isIgnoredIp, getCachedPublicIp } = require('./utils/serverPublicIp');
const { validateIpMiddleware } = require('./utils/validateIp');

// Middlewares
const { helmetMiddleware, corsMiddleware, jsonParser, urlencodedParser, securityHeaders } = require('./middleware/securityHeaders');
const blockSensitiveFiles = require('./middleware/blockSensitiveFiles');
const ipTracker = require('./middleware/ipTracker');
const { getMinuteKey } = require('./middleware/ipTracker');
const rateLimiterAndBlacklist = require('./middleware/rateLimiterAndBlacklist');
const { unbanLocalIp } = require('./middleware/rateLimiterAndBlacklist');
const adminAuth = require('./middleware/adminAuth');
const globalErrorHandler = require('./middleware/globalErrorHandler');

// Services
const excelService = require('./services/excelService');
const telegramService = require('./services/telegramService');

const app = express();

// ================= 1. PROXY & FIRST LINE OF DEFENSE (ANTI-DDOS AUTO-BAN) =================
app.set('trust proxy', true);
app.disable('x-powered-by');

// TIER 1: Rate Limiter & Blacklist runs FIRST (0ms drop botnet without consuming CPU/RAM/Redis)
app.use(rateLimiterAndBlacklist);

// TIER 2: Block requests scanning sensitive files (.env, .git, config.txt, certs, data)
app.use(blockSensitiveFiles);

// TIER 3: Apply Security Headers with Helmet, CORS & Security Headers
app.use(helmetMiddleware);
app.use(corsMiddleware);
app.use(securityHeaders);

// TIER 4: Limit JSON & URL-encoded Payload to 10kb max to prevent RAM overflow
app.use(jsonParser);
app.use(urlencodedParser);

// ================= 2. REQUEST LOGGER (PM2 / CONSOLE AUDIT LOG) =================
app.use((req, res, next) => {
  const start = Date.now();
  const clientIp = getRealIp(req);

  res.on('finish', () => {
    const duration = Date.now() - start;
    const status = res.statusCode;
    const symbol = status >= 500 ? '🔴' : status >= 400 ? '🟡' : '🟢';
    console.log(`[INGRESS] ${symbol} ${req.method} ${req.originalUrl} | IP: ${clientIp} | Status: ${status} | ${duration}ms`);
  });

  next();
});

// ================= 3. IP TRACKER PIPELINE (ONLY TRACK VALID TRAFFIC) =================
app.use(ipTracker);

// ================= 4. ADMIN ROUTES (REQUIRES ADMIN AUTH) =================

/**
 * API: Unban IP (Strict IP Validation + In-Memory Clear)
 * POST /api/unban/:ip
 */
app.post('/api/unban/:ip', adminAuth, validateIpMiddleware('ip'), async (req, res, next) => {
  const cleanIp = req.params.ip;
  const blacklistKey = `blacklist:${cleanIp}`;
  const rateLimitKey = `rate_limit:${cleanIp}`;
  const burstKey = `burst:${cleanIp}`;

  try {
    const deletedCount = await redis.del(blacklistKey, rateLimitKey, burstKey);
    unbanLocalIp(cleanIp);
    console.log(`[ADMIN UNBAN] ✅ Unbanned IP ${cleanIp} (Deleted ${deletedCount} keys in Redis + In-memory cache).`);

    return res.json({
      success: true,
      message: `Successfully unbanned IP ${cleanIp}`,
      ip: cleanIp
    });
  } catch (error) {
    next(error);
  }
});

/**
 * API: Export and Download Excel Report
 * GET /api/export-excel
 */
app.get('/api/export-excel', adminAuth, async (req, res, next) => {
  try {
    const filePath = await excelService.exportIpReportToExcel();

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ success: false, message: 'Report file not found' });
    }

    const filename = `ip_report_${new Date().toISOString().slice(0, 10)}.xlsx`;
    return res.download(filePath, filename, (err) => {
      if (err && !res.headersSent) {
        next(err);
      }
    });
  } catch (error) {
    next(error);
  }
});

/**
 * API: Clear Top Ingress Client Records
 * POST /api/clear-tracker
 */
app.post('/api/clear-tracker', adminAuth, async (req, res, next) => {
  try {
    const trackedIps = await redis.smembers('tracked_ips_set');
    const pipeline = redis.pipeline();

    if (trackedIps.length > 0) {
      trackedIps.forEach(ip => {
        pipeline.del(`ip_tracker:${ip}`);
      });
    }

    pipeline.del('tracked_ips_set');

    const trackerKeys = await redis.keys('ip_tracker:*');
    if (trackerKeys.length > 0) {
      trackerKeys.forEach(k => pipeline.del(k));
    }

    await pipeline.exec();
    console.log(`[ADMIN ACTION] 🗑️ Purged ${trackedIps.length} client telemetry records.`);

    return res.json({
      success: true,
      message: `Successfully purged ${trackedIps.length} client telemetry records`,
      clearedCount: trackedIps.length
    });
  } catch (error) {
    next(error);
  }
});

/**
 * API: Toggle Emergency Lockdown Mode (Block 100% Ingress)
 * POST /api/lockdown
 */
app.post('/api/lockdown', adminAuth, async (req, res, next) => {
  const { action, durationSec } = req.body || {};
  const shouldEnable = action !== 'off' && action !== 'disable';

  try {
    if (shouldEnable) {
      const dur = parseInt(durationSec, 10) || 0;
      if (dur > 0) {
        await redis.set('system:lockdown_mode', '1', 'EX', dur);
      } else {
        await redis.set('system:lockdown_mode', '1');
      }
      await redis.publish('anti_ddos_sync', 'LOCKDOWN:ON').catch(() => {});
      console.warn(`[ADMIN ACTION] 🚨 EMERGENCY LOCKDOWN ACTIVATED (${dur > 0 ? dur + 's' : 'Indefinite'}).`);
      return res.json({ success: true, lockdown: true, durationSec: dur, message: 'Emergency Lockdown activated (100% public traffic blocked)' });
    } else {
      await redis.del('system:lockdown_mode');
      await redis.publish('anti_ddos_sync', 'LOCKDOWN:OFF').catch(() => {});
      console.log('[ADMIN ACTION] 🟢 EMERGENCY LOCKDOWN LIFTED.');
      return res.json({ success: true, lockdown: false, message: 'Emergency Lockdown lifted. Normal traffic restored.' });
    }
  } catch (error) {
    next(error);
  }
});

/**
 * API: Mass Ban All Foreign Client Endpoints
 * POST /api/ban-all
 */
app.post('/api/ban-all', adminAuth, async (req, res, next) => {
  try {
    const { durationSec, reason } = req.body || {};
    const banDuration = parseInt(durationSec, 10) || Number(config.BAN_DURATION_SEC) || 1800;
    const banReason = reason || 'Mass ban by Admin Web Dashboard';

    const trackedIps = await redis.smembers('tracked_ips_set');
    const { isOwnerIp } = require('./utils/serverPublicIp');
    const targetIps = trackedIps.filter(ip => !isOwnerIp(ip));

    if (targetIps.length === 0) {
      return res.json({ success: true, bannedCount: 0, message: 'No foreign client IPs to ban (Owner IPs protected).' });
    }

    const pipeline = redis.pipeline();
    targetIps.forEach(ip => {
      pipeline.set(`blacklist:${ip}`, banReason, 'EX', banDuration);
    });
    await pipeline.exec();

    await redis.publish('anti_ddos_sync', 'BAN:*').catch(() => {});
    console.warn(`[ADMIN ACTION] 🚫 Executed MASS BAN on ${targetIps.length} IPs for ${banDuration}s.`);

    return res.json({
      success: true,
      bannedCount: targetIps.length,
      durationSec: banDuration,
      message: `Successfully mass-banned ${targetIps.length} client IPs for ${banDuration}s`
    });
  } catch (error) {
    next(error);
  }
});

/**
 * API: Unban All Blacklisted Targets
 * POST /api/unban-all
 */
app.post('/api/unban-all', adminAuth, async (req, res, next) => {
  try {
    const bannedKeys = await redis.keys('blacklist:*');
    if (bannedKeys.length === 0) {
      return res.json({ success: true, unbannedCount: 0, message: 'Blacklist is currently empty.' });
    }

    const pipeline = redis.pipeline();
    bannedKeys.forEach(k => pipeline.del(k));
    await pipeline.exec();

    await redis.publish('anti_ddos_sync', 'UNBAN:*').catch(() => {});
    console.log(`[ADMIN ACTION] 🔓 Cleared blacklist for all ${bannedKeys.length} IPs.`);

    return res.json({
      success: true,
      unbannedCount: bannedKeys.length,
      message: `Successfully unbanned all ${bannedKeys.length} blacklisted IPs`
    });
  } catch (error) {
    next(error);
  }
});

/**
 * API: Verify Proof-of-Work Challenge Answer & Issue Clearance Cookie
 * POST /api/challenge-verify
 */
app.post('/api/challenge-verify', async (req, res, next) => {
  try {
    const { nonce, timestamp, difficulty, solution, signature } = req.body || {};
    const ip = getRealIp(req);

    const { verifyPoWSolution, generateClearanceCookie, COOKIE_NAME } = require('./utils/challengeEngine');
    const isValid = verifyPoWSolution(ip, nonce, timestamp, difficulty, solution, signature);

    if (isValid) {
      const clearanceCookie = generateClearanceCookie(ip);
      res.setHeader('Set-Cookie', `${COOKIE_NAME}=${clearanceCookie}; Path=/; Max-Age=86400; HttpOnly; SameSite=Lax`);
      return res.json({ success: true, message: 'Challenge passed. Clearance granted.' });
    } else {
      return res.status(403).json({ success: false, message: 'Proof of work verification failed.' });
    }
  } catch (error) {
    next(error);
  }
});

// ================= 6. PUBLIC API ENDPOINTS & TELEMETRY =================

/**
 * API: Health Check
 * GET /api/health
 */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    system: 'CYBER_C2_DEFENDER',
    yourIp: getRealIp(req),
    serverPublicIp: getCachedPublicIp() || 'Detecting...',
    timestamp: new Date().toISOString()
  });
});

/**
 * API: Time-Series Requests / Second (RPS) Data for Chart.js
 * GET /api/chart-data?window=30s | 60s | 5m | 15m | 30m | 60m
 */
app.get('/api/chart-data', async (req, res, next) => {
  try {
    const rawWindow = String(req.query.window || req.query.seconds || req.query.minutes || '30s').toLowerCase().trim();
    const now = Date.now();
    const currentSec = Math.floor(now / 1000);
    const pad = (n) => String(n).padStart(2, '0');

    let isPerSecond = false;
    let count = 30;

    if (rawWindow.endsWith('s')) {
      isPerSecond = true;
      count = Math.min(Math.max(parseInt(rawWindow, 10) || 30, 10), 300); // 10s -> 300s
    } else if (rawWindow.endsWith('m')) {
      const mins = Math.min(Math.max(parseInt(rawWindow, 10) || 30, 1), 120);
      if (mins <= 5) {
        isPerSecond = true;
        count = mins * 60;
      } else {
        isPerSecond = false;
        count = mins;
      }
    } else {
      const num = parseInt(rawWindow, 10) || 30;
      if (num <= 5) {
        isPerSecond = true;
        count = num * 60;
      } else if (num <= 300 && (req.query.seconds || num <= 60)) {
        isPerSecond = true;
        count = num;
      } else {
        isPerSecond = false;
        count = Math.min(Math.max(num, 5), 120);
      }
    }

    const cleanKeys = [];
    const ddosKeys = [];
    const labels = [];

    if (isPerSecond) {
      for (let i = count - 1; i >= 0; i--) {
        const sec = currentSec - i;
        const d = new Date(sec * 1000);
        cleanKeys.push(`traffic_sec:${sec}`);
        ddosKeys.push(`ddos_sec:${sec}`);
        labels.push(`${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`);
      }

      const pipeline = redis.pipeline();
      cleanKeys.forEach(k => pipeline.get(k));
      ddosKeys.forEach(k => pipeline.get(k));
      const results = await pipeline.exec();

      const cleanValues = [];
      const ddosValues = [];
      for (let i = 0; i < count; i++) {
        const val = results[i] && results[i][1] ? parseInt(results[i][1], 10) : 0;
        cleanValues.push(val);
      }
      for (let i = count; i < count * 2; i++) {
        const val = results[i] && results[i][1] ? parseInt(results[i][1], 10) : 0;
        ddosValues.push(val);
      }

      const totalCleanInWindow = cleanValues.reduce((sum, v) => sum + v, 0);
      const totalDdosInWindow = ddosValues.reduce((sum, v) => sum + v, 0);
      const currentCleanRps = cleanValues.length > 0 ? cleanValues[cleanValues.length - 1] : 0;
      const currentDdosRps = ddosValues.length > 0 ? ddosValues[ddosValues.length - 1] : 0;
      const peakCleanRps = cleanValues.length > 0 ? Math.max(...cleanValues) : 0;
      const peakDdosRps = ddosValues.length > 0 ? Math.max(...ddosValues) : 0;
      const avgCleanRps = cleanValues.length > 0 ? Math.round((totalCleanInWindow / cleanValues.length) * 10) / 10 : 0;
      const avgDdosRps = ddosValues.length > 0 ? Math.round((totalDdosInWindow / ddosValues.length) * 10) / 10 : 0;

      const totalValues = cleanValues.map((cv, idx) => cv + ddosValues[idx]);

      return res.json({
        success: true,
        unit: 'req/s',
        resolution: '1s',
        window: rawWindow,
        labels,
        values: totalValues,
        cleanValues,
        ddosValues,
        summary: {
          currentRps: currentCleanRps,
          currentDdosRps,
          peakRps: peakCleanRps,
          peakDdosRps,
          avgRps: avgCleanRps,
          avgDdosRps,
          totalCleanInWindow,
          totalDdosInWindow,
          totalRequestsInWindow: totalCleanInWindow + totalDdosInWindow
        }
      });
    } else {
      for (let i = count - 1; i >= 0; i--) {
        const time = now - i * 60 * 1000;
        const d = new Date(time);
        const minuteKey = getMinuteKey(time);
        cleanKeys.push(`traffic_stats:${minuteKey}`);
        labels.push(`${pad(d.getHours())}:${pad(d.getMinutes())}`);
      }

      const rawValues = cleanKeys.length > 0 ? await redis.mget(cleanKeys) : [];
      const cleanValues = rawValues.map(v => (v ? Math.round((parseInt(v, 10) / 60) * 10) / 10 : 0));
      const rawCounts = rawValues.map(v => (v ? parseInt(v, 10) : 0));
      const ddosValues = new Array(cleanValues.length).fill(0);

      const totalRequestsInWindow = rawCounts.reduce((sum, v) => sum + v, 0);
      const currentRps = cleanValues.length > 0 ? cleanValues[cleanValues.length - 1] : 0;
      const peakRps = cleanValues.length > 0 ? Math.max(...cleanValues) : 0;
      const avgRps = count > 0 ? Math.round((totalRequestsInWindow / (count * 60)) * 10) / 10 : 0;

      return res.json({
        success: true,
        unit: 'req/s',
        resolution: '1m',
        window: rawWindow,
        labels,
        values: cleanValues,
        cleanValues,
        ddosValues,
        summary: {
          currentRps,
          currentDdosRps: 0,
          peakRps,
          peakDdosRps: 0,
          avgRps,
          avgDdosRps: 0,
          totalRequestsInWindow
        }
      });
    }
  } catch (error) {
    next(error);
  }
});

/**
 * API: Aggregated stats for Dashboard Metrics
 * GET /api/stats
 */
app.get('/api/stats', async (req, res, next) => {
  try {
    const ipSet = new Set();
    try {
      const trackedIps = await redis.smembers('tracked_ips_set');
      trackedIps.forEach(ip => {
        if (!isIgnoredIp(ip)) ipSet.add(ip);
      });
    } catch (e) {}

    try {
      const trackerKeys = await redis.keys('ip_tracker:*');
      trackerKeys.forEach(k => {
        const ip = k.replace('ip_tracker:', '');
        if (ip && !isIgnoredIp(ip)) ipSet.add(ip);
      });
    } catch (e) {}

    const allBlacklistKeys = (await redis.keys('blacklist:*')) || [];
    allBlacklistKeys.forEach(k => {
      const ip = k.replace('blacklist:', '');
      if (ip && !isIgnoredIp(ip)) ipSet.add(ip);
    });

    const ipList = Array.from(ipSet).filter(ip => !isIgnoredIp(ip));
    const now = Date.now();
    let totalCleanRequests = 0;
    let activeIpsCount = 0;
    const topIPs = [];

    if (ipList.length > 0) {
      const pipeline = redis.pipeline();
      ipList.forEach(ip => {
        pipeline.hgetall(`ip_tracker:${ip}`);
        pipeline.ttl(`blacklist:${ip}`);
      });

      const results = await pipeline.exec();

      for (let i = 0; i < ipList.length; i++) {
        const ip = ipList[i];
        const trackerRes = results[i * 2];
        const banTtlRes = results[i * 2 + 1];

        const trackerData = (trackerRes && !trackerRes[0]) ? (trackerRes[1] || {}) : {};
        const banTtl = (banTtlRes && !banTtlRes[0]) ? Number(banTtlRes[1]) : -2;

        const count = parseInt(trackerData.count || 0, 10);
        const firstSeen = trackerData.first_seen ? Number(trackerData.first_seen) : null;
        const lastSeen = trackerData.last_seen ? Number(trackerData.last_seen) : null;

        totalCleanRequests += count;

        const isBanned = banTtl > -2;
        const isActive = lastSeen && (now - lastSeen < 5 * 60 * 1000);
        if (isActive) activeIpsCount++;

        topIPs.push({
          ip,
          count,
          firstSeen: firstSeen ? new Date(firstSeen).toISOString() : 'N/A',
          lastSeen: lastSeen ? new Date(lastSeen).toISOString() : 'N/A',
          firstSeenRaw: firstSeen,
          lastSeenRaw: lastSeen,
          isBlacklisted: isBanned,
          banTimeRemainingSec: isBanned ? (banTtl > 0 ? banTtl : 'Permanent') : 0,
          status: isBanned ? 'Banned' : (isActive ? 'Active' : 'Idle')
        });
      }
    }

    // Sort Top IPs by count descending
    topIPs.sort((a, b) => b.count - a.count);

    // Calculate Real-Time 5s DDoS Rate and Clean Rate
    const nowSec = Math.floor(Date.now() / 1000);
    const ddos5sKeys = [];
    const clean5sKeys = [];
    for (let s = nowSec - 5; s < nowSec; s++) {
      ddos5sKeys.push(`ddos_sec:${s}`);
      clean5sKeys.push(`traffic_sec:${s}`);
    }

    const sysPipeline = redis.pipeline();
    sysPipeline.get('system:lockdown_mode');
    sysPipeline.ttl('system:lockdown_mode');
    sysPipeline.get('system:lockdown_dropped_total');
    sysPipeline.get('system:total_ddos_mitigated_cumulative');
    sysPipeline.get('system:under_attack_mode');
    sysPipeline.get('system:drop_datacenter_proxies');
    sysPipeline.smembers('system:blocked_countries');
    sysPipeline.smembers('system:banned_subnets');
    ddos5sKeys.forEach(k => sysPipeline.get(k));
    clean5sKeys.forEach(k => sysPipeline.get(k));

    const sysResults = await sysPipeline.exec();
    const isLockdownActive = sysResults[0] && (sysResults[0][1] === '1' || sysResults[0][1] === 'true');
    const lockdownTtl = (sysResults[1] && sysResults[1][1]) ? parseInt(sysResults[1][1], 10) : 0;
    const lockdownDropped = (sysResults[2] && sysResults[2][1]) ? parseInt(sysResults[2][1], 10) : 0;
    const ddosMitigatedTotal = (sysResults[3] && sysResults[3][1]) ? parseInt(sysResults[3][1], 10) : 0;
    const isUnderAttackActive = sysResults[4] && sysResults[4][1] === '1';
    const isDropProxiesActive = sysResults[5] && sysResults[5][1] === '1';
    const blockedCountriesList = (sysResults[6] && sysResults[6][1]) || [];
    const bannedSubnetsList = (sysResults[7] && sysResults[7][1]) || [];

    let ddos5sSum = 0;
    let clean5sSum = 0;
    for (let i = 8; i < 13; i++) {
      ddos5sSum += sysResults[i] && sysResults[i][1] ? parseInt(sysResults[i][1], 10) : 0;
    }
    for (let i = 13; i < 18; i++) {
      clean5sSum += sysResults[i] && sysResults[i][1] ? parseInt(sysResults[i][1], 10) : 0;
    }

    const currentDdosRps = Math.round((ddos5sSum / 5) * 10) / 10;
    const currentCleanRps = Math.round((clean5sSum / 5) * 10) / 10;

    // Total Requests MUST exactly equal the sum of requests from all tracked client IPs
    const totalRequestsSum = topIPs.reduce((sum, item) => sum + (item.count || 0), 0);

    res.json({
      success: true,
      lockdown: isLockdownActive,
      lockdownTtl: isLockdownActive && lockdownTtl > 0 ? lockdownTtl : 0,
      lockdownDroppedTotal: lockdownDropped,
      totalDdosMitigated: ddosMitigatedTotal,
      underAttack: isUnderAttackActive,
      dropProxies: isDropProxiesActive,
      blockedCountriesCount: blockedCountriesList.length,
      bannedSubnetsCount: bannedSubnetsList.length,
      totalUniqueIPs: ipList.length,
      totalRequestCount: totalRequestsSum,
      totalCleanRequests: totalRequestsSum,
      bannedIPsCount: allBlacklistKeys.length,
      activeIPs: activeIpsCount,
      currentCleanRps,
      currentDdosRps,
      topIPs: topIPs.slice(0, 50)
    });
  } catch (error) {
    next(error);
  }
});

/**
 * API: Query specific IP details (Strict IP validation)
 * GET /api/ip-stats/:ip
 */
app.get(['/api/ip-stats', '/api/ip-stats/:ip'], validateIpMiddleware('ip'), async (req, res, next) => {
  const targetIp = req.params.ip || req.query.ip;

  try {
    const pipeline = redis.pipeline();
    pipeline.hgetall(`ip_tracker:${targetIp}`);
    pipeline.ttl(`blacklist:${targetIp}`);
    pipeline.get(`rate_limit:${targetIp}`);
    pipeline.ttl(`rate_limit:${targetIp}`);

    const [trackerRes, blacklistRes, rateLimitCountRes, rateLimitTtlRes] = await pipeline.exec();

    const trackerData = (trackerRes && !trackerRes[0]) ? (trackerRes[1] || {}) : {};
    const banTtl = (blacklistRes && !blacklistRes[0]) ? Number(blacklistRes[1]) : -2;
    const currentRateCount = (rateLimitCountRes && !rateLimitCountRes[0]) ? parseInt(rateLimitCountRes[1] || '0', 10) : 0;
    const currentRateTtl = (rateLimitTtlRes && !rateLimitTtlRes[0]) ? Number(rateLimitTtlRes[1]) : 0;

    const isTracked = Object.keys(trackerData).length > 0;
    const isBlacklisted = banTtl > -2;

    const firstSeenNum = trackerData.first_seen ? Number(trackerData.first_seen) : null;
    const lastSeenNum = trackerData.last_seen ? Number(trackerData.last_seen) : null;

    res.json({
      success: true,
      ip: targetIp,
      tracker: !isTracked ? null : {
        count: parseInt(trackerData.count || '0', 10),
        firstSeen: firstSeenNum ? new Date(firstSeenNum).toLocaleString('vi-VN') : 'N/A',
        lastSeen: lastSeenNum ? new Date(lastSeenNum).toLocaleString('vi-VN') : 'N/A'
      },
      security: {
        isBlacklisted,
        banTimeRemainingSec: isBlacklisted ? (banTtl > 0 ? banTtl : 'Permanent') : 0,
        rateLimit: {
          currentRequests: currentRateCount,
          maxRequests: Number(config.RATE_LIMIT_MAX_REQUESTS) || 100,
          windowSec: Number(config.RATE_LIMIT_WINDOW_SEC) || 60,
          windowRemainingSec: currentRateTtl > 0 ? currentRateTtl : 0
        }
      }
    });
  } catch (err) {
    next(err);
  }
});

// ================= 7. STATIC DASHBOARD =================
const publicDir = path.join(__dirname, '..', 'public');
app.use(express.static(publicDir));

app.get('/', (req, res) => {
  const indexPath = path.join(publicDir, 'index.html');
  if (fs.existsSync(indexPath)) {
    return res.sendFile(indexPath);
  }
  return res.json({
    message: 'CYBER_C2_DEFENDER Active',
    yourIp: getRealIp(req),
    timestamp: new Date().toISOString()
  });
});

// ================= 8. CATCH-ALL 404 =================
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Resource not found'
  });
});

// ================= 9. GLOBAL ERROR HANDLER =================
app.use(globalErrorHandler);

// ================= 10. SERVER BOOTSTRAP (HTTP / HTTPS mTLS) =================
const PORT = Number(config.PORT) || 3000;
let serverInstance;

if (config.USE_HTTPS) {
  try {
    const certPath = path.isAbsolute(config.SSL_CERT_PATH) ? config.SSL_CERT_PATH : path.join(__dirname, '..', config.SSL_CERT_PATH);
    const keyPath = path.isAbsolute(config.SSL_KEY_PATH) ? config.SSL_KEY_PATH : path.join(__dirname, '..', config.SSL_KEY_PATH);
    const caPath = path.isAbsolute(config.CLOUDFLARE_CA_PATH) ? config.CLOUDFLARE_CA_PATH : path.join(__dirname, '..', config.CLOUDFLARE_CA_PATH);

    const httpsOptions = {
      cert: fs.readFileSync(certPath),
      key: fs.readFileSync(keyPath)
    };

    // Enable mTLS Authenticated Origin Pulls if Cloudflare CA file exists
    if (fs.existsSync(caPath)) {
      httpsOptions.ca = [fs.readFileSync(caPath)];
      httpsOptions.requestCert = true;
      httpsOptions.rejectUnauthorized = true;
      console.log('[SECURITY] 🔒 Cloudflare Authenticated Origin Pulls (mTLS) has been ACTIVATED.');
    }

    serverInstance = https.createServer(httpsOptions, app);
    console.log(`[SECURITY] 🔒 HTTPS mTLS mode activated.`);
  } catch (sslErr) {
    console.error('[SSL ERROR] Cannot load SSL certificate. Falling back to HTTP:', sslErr.message);
    serverInstance = http.createServer(app);
  }
} else {
  serverInstance = http.createServer(app);
}

serverInstance.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`🚀 [SERVER] CYBER_C2_DEFENDER running at: http${config.USE_HTTPS ? 's' : ''}://localhost:${PORT}`);
  console.log(`📊 [DASHBOARD] Hacker C2 Interface: http${config.USE_HTTPS ? 's' : ''}://localhost:${PORT}/`);
  console.log(`🛡️  [SECURITY] Rate Limit: ${config.RATE_LIMIT_MAX_REQUESTS} reqs / ${config.RATE_LIMIT_WINDOW_SEC}s`);
  console.log(`⛔ [SECURITY] Ban Duration: ${config.BAN_DURATION_SEC}s`);
  console.log(`📁 [EXCEL] Export file: ${config.EXCEL_EXPORT_PATH}`);
  console.log(`🔑 [API AUTH] Admin API Key: ${config.ADMIN_API_KEY ? '🔒 Auth enabled' : '🔓 Not set'}`);
  console.log(`🤖 [TELEGRAM] Bot Status: ${telegramService.isTelegramConfigured() ? '✅ Activated' : '⚠️ Disabled'}`);
  console.log(`🛡️  [ANTI-DDOS] Real-time Telegram DDoS Monitoring: Updates every 5 seconds`);
  console.log(`=======================================================`);

  // Start background processes
  telegramService.initTelegramBot();
});

module.exports = app;