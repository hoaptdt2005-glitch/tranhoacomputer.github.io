# 🛡️ CLOUDFLARE WAF & ZERO TRUST SECURITY HANDBOOK

Detailed documentation guiding the setup of a multi-layer Cloudflare Edge defense system for the **CYBER C2 DEFENDER (IP Report & Anti-DDoS)** application, stopping 99.9% of vulnerability scanning traffic and brute-force attacks before they reach the server.

---

## 📑 TABLE OF CONTENTS
1. [Multi-Tier Defense Architecture](#1-multi-tier-defense-architecture)
2. [Cloudflare Zero Trust Configuration (Email OTP Access)](#2-cloudflare-zero-trust-configuration-email-otp-access)
3. [Cloudflare WAF Custom Rules Configuration (3 Core Rules)](#3-cloudflare-waf-custom-rules-configuration-3-core-rules)
4. [Cloudflare Edge Rate Limiting Configuration](#4-cloudflare-edge-rate-limiting-configuration)

---

## 1. MULTI-TIER DEFENSE ARCHITECTURE

```mermaid
flowchart TD
    Client[🌐 Internet Users / Hackers] --> CF_Edge[☁️ Cloudflare Edge]
    
    subgraph Cloudflare WAF & Access
        CF_Edge --> WAF1[Rule 1: Block Exploit Scanners & Malicious User-Agents]
        WAF1 --> WAF2[Rule 2: Managed Challenge outside territory]
        WAF2 --> WAF3[Rule 3: Block access to sensitive files]
        WAF3 --> RateLimit[Rule 4: Edge Rate Limiting > 50 reqs / 10s]
        RateLimit --> ZeroTrust[🔐 Cloudflare Zero Trust: Email OTP for Admin Routes]
    end
    
    ZeroTrust --> Server[🖥️ Host PC / Express Server]
    
    subgraph Host Defense
        Server --> IPTracker[📊 Real-time IP Tracker]
        IPTracker --> Local_RateLimiter[⛔ Local Rate Limiter & Auto-Ban]
        Local_RateLimiter --> Redis[(⚡ Redis Cache)]
        Local_RateLimiter --> TelegramAlert[🤖 Telegram Bot Alert 24/7]
    end
```

---

## 2. CLOUDFLARE ZERO TRUST CONFIGURATION (EMAIL OTP ACCESS)

> 🎯 **Goal**: Setup a login screen requiring an OTP code sent to the Administrator's Email before granting access to sensitive paths (`/api/unban/*`, `/api/export-excel`, `/api/backup-now`, or Dashboard).

### Steps to configure:
1. Log into [Cloudflare Dashboard](https://dash.cloudflare.com/) -> Select **Zero Trust**.
2. Navigate to **Access** -> **Applications** -> Click **Add an application**.
3. Select **Self-hosted** type.
4. **Application Configuration:**
   - **Application name**: `Cyber C2 Admin Gate`
   - **Application domain**: `shield.yourdomain.com` (Path: leave empty or enter `/api/unban/*`, `/api/export-excel`).
   - **Session Duration**: `24 Hours`.
5. **Access Policy Configuration:**
   - **Policy name**: `Admin OTP Only`
   - **Action**: `Allow`
   - **Configure rules**: Select Selector as `Emails` -> Enter your admin email (e.g., `admin@yourdomain.com`).
6. Click **Save policy** -> **Add application**.

---

## 3. CLOUDFLARE WAF CUSTOM RULES CONFIGURATION (3 CORE RULES)

Go to **Websites** -> Select your domain -> **Security** -> **WAF** -> **Custom rules** -> **Create rule**:

---

### 🛡️ Rule 1: Block Automated Scanners (Block Scanners & Malicious User-Agents)
- **Rule Name**: `Block Automated Scanners & Vulnerability Tools`
- **Action**: `Block`
- **Expression Preview**:
```text
(http.user_agent contains "nmap") or 
(http.user_agent contains "sqlmap") or 
(http.user_agent contains "burp") or 
(http.user_agent contains "nikto") or 
(http.user_agent contains "zgrab") or 
(http.user_agent contains "python-requests") or 
(http.user_agent contains "go-http-client") or 
(http.user_agent contains "nuclei") or 
(http.user_agent contains "masscan")
```

---

### 🛡️ Rule 2: Geo-Blocking Challenge
- **Rule Name**: `Challenge Non-Target Geo Regions`
- **Action**: `Managed Challenge` (Cloudflare Turnstile automatically)
- **Expression Preview**:
```text
not (ip.geoip.country in {"VN"})
```

---

### 🛡️ Rule 3: Absolute Block on Sensitive Files (Block Sensitive Files)
- **Rule Name**: `Block Probing Sensitive Files`
- **Action**: `Block`
- **Expression Preview**:
```text
(http.request.uri.path contains "/.env") or 
(http.request.uri.path contains "/.git") or 
(http.request.uri.path contains "config.txt") or 
(http.request.uri.path contains ".rdb") or 
(http.request.uri.path contains ".enc") or 
(http.request.uri.path contains "/certs/") or 
(http.request.uri.path contains "/data/")
```

---

## 4. CLOUDFLARE EDGE RATE LIMITING CONFIGURATION

Go to **Security** -> **WAF** -> **Rate limiting rules** -> **Create rule**:

- **Rule Name**: `Edge DDoS Rate Limit - 50 reqs / 10s`
- **Rate limiting criteria**:
  - **Requests**: `50`
  - **Period**: `10 seconds`
  - **Count by**: `IP address`
- **Action**: `Block` (Duration: `10 minutes`)
- **Response status code**: `429 (Too Many Requests)`
- **Response content**:
  ```json
  {"success": false, "message": "Edge Rate Limit Exceeded by Cloudflare"}
  ```
